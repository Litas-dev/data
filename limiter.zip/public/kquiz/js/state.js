﻿// /js/state.js
export const state = {
  data: null,
  players: {},
  nameById: new Map()
};
