/* KQuiz papildinys: Komandu chemine kova (v1.0)
   - Vedejas paleid�ia foje, kur �iurovai pasirenka A (raudona) arba B (melyna) komanda
   - Po 30 s laukimo komandos var�osi, kas greiciau para�ys teisinga cheminio elemento simboli
   - Pirmas teisingas simbolis duoda +1 ta�ka komandai; laimi geriausia i� 5 ratu
*/
(function () {
  "use strict";

  const ADDON_ID = "chemTeamBattle";
  const LOBBY_MS = 30000;
  const ROUND_MS = 15000;
  const CELEBRATION_MS = 4000;
  const MAX_ROUNDS = 5;
  const TEAM_CAP = 5;
  const WIN_REWARD = 50;
  const LOSS_PENALTY = 50;
  const SUDDEN_DEATH_MS = 8000;

  const TEAMS = [
    { id: "red", label: "A komanda", joinKey: "A", color: "#e23c4a" },
    { id: "blue", label: "B komanda", joinKey: "B", color: "#2d6cf6" }
  ];

  const ELEMENTS = [
    { number: 1, symbol: "H", name: "Vandenilis" },
    { number: 2, symbol: "He", name: "Helis" },
    { number: 3, symbol: "Li", name: "Litis" },
    { number: 4, symbol: "Be", name: "Berilis" },
    { number: 5, symbol: "B", name: "Boras" },
    { number: 6, symbol: "C", name: "Anglis" },
    { number: 7, symbol: "N", name: "Azotas" },
    { number: 8, symbol: "O", name: "Deguonis" },
    { number: 10, symbol: "Ne", name: "Neonas" },
    { number: 11, symbol: "Na", name: "Natris" },
    { number: 12, symbol: "Mg", name: "Magnis" },
    { number: 13, symbol: "Al", name: "Aliuminis" },
    { number: 14, symbol: "Si", name: "Silicis" },
    { number: 15, symbol: "P", name: "Fosforas" },
    { number: 16, symbol: "S", name: "Siera" },
    { number: 17, symbol: "Cl", name: "Chloras" },
    { number: 18, symbol: "Ar", name: "Argonas" },
    { number: 19, symbol: "K", name: "Kalis" },
    { number: 20, symbol: "Ca", name: "Kalcis" },
    { number: 21, symbol: "Sc", name: "Skandis" },
    { number: 22, symbol: "Ti", name: "Titanas" },
    { number: 23, symbol: "V", name: "Vanadis" },
    { number: 24, symbol: "Cr", name: "Chromas" },
    { number: 25, symbol: "Mn", name: "Manganas" },
    { number: 26, symbol: "Fe", name: "Gelezis" },
    { number: 27, symbol: "Co", name: "Kobaltas" },
    { number: 28, symbol: "Ni", name: "Nikelis" },
    { number: 29, symbol: "Cu", name: "Varis" },
    { number: 30, symbol: "Zn", name: "Cinkas" },
    { number: 31, symbol: "Ga", name: "Galis" },
    { number: 32, symbol: "Ge", name: "Germanis" },
    { number: 33, symbol: "As", name: "Arsenas" },
    { number: 34, symbol: "Se", name: "Selenas" },
    { number: 35, symbol: "Br", name: "Bromas" },
    { number: 36, symbol: "Kr", name: "Kriptonas" },
    { number: 37, symbol: "Rb", name: "Rubidis" },
    { number: 38, symbol: "Sr", name: "Stroncis" },
    { number: 39, symbol: "Y", name: "Itris" },
    { number: 40, symbol: "Zr", name: "Cirkonis" },
    { number: 41, symbol: "Nb", name: "Niobis" },
    { number: 42, symbol: "Mo", name: "Molibdenas" },
    { number: 43, symbol: "Tc", name: "Tecnetis" },
    { number: 44, symbol: "Ru", name: "Rutenis" },
    { number: 45, symbol: "Rh", name: "Rodis" },
    { number: 46, symbol: "Pd", name: "Paladis" },
    { number: 47, symbol: "Ag", name: "Sidabras" },
    { number: 48, symbol: "Cd", name: "Kadmis" },
    { number: 49, symbol: "In", name: "Indis" },
    { number: 50, symbol: "Sn", name: "Alavas" }
  ];

  function shuffle(list) {
    const arr = list.slice();
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
    }
    return arr;
  }

  function getUserId(msg) {
    let id =
      msg?.userId ||
      msg?.user?.userId ||
      msg?.user?.secUid ||
      msg?.secUid ||
      msg?.user?.uniqueId ||
      msg?.uniqueId ||
      msg?.uid ||
      null;
    if (typeof id === "number") id = String(id);
    return id;
  }

  function getUserName(msg) {
    return (
      msg?.displayName ||
      msg?.nickname ||
      msg?.user?.nickname ||
      msg?.user?.displayName ||
      msg?.user?.uniqueId ||
      msg?.nickname ||
      msg?.uniqueId ||
      "žaidėjas"
    );
  }

  function getUserAvatar(msg) {
    return (
      msg?.profilePicture ||
      msg?.profilePictureUrl ||
      msg?.user?.profilePicture ||
      msg?.user?.profilePictureUrl ||
      msg?.avatar ||
      ""
    );
  }

  function getChatText(msg) {
    if (typeof msg?.text === "string") return msg.text;
    if (typeof msg?.parsedAnswer === "string") return msg.parsedAnswer;
    return "";
  }

  function parseTeamChoice(text) {
    if (!text) return null;
    const upper = text.toUpperCase();
    if (
      upper === "A" ||
      upper === "RED" ||
      upper.indexOf("TEAM A") >= 0 ||
      upper.indexOf("KOMANDA A") >= 0 ||
      upper.indexOf("RAUD") >= 0
    ) {
      return "red";
    }
    if (
      upper === "B" ||
      upper === "BLUE" ||
      upper.indexOf("TEAM B") >= 0 ||
      upper.indexOf("KOMANDA B") >= 0 ||
      upper.indexOf("MELYN") >= 0 ||
      upper.indexOf("MELYN") >= 0
    ) {
      return "blue";
    }
    return null;
  }

  function sanitizeSymbol(raw) {
    return String(raw || "").trim().replace(/\s+/g, "");
  }

  function canonicalizeId(raw) {
    if (raw == null) return null;
    const str = String(raw);
    return str.length > 30 ? str : str.toLowerCase();
  }

  function factory() {
    let mounted = false;
    let wrap = null;
    let styleEl = null;
    let visible = false;
    let phase = "idle";
    let lobbyTimer = null;
    let lobbyTicker = null;
    let lobbyEndsAt = 0;
    let roundTimer = null;
    let countdownTicker = null;
    let celebrationTimer = null;
    let questionEndsAt = 0;
    let pausedMain = false;
    let guardAttached = false;
    let roundIndex = 0;
    let current = null;
    let deck = [];
    let caseHintShown = false;
    let roundResolved = false;
    let suddenDeath = false;
    let lastScores = { red: 0, blue: 0 };
    let lastJoin = null;
    const scorePulseTimers = { red: null, blue: null };
    const emitEvent = (name, payload) => {
      try { window.KQuiz?.emit?.(name, payload); }
      catch (err) { console.warn("[chem-team-battle] emit failed", name, err); }
    };
    const shallowMemberView = (player) => ({
      id: player?.id || player?.originalId || null,
      name: player?.name || "",
      avatar: player?.avatar || ""
    });
    const snapshotTeams = () => ({
      red: {
        count: members.red.size,
        score: scores.red || 0,
        members: Array.from(members.red.values()).map(shallowMemberView)
      },
      blue: {
        count: members.blue.size,
        score: scores.blue || 0,
        members: Array.from(members.blue.values()).map(shallowMemberView)
      }
    });
    const snapshotScores = () => ({ red: scores.red || 0, blue: scores.blue || 0 });
    const emitTeamEvent = (details) => {
      emitEvent("team:event", Object.assign({ addon: ADDON_ID, timestamp: Date.now() }, details));
    };

    const members = { red: new Map(), blue: new Map() };
    const scores = { red: 0, blue: 0 };
    const userToTeam = new Map();

    const ctrl = window.KQuiz?.control || {};
    const { pauseMain, resumeFlow, setChatGuard, clearChatGuard } = ctrl;

    const refs = {
      headerTimer: null,
      status: null,
      roundLabel: null,
      elementName: null,
      elementNumber: null,
      questionTimer: null,
      banner: null,
      resultTitle: null,
      resultDetail: null,
      rewardInfo: null,
      rewardList: null,
      penaltyInfo: null,
      penaltyList: null,
      redCount: null,
      blueCount: null,
      redMembers: null,
      blueMembers: null,
      redScore: null,
      blueScore: null,
      skipBtn: null,
      restartBtn: null
    };

    function mount() {
      if (mounted) return;

      styleEl = document.createElement("style");
      styleEl.textContent = `
@keyframes battleGlow{
  0%{transform:rotate(0deg);}
  100%{transform:rotate(360deg);}
}
@keyframes chipPop{
  0%{transform:scale3d(.7,.7,1) rotateX(-40deg);opacity:0;}
  60%{transform:scale3d(1.08,1.08,1) rotateX(6deg);opacity:1;}
  100%{transform:scale3d(1,1,1) rotateX(0deg);opacity:1;}
}
@keyframes scorePulse{
  0%{transform:translateZ(0) scale3d(1,1,1);}
  50%{transform:translateZ(22px) scale3d(1.12,1.12,1);}
  100%{transform:translateZ(0) scale3d(1,1,1);}
}
@keyframes confettiFall{
  0%{transform:translate3d(0,-40%,0) rotateZ(0deg);opacity:0.9;}
  100%{transform:translate3d(0,140%,0) rotateZ(260deg);opacity:0;}
}
@keyframes sparkFloat{
  0%{opacity:0;transform:translate3d(0,0,0) scale(.6);}
  30%{opacity:.9;}
  100%{opacity:0;transform:translate3d(120px,-220px,60px) scale(1.2);}
}
@keyframes burstRise{
  0%{transform:translate(-50%,20%) scale(.6);opacity:0;}
  40%{transform:translate(-50%,-10%) scale(1);opacity:1;}
  100%{transform:translate(-50%,-120%) scale(1.2);opacity:0;}
}
.kq-battle-wrap{
  position:fixed;inset:0;z-index:160;
  display:none;align-items:center;justify-content:center;
  background:linear-gradient(135deg,rgba(6,10,22,0.88),rgba(14,24,54,0.92));
  padding:28px;
  font-family:"Inter",Arial,sans-serif;
  color:#f6f8ff;
  perspective:1600px;
  overflow:hidden;
}
.kq-battle-wrap::before{
  content:"";
  position:absolute;inset:-20%;
  background:radial-gradient(circle at center,rgba(88,118,255,0.28),transparent 60%),conic-gradient(from 0deg,rgba(226,60,74,0.12),rgba(45,108,246,0.12),rgba(226,60,74,0.12));
  filter:blur(60px);
  animation:battleGlow 20s linear infinite;
  pointer-events:none;
}
.kq-battle-wrap::after{
  content:"";
  position:absolute;inset:0;
  background:radial-gradient(circle at 15% 20%,rgba(226,60,74,0.15) 0%,transparent 55%),radial-gradient(circle at 80% 80%,rgba(45,108,246,0.18) 0%,transparent 50%);
  opacity:0.7;
  pointer-events:none;
}
.kq-battle-card{
  width:min(1100px,92vw);
  min-height:min(640px,88vh);
  background:rgba(16,22,42,0.96);
  border:1px solid rgba(255,255,255,0.08);
  border-radius:20px;
  box-shadow:0 24px 64px rgba(0,0,0,0.45);
  display:flex;
  flex-direction:column;
  padding:26px;
  gap:20px;
  position:relative;
  box-shadow:0 30px 120px rgba(5,12,30,0.55);
}
.kq-battle-header{
  display:flex;
  align-items:center;
  justify-content:space-between;
}
.kq-battle-title{
  font-size:32px;
  font-weight:900;
  letter-spacing:0.02em;
}
.kq-battle-timer{
  min-width:92px;
  text-align:center;
  font-size:28px;
  font-weight:700;
  padding:8px 18px;
  border-radius:999px;
  background:rgba(255,255,255,0.12);
}
.kq-battle-phase{
  display:none;
  flex:1;
  flex-direction:column;
  gap:18px;
}
.kq-battle-wrap[data-phase="lobby"] .phase-lobby,
.kq-battle-wrap[data-phase="quiz"] .phase-quiz,
.kq-battle-wrap[data-phase="result"] .phase-result{
  display:flex;
}
.kq-battle-instructions{
  font-size:18px;
  opacity:0.92;
  line-height:1.4;
  text-align:center;
}
.kq-battle-teams{
  display:flex;
  gap:18px;
  flex:1;
}
.kq-battle-team{
  flex:1;
  border-radius:18px;
  padding:18px;
  display:flex;
  flex-direction:column;
  gap:12px;
  background:rgba(255,255,255,0.05);
  border:2px solid transparent;
  transition:transform .25s ease, border-color .35s ease, box-shadow .35s ease;
}
.kq-battle-team.red{ border-color:#e23c4a; box-shadow:0 0 32px rgba(226,60,74,0.2); }
.kq-battle-team.blue{ border-color:#2d6cf6; box-shadow:0 0 32px rgba(45,108,246,0.2); }
.kq-battle-team:hover{
  transform:translateY(-6px) scale(1.01);
}
.kq-battle-team .team-name{
  font-size:24px;
  font-weight:800;
}
.kq-battle-team .team-join{
  font-size:16px;
  opacity:0.75;
}
.kq-battle-team .team-count{
  font-size:16px;
  font-weight:600;
  opacity:0.9;
}
.kq-battle-team .team-members{
  flex:1;
  display:flex;
  flex-wrap:wrap;
  gap:8px;
  align-content:flex-start;
  overflow:auto;
}
.kq-battle-team .chip{
  width:52px;
  height:52px;
  border-radius:50%;
  background:rgba(255,255,255,0.12);
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
  position:relative;
  border:2px solid rgba(255,255,255,0.18);
  box-shadow:0 4px 12px rgba(0,0,0,0.25);
  transform-style:preserve-3d;
  animation:chipPop .35s ease;
}
.kq-battle-team .chip img{
  width:100%;
  height:100%;
  object-fit:cover;
}
.kq-battle-team .chip.chip-new{
  animation:chipPop .55s cubic-bezier(.22,1.56,.36,.94);
  box-shadow:0 10px 30px rgba(255,255,255,0.35);
}
.kq-battle-team .chip .initial{
  font-size:20px;
  font-weight:700;
  letter-spacing:0.02em;
  opacity:0.85;
}
.kq-battle-scoreboard{
  display:flex;
  gap:18px;
}
.kq-battle-score{
  flex:1;
  display:flex;
  align-items:center;
  justify-content:space-between;
  padding:16px 22px;
  border-radius:16px;
  background:rgba(255,255,255,0.05);
  border:2px solid transparent;
}
.kq-battle-score.red{ border-color:#e23c4a; }
.kq-battle-score.blue{ border-color:#2d6cf6; }
.kq-battle-score .label{
  font-size:18px;
  font-weight:700;
  letter-spacing:0.02em;
}
.kq-battle-score .value{
  font-size:40px;
  font-weight:900;
  transform-style:preserve-3d;
}
.kq-battle-score .value.bump-up{ animation:scorePulse .6s cubic-bezier(.25,1.12,.32,1) both; color:#aefcd4; }
.kq-battle-score .value.bump-down{ animation:scorePulse .6s cubic-bezier(.25,1.12,.32,1) reverse both; color:#ffd7d7; }
.kq-battle-round{
  font-size:20px;
  font-weight:700;
  opacity:0.85;
}
.kq-battle-question{
  display:flex;
  align-items:center;
  gap:16px;
  flex-wrap:wrap;
  padding:18px 20px;
  border-radius:16px;
  background:rgba(11,18,36,0.9);
  border:1px solid rgba(255,255,255,0.06);
}
.kq-battle-question .prompt{
  font-size:18px;
  font-weight:600;
  opacity:0.8;
}
.kq-battle-question .name{
  font-size:28px;
  font-weight:900;
}
.kq-battle-question .number{
  font-size:18px;
  font-weight:500;
  opacity:0.75;
}
.kq-battle-question .q-timer{
  margin-left:auto;
  font-size:26px;
  font-weight:800;
  padding:6px 16px;
  border-radius:12px;
  background:rgba(255,255,255,0.12);
}
.kq-battle-status{
  font-size:18px;
  padding:14px 18px;
  border-radius:12px;
  background:rgba(255,255,255,0.06);
  border:1px solid rgba(255,255,255,0.08);
}
.kq-battle-status.positive{ border-color:rgba(65,214,145,0.5); color:#aefcd4; }
.kq-battle-status.warning{ border-color:rgba(255,180,92,0.6); color:#ffe1b4; }
.kq-battle-status{
  transition:transform .3s ease, box-shadow .3s ease;
}
.kq-battle-status.positive{ box-shadow:0 0 22px rgba(65,214,145,0.2); }
.kq-battle-status.warning{ box-shadow:0 0 22px rgba(255,180,92,0.2); }
.kq-battle-banner{
  font-size:24px;
  font-weight:800;
  text-align:center;
  padding:16px;
  border-radius:14px;
  background:rgba(255,255,255,0.08);
  border:1px solid rgba(255,255,255,0.12);
}
.kq-battle-banner.hidden{ display:none; }
.kq-battle-banner.positive{ border-color:rgba(65,214,145,0.5); color:#aefcd4; }
.kq-battle-banner.warning{ border-color:rgba(255,180,92,0.6); color:#ffe1b4; }
.kq-battle-result{
  margin:auto;
  text-align:center;
  display:flex;
  flex-direction:column;
  gap:14px;
}
.kq-battle-result .result-title{
  font-size:34px;
  font-weight:900;
}
.kq-battle-result .result-detail{
  font-size:20px;
  opacity:0.85;
}
.kq-battle-reward-info,
.kq-battle-penalty-info{
  font-size:18px;
  opacity:0.9;
}
.kq-battle-reward-list,
.kq-battle-penalty-list{
  display:flex;
  flex-wrap:wrap;
  justify-content:center;
  gap:10px;
}
.kq-battle-reward-chip,
.kq-battle-penalty-chip{
  padding:6px 12px;
  border-radius:999px;
  background:rgba(255,255,255,0.12);
  border:1px solid rgba(255,255,255,0.18);
  font-size:16px;
  font-weight:700;
  letter-spacing:0.01em;
}
.kq-battle-reward-list.hidden,
.kq-battle-reward-info.hidden,
.kq-battle-penalty-list.hidden,
.kq-battle-penalty-info.hidden{
  display:none;
}
.kq-battle-penalty-chip{
  background:rgba(226,60,74,0.18);
  border-color:rgba(226,60,74,0.35);
}
.kq-battle-actions{
  display:flex;
  gap:12px;
  justify-content:flex-end;
}
.kq-battle-btn{
  padding:12px 20px;
  border-radius:10px;
  border:none;
  font-size:16px;
  font-weight:600;
  cursor:pointer;
  color:#0b0f1c;
  background:#f5f7ff;
  transition:transform 0.15s ease, opacity 0.2s ease;
}
.kq-battle-btn:hover{ transform:translateY(-1px); opacity:0.92; }
.kq-battle-btn.warn{ background:#ffc266; color:#2c1600; }
.kq-battle-btn.alt{ background:#7d8bff; color:#050713; }
.kq-battle-btn.hidden{ display:none; }
      `;
      document.head.appendChild(styleEl);

      wrap = document.createElement("div");
      wrap.className = "kq-battle-wrap";
      wrap.setAttribute("data-phase", "idle");
      wrap.innerHTML = `
        <div class="kq-battle-card">
          <div class="kq-battle-header">
            <div class="kq-battle-title">Komandu kova</div>
            <div class="kq-battle-timer" data-role="main-timer">30</div>
          </div>

          <div class="kq-battle-phase phase-lobby">
            <div class="kq-battle-instructions">
              <strong>A</strong>, jei nori buti su raudonaisiais (A komanda), arba <strong>B</strong>, jei renkasi melynuosius (B komanda). Kiekvienoje komandoje telpa iki ${TEAM_CAP} žaidėjų.
            </div>
            <div class="kq-battle-teams">
              <div class="kq-battle-team red" data-team="red">
                <div class="team-name">A komanda <span style="opacity:0.7;font-size:16px;">(Raudona)</span></div>
                <div class="team-count" data-role="count-red">0 žaidėjų</div>
                <div class="team-members" data-role="members-red"></div>
              </div>
              <div class="kq-battle-team blue" data-team="blue">
                <div class="team-name">B komanda <span style="opacity:0.7;font-size:16px;">(Melyna)</span></div>
                <div class="team-count" data-role="count-blue">0 žaidėjų</div>
                <div class="team-members" data-role="members-blue"></div>
              </div>
            </div>
          </div>

          <div class="kq-battle-phase phase-quiz">
            <div class="kq-battle-scoreboard">
              <div class="kq-battle-score red">
                <div class="label">A komanda</div>
                <div class="value" data-role="score-red">0</div>
              </div>
              <div class="kq-battle-score blue">
                <div class="label">B komanda</div>
                <div class="value" data-role="score-blue">0</div>
              </div>
            </div>
            <div class="kq-battle-round" data-role="round-label">1 ratas / ${MAX_ROUNDS}</div>
            <div class="kq-battle-question">
              <div class="prompt">Elementas:</div>
              <div class="name" data-role="element-name">Vandenilis</div>
              <div class="number">Nr. <span data-role="element-number">1</span></div>
              <div class="q-timer" data-role="question-timer">15</div>
            </div>
            <div class="kq-battle-status" data-role="status">Pasiruo�kite...</div>
            <div class="kq-battle-banner hidden" data-role="banner"></div>
          </div>

          <div class="kq-battle-phase phase-result">
            <div class="kq-battle-result">
              <div class="result-title" data-role="result-title">Kova baigta</div>
              <div class="result-detail" data-role="result-detail">Taškai bus parodyti cia.</div>
              <div class="kq-battle-reward-info hidden" data-role="reward-info"></div>
              <div class="kq-battle-reward-list hidden" data-role="reward-list"></div>
              <div class="kq-battle-penalty-info hidden" data-role="penalty-info"></div>
              <div class="kq-battle-penalty-list hidden" data-role="penalty-list"></div>
            </div>
          </div>

<div class="kq-battle-actions">
  <button class="kq-battle-btn" data-act="close">Uždaryti</button>
  <button class="kq-battle-btn alt" data-act="restart">Foje</button>
  <button class="kq-battle-btn" data-act="start">Pradeti kova</button>
  <button class="kq-battle-btn warn hidden" data-act="skip">Praleisti</button>
</div>

        </div>`;

      document.body.appendChild(wrap);

      refs.headerTimer = wrap.querySelector("[data-role='main-timer']");
      refs.status = wrap.querySelector("[data-role='status']");
      refs.roundLabel = wrap.querySelector("[data-role='round-label']");
      refs.elementName = wrap.querySelector("[data-role='element-name']");
      refs.elementNumber = wrap.querySelector("[data-role='element-number']");
      refs.questionTimer = wrap.querySelector("[data-role='question-timer']");
      refs.banner = wrap.querySelector("[data-role='banner']");
      refs.resultTitle = wrap.querySelector("[data-role='result-title']");
      refs.resultDetail = wrap.querySelector("[data-role='result-detail']");
      refs.rewardInfo = wrap.querySelector("[data-role='reward-info']");
      refs.rewardList = wrap.querySelector("[data-role='reward-list']");
      refs.penaltyInfo = wrap.querySelector("[data-role='penalty-info']");
      refs.penaltyList = wrap.querySelector("[data-role='penalty-list']");
      refs.redCount = wrap.querySelector("[data-role='count-red']");
      refs.blueCount = wrap.querySelector("[data-role='count-blue']");
      refs.redMembers = wrap.querySelector("[data-role='members-red']");
      refs.blueMembers = wrap.querySelector("[data-role='members-blue']");
      refs.redScore = wrap.querySelector("[data-role='score-red']");
      refs.blueScore = wrap.querySelector("[data-role='score-blue']");
      refs.skipBtn = wrap.querySelector("[data-act='skip']");
      refs.restartBtn = wrap.querySelector("[data-act='restart']");
      refs.startBtn = wrap.querySelector("[data-act='start']");

wrap.addEventListener("click", (evt) => {
  const act = evt.target?.getAttribute?.("data-act");
  if (!act) return;

  if (act === "close") {
    hide();

  } else if (act === "restart") {
    if (phase === "quiz") {
      startLobby(true);
    } else {
      startLobby(false);
    }

  } else if (act === "start") {
    // manual start instead of lobby timeout
    finishLobby();

  } else if (act === "skip") {
    skipRound();
  }
});


      mounted = true;
    }

    function unmount() {
      if (!mounted) return;
      stopAllTimers();
      detachGuard();
      try { wrap?.remove(); } catch {}
      try { styleEl?.remove(); } catch {}
      mounted = false;
      wrap = null;
      styleEl = null;
      visible = false;
      phase = "idle";
    }

    function attachGuard() {
      if (guardAttached || typeof setChatGuard !== "function") return;
      try {
        setChatGuard(handleChat);
        guardAttached = true;
      } catch (err) {
        console.warn("[chem-team-battle] setChatGuard failed", err);
      }
    }

    function detachGuard() {
      if (!guardAttached) return;
      guardAttached = false;
      if (typeof clearChatGuard === "function") {
        try { clearChatGuard(); } catch (err) {
          console.warn("[chem-team-battle] clearChatGuard failed", err);
        }
      }
    }

    function show() {
      if (!mounted) mount();
      if (!mounted || visible) return;
      visible = true;
      wrap.style.display = "flex";
      if (pauseMain && !pausedMain) {
        try { pauseMain(); pausedMain = true; } catch {}
      }
      startLobby(false);
    }

    function hide() {
      if (!visible) return;
      visible = false;
      stopAllTimers();
      detachGuard();
      wrap.setAttribute("data-phase", "idle");
      wrap.style.display = "none";
      setStatus("");
      setBanner("", null);
      clearOutcomeDisplay();
      Object.keys(scorePulseTimers).forEach((key) => {
        if (scorePulseTimers[key]) {
          clearTimeout(scorePulseTimers[key]);
          scorePulseTimers[key] = null;
        }
      });
      if (refs.redScore) refs.redScore.classList.remove("bump-up", "bump-down");
      if (refs.blueScore) refs.blueScore.classList.remove("bump-up", "bump-down");
      if (resumeFlow && pausedMain) {
        try { resumeFlow(); } catch {}
      }
      pausedMain = false;
      phase = "idle";
    }
function setPhase(next) {
  phase = next;
  if (wrap) wrap.setAttribute("data-phase", next);
  updateHeaderTimer();

  if (refs.skipBtn) {
    refs.skipBtn.classList.toggle("hidden", next !== "quiz");
  }
  if (refs.startBtn) {
    // show the Start button only in the lobby
    refs.startBtn.classList.toggle("hidden", next !== "lobby");
  }
}


    function stopAllTimers() {
      if (lobbyTimer) { clearTimeout(lobbyTimer); lobbyTimer = null; }
      if (lobbyTicker) { clearInterval(lobbyTicker); lobbyTicker = null; }
      if (roundTimer) { clearTimeout(roundTimer); roundTimer = null; }
      if (countdownTicker) { clearInterval(countdownTicker); countdownTicker = null; }
      if (celebrationTimer) { clearTimeout(celebrationTimer); celebrationTimer = null; }
    }

    function resetPlayers() {
      members.red.clear();
      members.blue.clear();
      userToTeam.clear();
      scores.red = 0;
      scores.blue = 0;
      lastScores.red = 0;
      lastScores.blue = 0;
      lastJoin = null;
      suddenDeath = false;
      Object.keys(scorePulseTimers).forEach((key) => {
        if (scorePulseTimers[key]) {
          clearTimeout(scorePulseTimers[key]);
          scorePulseTimers[key] = null;
        }
      });
      if (refs.redScore) refs.redScore.classList.remove("bump-up", "bump-down");
      if (refs.blueScore) refs.blueScore.classList.remove("bump-up", "bump-down");
      renderTeams();
      renderScores();
      emitTeamEvent({
        type: "battleStart",
        teams: snapshotTeams(),
        suddenDeath: false
      });
    }

    function updateHeaderTimer() {
      if (!refs.headerTimer) return;
      if (phase === "lobby") {
        const remaining = Math.max(0, Math.ceil((lobbyEndsAt - performance.now()) / 1000));
        refs.headerTimer.textContent = `${remaining}s`;
      } else if (phase === "quiz") {
        refs.headerTimer.textContent = suddenDeath ? "Staigi mirtis" : `Ratas ${roundIndex + 1}/${MAX_ROUNDS}`;
      } else if (phase === "result") {
        refs.headerTimer.textContent = "Baigta";
      } else {
        refs.headerTimer.textContent = "Paruo�ta";
      }
    }

    function updateQuestionTimer() {
      if (!refs.questionTimer) return;
      if (phase !== "quiz" || !current) {
        refs.questionTimer.textContent = "0";
        return;
      }
      const remaining = Math.max(0, Math.ceil((questionEndsAt - performance.now()) / 1000));
      refs.questionTimer.textContent = String(remaining);
    }

    function renderTeams() {
      if (!refs.redCount || !refs.blueCount) return;
      refs.redCount.textContent = `${members.red.size}/${TEAM_CAP} žaidėjų`;
      refs.blueCount.textContent = `${members.blue.size}/${TEAM_CAP} žaidėjų`;
      if (refs.redMembers) {
        refs.redMembers.innerHTML =
          Array.from(members.red.values())
            .slice(0, TEAM_CAP)
            .map((p) => renderMemberChip(p, "red"))
            .join("") || `<div class="chip"><span class="initial">?</span></div>`;
      }
      if (refs.blueMembers) {
        refs.blueMembers.innerHTML =
          Array.from(members.blue.values())
            .slice(0, TEAM_CAP)
            .map((p) => renderMemberChip(p, "blue"))
            .join("") || `<div class="chip"><span class="initial">?</span></div>`;
      }
      highlightLastJoin();
    }

    function renderScores() {
      const redVal = Number(scores.red || 0);
      const blueVal = Number(scores.blue || 0);
      if (refs.redScore) refs.redScore.textContent = String(redVal);
      if (refs.blueScore) refs.blueScore.textContent = String(blueVal);
      lastScores.red = redVal;
      lastScores.blue = blueVal;
    }

    function renderMemberChip(player, teamId) {
      const record = ensureGlobalPlayerRecord(player) || player;
      const name = record?.name || player?.name || "";
      const avatar = player?.avatar || record?.avatar || "";
      const token = player?.dataToken || encodeURIComponent(player?.id || "");
      if (avatar) {
        return `<div class="chip" data-chip="${token}" data-team="${teamId}"><img src="${escapeAttr(avatar)}" alt="${escapeAttr(name)}" referrerpolicy="no-referrer"></div>`;
      }
      const initial = (name.trim().charAt(0) || "?").toUpperCase();
      return `<div class="chip" data-chip="${token}" data-team="${teamId}"><span class="initial">${escapeHtml(initial)}</span></div>`;
    }

    function clearOutcomeDisplay() {
      if (refs.rewardInfo) {
        refs.rewardInfo.textContent = "";
        refs.rewardInfo.classList.add("hidden");
      }
      if (refs.rewardList) {
        refs.rewardList.innerHTML = "";
        refs.rewardList.classList.add("hidden");
      }
      if (refs.penaltyInfo) {
        refs.penaltyInfo.textContent = "";
        refs.penaltyInfo.classList.add("hidden");
      }
      if (refs.penaltyList) {
        refs.penaltyList.innerHTML = "";
        refs.penaltyList.classList.add("hidden");
      }
    }

    function showRewardList(teamLabel, amount, rewards) {
      if (!refs.rewardInfo || !refs.rewardList) return;
      if (!rewards || !rewards.length) {
        return;
      }
      refs.rewardInfo.textContent = `${teamLabel} nariai gavo po +${amount} ta�ku:`;
      refs.rewardInfo.classList.remove("hidden");
      refs.rewardList.innerHTML = rewards
        .map((r) => `<div class="kq-battle-reward-chip">${escapeHtml(r.name || "žaidėjas")} +${amount}</div>`)
        .join("");
      refs.rewardList.classList.remove("hidden");
    }

    function showPenaltyList(teamLabel, amount, penalties) {
      if (!refs.penaltyInfo || !refs.penaltyList) return;
      if (!penalties || !penalties.length) {
        return;
      }
      const value = Math.abs(amount);
      refs.penaltyInfo.textContent = `${teamLabel} nariai neteko po -${value} ta�ku:`;
      refs.penaltyInfo.classList.remove("hidden");
      refs.penaltyList.innerHTML = penalties
        .map((p) => `<div class="kq-battle-penalty-chip">${escapeHtml(p.name || "žaidėjas")} -${value}</div>`)
        .join("");
      refs.penaltyList.classList.remove("hidden");
    }

    function highlightLastJoin() {
      if (!lastJoin || !wrap) return;
      const node = wrap.querySelector(`.chip[data-team="${lastJoin.team}"][data-chip="${lastJoin.token}"]`);
      if (node) {
        node.classList.add("chip-new");
        setTimeout(() => { node.classList.remove("chip-new"); }, 1400);
      }
      lastJoin = null;
    }

    function triggerScorePulse(teamId, direction) {
      const ref = teamId === "red" ? refs.redScore : refs.blueScore;
      if (!ref) return;
      ref.classList.remove("bump-up", "bump-down");
      void ref.offsetWidth;
      ref.classList.add(direction === "down" ? "bump-down" : "bump-up");
      if (scorePulseTimers[teamId]) clearTimeout(scorePulseTimers[teamId]);
      scorePulseTimers[teamId] = setTimeout(() => {
        ref.classList.remove("bump-up", "bump-down");
      }, 650);
    }

    function launchVictoryBurst(teamId, winnerName) {
      if (!wrap) return;
      const burst = document.createElement("div");
      burst.className = `kq-battle-confetti ${teamId}`;
      burst.innerHTML = `<div class="burst">${escapeHtml(winnerName || "")}</div>`;
      const sparks = 14;
      for (let i = 0; i < sparks; i += 1) {
        const spark = document.createElement("div");
        spark.className = "spark";
        const offsetX = (Math.random() - 0.5) * 220;
        const delay = (Math.random() * 0.3).toFixed(2);
        const size = 8 + Math.random() * 8;
        spark.style.left = `${50 + offsetX / 10}%`;
        spark.style.bottom = `${12 + Math.random() * 10}%`;
        spark.style.width = `${size}px`;
        spark.style.height = `${size}px`;
        spark.style.animationDelay = `${delay}s`;
        burst.appendChild(spark);
      }
      wrap.appendChild(burst);
      setTimeout(() => { try { burst.remove(); } catch {} }, 1500);
    }

    function ensureGlobalPlayersState() {
      const quiz = window.KQuiz || (window.KQuiz = {});
      const st = quiz.state || (quiz.state = {});
      st.players = st.players || {};
      return st.players;
    }

    function ensureGlobalPlayerRecord(player) {
      if (!player) return null;
      const pidRaw = player.id ?? player.originalId;
      const pid = canonicalizeId(pidRaw);
      if (!pid) return null;
      player.id = pid;
      const playersState = ensureGlobalPlayersState();
      let record = playersState[pid];
      if (!record) {
        record = playersState[pid] = {
          id: pid,
          name: player.name || "žaidėjas",
          score: 0,
          nextMilestone: 100,
          avatar: player.avatar || ""
        };
      } else {
        if (player.name && record.name !== player.name) record.name = player.name;
        if (player.avatar && !record.avatar) record.avatar = player.avatar;
      }
      if (record.name) player.name = record.name;
      if (record.avatar && !player.avatar) player.avatar = record.avatar;
      return record;
    }

    function awardPointsToTeam(teamId, amount) {
      const team = members[teamId];
      if (!team || !team.size || !amount) return [];
      const granted = [];
      team.forEach((player) => {
        const record = ensureGlobalPlayerRecord(player);
        if (!record) return;
        const before = Number(record.score) || 0;
        const after = before + amount;
        record.score = after;
        if (player.avatar && !record.avatar) record.avatar = player.avatar;
        if (amount > 0 && record.score >= (record.nextMilestone || 100)) {
          record.nextMilestone = (record.nextMilestone || 100) + 100;
        }
        player.name = record.name || player.name;
        if (record.avatar && !player.avatar) player.avatar = record.avatar;
        try {
          window.KQuiz?.emit?.("scoresChanged", {
            id: record.id,
            before,
            after,
            player: record,
            delta: amount,
            source: ADDON_ID
          });
        } catch (err) {
          console.warn("[chem-team-battle] emit scoresChanged failed", err);
        }
        granted.push({ id: record.id, name: record.name || player.name || "žaidėjas", amount });
      });
      return granted;
    }

    function setStatus(text, tone) {
      if (!refs.status) return;
      refs.status.textContent = text || "";
      refs.status.classList.remove("positive", "warning");
      if (tone === "positive") refs.status.classList.add("positive");
      else if (tone === "warning") refs.status.classList.add("warning");
    }

    function setBanner(text, tone) {
      if (!refs.banner) return;
      if (!text) {
        refs.banner.classList.add("hidden");
        refs.banner.textContent = "";
        refs.banner.classList.remove("positive", "warning");
        return;
      }
      refs.banner.textContent = text;
      refs.banner.classList.remove("hidden", "positive", "warning");
      if (tone === "positive") refs.banner.classList.add("positive");
      else if (tone === "warning") refs.banner.classList.add("warning");
    }

    function startLobby(fromQuiz) {
      stopAllTimers();
      setPhase("lobby");
      attachGuard();   // <-- needed so A/B chat messages are captured
      clearOutcomeDisplay();
      if (!fromQuiz) {
        resetPlayers();
      } else {
        scores.red = 0;
        scores.blue = 0;
        renderTeams();
        renderScores();
      }
      lastScores.red = scores.red;
      lastScores.blue = scores.blue;
      lastJoin = null;
      suddenDeath = false;
      deck = shuffle(ELEMENTS);
      roundIndex = 0;
      current = null;
      caseHintShown = false;
      roundResolved = false;
      lobbyEndsAt = 0;
      if (refs.headerTimer) refs.headerTimer.textContent = "-";
      setBanner('Press "Start Battle" when ready.', "info");
      emitTeamEvent({
        type: "lobbyStart",
        teams: snapshotTeams()
      });
    }


    function finishLobby() {
      if (phase !== "lobby") return;
      stopLobbyTimers();
      if (!visible) return;
      if (members.red.size === 0 && members.blue.size === 0) {
        setStatus("Dar niekas neprisijunge.", "warning");
        lobbyEndsAt = performance.now() + LOBBY_MS;
        updateHeaderTimer();
        lobbyTicker = setInterval(() => {
          if (phase !== "lobby") return;
          updateHeaderTimer();
          if (performance.now() >= lobbyEndsAt) {
            finishLobby();
          }
        }, 250);
        lobbyTimer = setTimeout(finishLobby, LOBBY_MS);
        return;
      }
      startQuiz();
    }

    function stopLobbyTimers() {
      if (lobbyTimer) { clearTimeout(lobbyTimer); lobbyTimer = null; }
      if (lobbyTicker) { clearInterval(lobbyTicker); lobbyTicker = null; }
    }

    function startQuiz() {
      stopAllTimers();
      attachGuard();   // <-- keep guard on for answer checking too
      if (members.red.size === 0 || members.blue.size === 0) {
        setStatus("Reikia žaidėjų abiejose komandose. Paleiskite foje dar karta.", "warning");
        startLobby(false);
        return;
      }
      setPhase("quiz");
      clearOutcomeDisplay();
      renderScores();
      prepareRound();
    }

    function startSuddenDeath() {
      suddenDeath = true;
      roundIndex = MAX_ROUNDS;
      setStatus("Staigi mirtis! Pirmas teisingas simbolis laimi kova!", "warning");
      setBanner("Staigi mirtis � tik 8 sekundes atsakymui!", "warning");
      emitTeamEvent({
        type: "suddenDeath",
        teams: snapshotTeams(),
        round: roundIndex + 1
      });
      prepareRound();
    }

    function prepareRound() {
      if (!suddenDeath && roundIndex >= MAX_ROUNDS) {
        if (scores.red === scores.blue) {
          startSuddenDeath();
          return;
        }
        finishBattle();
        return;
      }
      if (suddenDeath && roundIndex > MAX_ROUNDS) {
        finishBattle();
        return;
      }
      if (deck.length === 0) {
        deck = shuffle(ELEMENTS);
      }
      current = deck.pop();
      caseHintShown = false;
      roundResolved = false;
      const roundTime = suddenDeath ? SUDDEN_DEATH_MS : ROUND_MS;
      questionEndsAt = performance.now() + roundTime;
      emitTeamEvent({
        type: "roundStart",
        round: roundIndex + 1,
        suddenDeath: !!suddenDeath,
        element: current ? { symbol: current.symbol, name: current.name, number: current.number } : null,
        scores: snapshotScores()
      });
      if (refs.elementName) refs.elementName.textContent = current?.name || "?";
      if (refs.elementNumber) refs.elementNumber.textContent = current?.number != null ? String(current.number) : "?";
      if (refs.roundLabel) {
        refs.roundLabel.textContent = suddenDeath ? "Staigi mirtis" : `Ratas ${roundIndex + 1} / ${MAX_ROUNDS}`;
      }
      updateHeaderTimer();
      if (suddenDeath) {
        setStatus("Staigi mirtis! Pirmas komandos narys su teisingu simboliu i�kart laimi.", "warning");
        setBanner("Staigi mirtis � tik 8 sekundes!", "warning");
      } else {
        setStatus(`Ratas ${roundIndex + 1}. Pirmas komandos narys, nusiuntes tikslu simboli, pelno 1 ta�ka.`, null);
        setBanner("", null);
      }
      updateQuestionTimer();
      if (countdownTicker) clearInterval(countdownTicker);
      countdownTicker = setInterval(() => {
        if (phase !== "quiz") return;
        updateQuestionTimer();
        if (performance.now() >= questionEndsAt) {
          handleNoPoint();
        }
      }, 200);
      if (roundTimer) clearTimeout(roundTimer);
      roundTimer = setTimeout(handleNoPoint, roundTime);
    }

    function handleNoPoint() {
      if (phase !== "quiz") return;
      clearQuestionTimers();
      if (roundResolved) return;
      roundResolved = true;
      setBanner(`Laikas baigesi! Ne viena komanda neatspejo simbolio ${current?.symbol}.`, "warning");
      setStatus("�iame rate ta�ku nera. Pasiruo�kite kitam elementui.", "warning");
      emitTeamEvent({
        type: "roundNoPoint",
        round: roundIndex + 1,
        suddenDeath: !!suddenDeath,
        element: current ? { symbol: current.symbol, name: current.name, number: current.number } : null,
        scores: snapshotScores()
      });
      celebrationTimer = setTimeout(() => {
        if (suddenDeath) {
          setStatus("Staigi mirtis tesiasi � kraunamas kitas elementas.", "warning");
          setBanner("Dar nera nugaletojo. Staigi mirtis kartojama!", "warning");
          roundResolved = false;
          prepareRound();
        } else {
          roundIndex += 1;
          prepareRound();
        }
      }, CELEBRATION_MS);
    }

    function clearQuestionTimers() {
      if (roundTimer) { clearTimeout(roundTimer); roundTimer = null; }
      if (countdownTicker) { clearInterval(countdownTicker); countdownTicker = null; }
    }

    function handleCorrect(teamId, msg) {
      if (phase !== "quiz" || !current) return;
      clearQuestionTimers();
      if (roundResolved) return;
      roundResolved = true;
      const prevScore = Number(scores[teamId] || 0);
      const newScore = prevScore + 1;
      scores[teamId] = newScore;
      renderScores();
      const team = TEAMS.find((t) => t.id === teamId);
      const name = getUserName(msg);
      const avatar = getUserAvatar(msg);
      const playerId = canonicalizeId(getUserId(msg));
      triggerScorePulse(teamId, "up");
      launchVictoryBurst(teamId, `${name} � ${current.symbol}`);
      setBanner(`${team?.label || "Komanda"} pelne ta�ka! ${name} atsake ${current.symbol}.`, "positive");
      setStatus(`${name} i�kovojo ta�ka ${team?.label || "komandai"}!`, "positive");
      emitTeamEvent({
        type: "roundPoint",
        teamId,
        round: roundIndex + 1,
        suddenDeath: !!suddenDeath,
        player: { id: playerId, name, avatar: avatar || "" },
        element: current ? { symbol: current.symbol, name: current.name, number: current.number } : null,
        scores: snapshotScores()
      });
      celebrationTimer = setTimeout(() => {
        if (suddenDeath) {
          finishBattle();
        } else {
          roundIndex += 1;
          prepareRound();
        }
      }, CELEBRATION_MS);
    }

    function skipRound() {
      if (phase !== "quiz" || !current) return;
      if (roundResolved) return;
      roundResolved = true;
      clearQuestionTimers();
      setBanner("Vedejas praleido �i elementa.", "warning");
      setStatus("Perjungiame i kita elementa.", "warning");
      emitTeamEvent({
        type: "roundSkip",
        round: roundIndex + 1,
        suddenDeath: !!suddenDeath,
        element: current ? { symbol: current.symbol, name: current.name, number: current.number } : null,
        scores: snapshotScores()
      });
      celebrationTimer = setTimeout(() => {
        if (suddenDeath) {
          roundResolved = false;
          prepareRound();
        } else {
          roundIndex += 1;
          prepareRound();
        }
      }, 1200);
    }

    function finishBattle() {
      setPhase("result");
      detachGuard();
      clearOutcomeDisplay();
      const wasSuddenDeath = suddenDeath;
      suddenDeath = false;
      const redScore = scores.red || 0;
      const blueScore = scores.blue || 0;
      const baseDetail = `Galutinis rezultatas - A komanda: ${redScore}, B komanda: ${blueScore}.`;
      let winningTeamId = null;
      if (redScore > blueScore) winningTeamId = "red";
      else if (blueScore > redScore) winningTeamId = "blue";
      const winningTeam = winningTeamId ? TEAMS.find((t) => t.id === winningTeamId) : null;
      const losingTeamId =
        winningTeamId === "red" ? "blue" : winningTeamId === "blue" ? "red" : null;
      const losingTeam = losingTeamId ? TEAMS.find((t) => t.id === losingTeamId) : null;
      if (refs.resultTitle) {
        if (winningTeam) refs.resultTitle.textContent = `${winningTeam.label} laimejo!`;
        else refs.resultTitle.textContent = "Lygiosios!";
      }
      if (refs.resultDetail) {
        refs.resultDetail.textContent = baseDetail;
      }
      let rewards = [];
      let penalties = [];
      if (winningTeamId) {
        rewards = awardPointsToTeam(winningTeamId, WIN_REWARD);
        penalties =
          losingTeamId ? awardPointsToTeam(losingTeamId, -LOSS_PENALTY) : [];
        if (rewards.length) showRewardList(winningTeam.label, WIN_REWARD, rewards);
        if (penalties.length && losingTeam) {
          showPenaltyList(losingTeam.label, LOSS_PENALTY, penalties);
        }
        if (!rewards.length && !penalties.length) {
          setBanner(`${winningTeam.label} laimejo, bet komanda neturi žaidėjų apdovanojimui.`, "warning");
          setStatus("Patikrinkite komandu sara�us ir bandykite dar karta.", "warning");
          return;
        }
        let detailText = baseDetail;
        if (rewards.length) {
          detailText += ` Kiekvienas ${winningTeam.label} narys gavo +${WIN_REWARD} ta�ku.`;
        }
        if (penalties.length && losingTeam) {
          detailText += ` ${losingTeam.label} nariai prarado -${LOSS_PENALTY} ta�ku.`;
        }
        if (refs.resultDetail) refs.resultDetail.textContent = detailText;
        if (rewards.length && penalties.length && losingTeam) {
          setBanner(`${winningTeam.label} gauna +${WIN_REWARD}, o ${losingTeam.label} praranda -${LOSS_PENALTY}!`, "positive");
          setStatus(`${winningTeam.label} triumfuoja! ${losingTeam.label} nariai nubausti -${LOSS_PENALTY}.`, "positive");
        } else if (rewards.length) {
          setBanner(`${winningTeam.label} gauna po +${WIN_REWARD} tašku!`, "positive");
          setStatus(`${winningTeam.label} triumfuoja! Visi komandos nariai apdovanoti +${WIN_REWARD} taškais.`, "positive");
        } else if (penalties.length && losingTeam) {
          setBanner(`${losingTeam.label} neteko po -${LOSS_PENALTY} tašku.`, "warning");
          setStatus(`${losingTeam.label} nariai prarado po -${LOSS_PENALTY} tašku.`, "warning");
        }
      } else {
        if (refs.resultDetail) {
          refs.resultDetail.textContent = `${baseDetail} Taškai nebuvo išdalinti.`;
        }
        setBanner("Lygiosios taškai nebuvo išdalinti.", "warning");
        setStatus("Kova baigesi lygiosiomis. Paleiskite foje iš naujo, jei norite revanšo.", null);
      }
      emitTeamEvent({
        type: "battleEnd",
        winner: winningTeamId,
        losingTeam: losingTeamId,
        scores: { red: redScore, blue: blueScore },
        suddenDeath: !!wasSuddenDeath,
        rewards: rewards.map(r => ({ id: r.id, name: r.name, amount: r.amount })),
        penalties: penalties.map(p => ({ id: p.id, name: p.name, amount: p.amount })),
        teams: snapshotTeams()
      });
    }

    function handleChat(msg) {
      if (!visible) return false;
      const textRaw = getChatText(msg);
      const trimmed = String(textRaw || "").trim();
      if (!trimmed) return true;
      const userRawId = getUserId(msg);
      const userId = canonicalizeId(userRawId);
      if (!userId) return true;

      if (phase === "lobby") {
        const teamId = parseTeamChoice(trimmed);
        if (!teamId) return true;
        assignToTeam(teamId, userRawId, msg);
        return true;
      }

      if (phase === "quiz") {
        if (!current) return true;
        if (roundResolved) return true;
        if (!userToTeam.has(userId)) return true;
        const attempt = sanitizeSymbol(trimmed);
        if (!attempt) return true;
        if (attempt === current.symbol) {
          handleCorrect(userToTeam.get(userId), msg);
        } else if (attempt.toUpperCase() === current.symbol.toUpperCase()) {
          if (!caseHintShown) {
            caseHintShown = true;
            setStatus(`Letter case matters! Send exactly: ${current.symbol}`, "warning");
          }
        }
        return true;
      }

      return true;
    }

    function assignToTeam(teamId, userId, msg) {
      const team = TEAMS.find((t) => t.id === teamId);
      if (!team) return;
      const canonId = canonicalizeId(userId);
      const prevTeam = userToTeam.get(canonId);
      if (!canonId) return;
      const playersState = ensureGlobalPlayersState();
      const baseName = getUserName(msg);
      const baseAvatar = getUserAvatar(msg) || "";
      const record = ensureGlobalPlayerRecord({ id: canonId, name: baseName, avatar: baseAvatar }) || playersState[canonId];
      const finalName = record?.name || baseName || canonId;
      const finalAvatar = record?.avatar || baseAvatar || "";
      const teamMap = members[teamId];
      const alreadyHere = teamMap.has(canonId);
      if (!alreadyHere && teamMap.size >= TEAM_CAP) {
        setStatus(`${team.label} jau turi ${TEAM_CAP} žaidėjus.`, "warning");
        return;
      }
      const other = teamId === "red" ? "blue" : "red";
      members[other].delete(canonId);
      if (userId && userId !== canonId) members[other].delete(userId);
      const existing = teamMap.get(canonId) || { id: canonId, name: finalName, avatar: finalAvatar };
      existing.name = finalName;
      if (finalAvatar) existing.avatar = finalAvatar;
      existing.originalId = userId;
      existing.dataToken = existing.dataToken || encodeURIComponent(canonId);
      teamMap.set(canonId, existing);
      userToTeam.set(canonId, teamId);
      lastJoin = { team: teamId, token: existing.dataToken };
      renderTeams();
      setStatus(`${finalName} prisijunge prie ${team.label}!`, "positive");
      emitTeamEvent({
        type: alreadyHere ? "teamUpdate" : "teamJoin",
        teamId,
        previousTeam: prevTeam && prevTeam !== teamId ? prevTeam : null,
        player: { id: canonId, name: finalName, avatar: finalAvatar },
        teams: snapshotTeams()
      });
    }

    function escapeHtml(text) {
      return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    }

    function escapeAttr(text) {
      return String(text || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    }

    // Exposed controls
    window.KQ_TeamBattle = window.KQ_TeamBattle || {};
    window.KQ_TeamBattle.start = () => { show(); };
    window.KQ_TeamBattle.stop = () => { hide(); };
    window.KQ_TeamBattle.restart = () => {
      if (visible) startLobby(false);
      else show();
    };

    return {
      id: ADDON_ID,
      name: "Komandu kova",
      description: "�iurovai pasiskirsto i raudona ir melyna komandas ir lenktyniauja atpa�indami cheminiu elementu simbolius.",
      defaultEnabled: false,
      enable() { /* noop - overlay is manual */ },
      disable() { hide(); unmount(); }
    };
  }

  function register() {
    if (!window.KQuiz?.registerAddon) {
      setTimeout(register, 200);
      return;
    }
    try {
      window.KQuiz.registerAddon(factory());
    } catch (err) {
      console.error("[chem-team-battle] register failed", err);
    }
  }

  register();
})();
