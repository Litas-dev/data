/* KQuiz Addon: Starting Soon Chemical Sprint (v2.0)
   - Turns the break overlay into a live mini-game using chemical element symbols
   - First chatter to post the correct symbol (case-sensitive) scores +1 point
   - Shows winner for 5s, cycles questions every 10s while the overlay is active
*/
(function () {
  "use strict";

  const QUESTION_MS = 15000;
  const CELEBRATION_MS = 5000;
  const ADDON_ID = "chemSprintBreak";

  const ELEMENTS = [
    { number: 1, symbol: "H", name: "Vandenilis" },
    { number: 2, symbol: "He", name: "Helis" },
    { number: 3, symbol: "Li", name: "Litis" },
    { number: 4, symbol: "Be", name: "Berilis" },
    { number: 5, symbol: "B", name: "Boras" },
    { number: 6, symbol: "C", name: "Anglis" },
    { number: 7, symbol: "N", name: "Azotas" },
    { number: 8, symbol: "O", name: "Deguonis" },
    { number: 10, symbol: "Ne", name: "Neonas" },
    { number: 11, symbol: "Na", name: "Natris" },
    { number: 12, symbol: "Mg", name: "Magnis" },
    { number: 13, symbol: "Al", name: "Aliuminis" },
    { number: 14, symbol: "Si", name: "Silicis" },
    { number: 15, symbol: "P", name: "Fosforas" },
    { number: 16, symbol: "S", name: "Siera" },
    { number: 17, symbol: "Cl", name: "Chloras" },
    { number: 18, symbol: "Ar", name: "Argonas" },
    { number: 19, symbol: "K", name: "Kalis" },
    { number: 20, symbol: "Ca", name: "Kalcis" },
    { number: 21, symbol: "Sc", name: "Skandis" },
    { number: 22, symbol: "Ti", name: "Titanas" },
    { number: 23, symbol: "V", name: "Vanadis" },
    { number: 24, symbol: "Cr", name: "Chromas" },
    { number: 25, symbol: "Mn", name: "Manganas" },
    { number: 27, symbol: "Co", name: "Kobaltas" },
    { number: 28, symbol: "Ni", name: "Nikelis" },
    { number: 29, symbol: "Cu", name: "Varis" },
    { number: 30, symbol: "Zn", name: "Cinkas" },
    { number: 31, symbol: "Ga", name: "Galis" },
    { number: 32, symbol: "Ge", name: "Germanis" },
    { number: 33, symbol: "As", name: "Arsenas" },
    { number: 34, symbol: "Se", name: "Selenas" },
    { number: 35, symbol: "Br", name: "Bromas" },
    { number: 36, symbol: "Kr", name: "Kriptonas" },
    { number: 37, symbol: "Rb", name: "Rubidis" },
    { number: 38, symbol: "Sr", name: "Stroncis" },
    { number: 39, symbol: "Y", name: "Itris" },
    { number: 40, symbol: "Zr", name: "Cirkonis" },
    { number: 41, symbol: "Nb", name: "Niobis" },
    { number: 42, symbol: "Mo", name: "Molibdenas" },
    { number: 43, symbol: "Tc", name: "Tecnetis" },
    { number: 44, symbol: "Ru", name: "Rutenis" },
    { number: 45, symbol: "Rh", name: "Rodis" },
    { number: 46, symbol: "Pd", name: "Paladis" },
    { number: 47, symbol: "Ag", name: "Sidabras" },
    { number: 48, symbol: "Cd", name: "Kadmis" },
    { number: 49, symbol: "In", name: "Indis" },
    { number: 50, symbol: "Sn", name: "Alavas" },
    { number: 51, symbol: "Sb", name: "Stibis" },
    { number: 53, symbol: "I", name: "Jodas" },
    { number: 54, symbol: "Xe", name: "Ksenonas" },
    { number: 55, symbol: "Cs", name: "Cezis" },
    { number: 56, symbol: "Ba", name: "Baris" },
    { number: 57, symbol: "La", name: "Lantanas" },
    { number: 58, symbol: "Ce", name: "Ceris" },
    { number: 59, symbol: "Pr", name: "Prazeodimis" },
    { number: 60, symbol: "Nd", name: "Neodimis" },
    { number: 61, symbol: "Pm", name: "Prometis" },
    { number: 62, symbol: "Sm", name: "Samaris" },
    { number: 63, symbol: "Eu", name: "Europis" },
    { number: 64, symbol: "Gd", name: "Gadolinijus" },
    { number: 65, symbol: "Tb", name: "Terbis" },
    { number: 66, symbol: "Dy", name: "Disprosis" },
    { number: 67, symbol: "Ho", name: "Holmis" },
    { number: 68, symbol: "Er", name: "Erbis" },
    { number: 69, symbol: "Tm", name: "Tulijus" },
    { number: 70, symbol: "Yb", name: "Iterbis" },
    { number: 71, symbol: "Lu", name: "Liuticis" },
    { number: 72, symbol: "Hf", name: "Hafnis" },
    { number: 73, symbol: "Ta", name: "Tantalis" },
    { number: 74, symbol: "W", name: "Volframas" },
    { number: 75, symbol: "Re", name: "Renis" },
    { number: 76, symbol: "Os", name: "Osmis" },
    { number: 77, symbol: "Ir", name: "Iridis" },
    { number: 78, symbol: "Pt", name: "Platina" },
    { number: 79, symbol: "Au", name: "Auksas" },
    { number: 80, symbol: "Hg", name: "Gyvsidabris" },
    { number: 81, symbol: "Tl", name: "Talijus" },
    { number: 83, symbol: "Bi", name: "Bizmutas" },
    { number: 84, symbol: "Po", name: "Polonis" },
    { number: 85, symbol: "At", name: "Astatinas" },
    { number: 86, symbol: "Rn", name: "Radonas" },
    { number: 87, symbol: "Fr", name: "Francijus" },
    { number: 88, symbol: "Ra", name: "Radis" },
    { number: 89, symbol: "Ac", name: "Aktinis" },
    { number: 90, symbol: "Th", name: "Toris" },
    { number: 91, symbol: "Pa", name: "Protaktinis" },
    { number: 92, symbol: "U", name: "Uranas" },
    { number: 93, symbol: "Np", name: "Neptunis" },
    { number: 94, symbol: "Pu", name: "Plutonis" },
    { number: 95, symbol: "Am", name: "Americis" },
    { number: 96, symbol: "Cm", name: "Kiuris" },
    { number: 97, symbol: "Bk", name: "Berkelis" },
    { number: 98, symbol: "Cf", name: "Kalifornis" },
    { number: 100, symbol: "Fm", name: "Fermis" },
    { number: 101, symbol: "Md", name: "Mendelevis" },
    { number: 102, symbol: "No", name: "Nobelis" },
    { number: 103, symbol: "Lr", name: "Laurencis" },
    { number: 104, symbol: "Rf", name: "Rezerfordis" },
    { number: 105, symbol: "Db", name: "Dubnis" },
    { number: 106, symbol: "Sg", name: "Syborgis" },
    { number: 107, symbol: "Bh", name: "Boris" },
    { number: 108, symbol: "Hs", name: "Hasis" },
    { number: 109, symbol: "Mt", name: "Meitneris" },
    { number: 111, symbol: "Rg", name: "Rentgenis" },
    { number: 112, symbol: "Cn", name: "Kopernikis" },
    { number: 113, symbol: "Nh", name: "Nihonis" },
    { number: 114, symbol: "Fl", name: "Flerovis" },
    { number: 115, symbol: "Mc", name: "Moskovis" },
    { number: 116, symbol: "Lv", name: "Livermoris" },
    { number: 117, symbol: "Ts", name: "Tenesinas" },
    { number: 118, symbol: "Og", name: "Oganesonas" },
  ];

  function shuffle(list) {
    const arr = list.slice();
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
    }
    return arr;
  }

  function getUserId(msg) {
    return (
      (msg && msg.user && (msg.user.userId || msg.user.uniqueId)) ||
      msg?.uid ||
      msg?.displayName ||
      msg?.nickname ||
      null
    );
  }

  function getUserName(msg) {
    return (
      msg?.displayName ||
      msg?.user?.nickname ||
      msg?.user?.displayName ||
      msg?.user?.profileName ||
      "�aidejas"
    );
  }

  function getUserAvatar(msg) {
    return (
      msg?.profilePicture ||
      msg?.profilePictureUrl ||
      msg?.user?.profilePicture ||
      msg?.user?.profilePictureUrl ||
      ""
    );
  }

  function ensurePlayersState() {
    const quiz = window.KQuiz || (window.KQuiz = {});
    const state = quiz.state || (quiz.state = {});
    state.players = state.players || {};
    return state.players;
  }

  function factory() {
    let mounted = false;
    let wrap = null;
    let styleEl = null;
    let visible = false;
    let pausedMain = false;
    let guardAttached = false;
    let awaiting = false;
    let current = null;
    let deck = [];
    let questionTimer = null;
    let questionCountdownId = null;
    let cooldownTimer = null;
    let roundStartedAt = 0;
    let questionEndsAt = 0;
    let breakLeftSec = 180;
    let breakTickId = null;
    let breakPaused = false;
    let caseHintShown = false;
    const answeredThisRound = new Set();
    const userIdToPlayer = new Map();

    const ctrl = window.KQuiz?.control || {};
    const { pauseMain, resumeFlow, setChatGuard, clearChatGuard } = ctrl;
    const emitEvent = (name, payload) => { try { window.KQuiz?.emit?.(name, payload); } catch (err) { console.warn("[chem-sprint] emit failed", name, err); } };

    const refs = {
      timerValue: null,
      questionName: null,
      questionNumber: null,
      symbolReveal: null,
      status: null,
      winnerCard: null,
      winnerAvatar: null,
      winnerName: null,
      winnerBonus: null,
      questionTimer: null,
      timerPauseBtn: null
    };

    const css = `
.kq-chem-wrap{
  position:fixed;inset:0;z-index:150;
  display:none;align-items:center;justify-content:center;
  background:rgba(9,14,28,.86);backdrop-filter:blur(8px);
  padding:18px;
}
.kq-chem-card{
  width:min(860px,100%);
  border-radius:22px;
  border:1px solid rgba(52,66,110,.65);
  background:linear-gradient(170deg,rgba(10,18,40,.94),rgba(8,12,26,.94));
  box-shadow:0 28px 72px rgba(0,0,0,.55);
  padding:26px;
  display:flex;flex-direction:column;gap:22px;
  color:#e4ebff;
}
.kq-chem-head{
  display:flex;align-items:flex-start;justify-content:space-between;gap:18px;
}
.kq-chem-title-wrap{
  display:flex;flex-direction:column;gap:8px;
  max-width:min(560px,100%);
}
.kq-chem-title{
  font:900 clamp(20px,3.2vw,32px)/1.05 "Segoe UI",system-ui;
  letter-spacing:.6px;color:#f0f4ff;
}
.kq-chem-mini{
  display:inline-flex;align-items:center;gap:6px;
  padding:4px 12px;border-radius:999px;
  background:rgba(44,75,162,.28);color:#9fb9ff;
  font:800 11px/1 "Segoe UI",system-ui;
  text-transform:uppercase;letter-spacing:1.6px;
  width:max-content;
}
.kq-chem-sub{
  font:600 clamp(12px,2vw,15px)/1.45 "Segoe UI",system-ui;
  color:#8fa5d8;
}
.kq-chem-timer{
  min-width:112px;
  padding:14px 20px;
  border-radius:20px;
  background:linear-gradient(140deg,#2246b7,#1fa3ff);
  display:flex;align-items:center;justify-content:center;
  font:900 clamp(28px,5.2vw,44px)/1 "Segoe UI",system-ui;
  color:#f6fbff;
  box-shadow:0 10px 28px rgba(24,86,180,.35);
}
.kq-chem-question{
  border:1px solid rgba(48,62,104,.55);
  border-radius:18px;
  padding:22px 24px;
  background:rgba(13,20,42,.72);
  display:flex;flex-direction:column;align-items:center;gap:14px;
  text-align:center;
}
.kq-chem-label{
  font:700 13px/1 "Segoe UI",system-ui;
  text-transform:uppercase;
  letter-spacing:2px;
  color:#7d8ebb;
}
.kq-chem-element{
  font:900 clamp(28px,6vw,46px)/1.05 "Segoe UI",system-ui;
  display:flex;gap:12px;align-items:flex-end;
}
.kq-chem-number{
  font:800 clamp(16px,3.5vw,24px)/1 "Segoe UI",system-ui;
  color:#6fa8ff;
}
.kq-chem-countdown{
  font:700 14px/1.2 "Segoe UI",system-ui;
  color:#a8b7df;
}
.kq-chem-countdown span{
  font:900 20px/1 "Segoe UI",system-ui;
  color:#ffd54f;
  margin:0 4px;
}
.kq-chem-hint{
  font:600 clamp(11px,2vw,14px)/1.45 "Segoe UI",system-ui;
  color:#96a9d1;
}
.kq-chem-reveal{
  font:800 clamp(26px,5vw,40px)/1.1 "Segoe UI",system-ui;
  color:#ffc857;
  letter-spacing:.08em;
  min-height:40px;
}
.kq-chem-winner{
  display:none;align-items:center;justify-content:center;gap:12px;
}
.kq-chem-winner.shown{
  display:flex;
}
.kq-chem-avatar{
  width:60px;height:60px;border-radius:50%;
  background:#132149;border:1px solid rgba(85,112,191,.5);
  display:flex;align-items:center;justify-content:center;
  font:900 24px/1 "Segoe UI",system-ui;
  color:#dfe7ff;
  overflow:hidden;
  box-shadow:0 10px 22px rgba(0,0,0,.45);
}
.kq-chem-avatar img{
  width:100%;height:100%;object-fit:cover;
}
.kq-chem-winner-text{
  display:flex;flex-direction:column;gap:4px;text-align:left;
}
.kq-chem-winner-name{
  font:800 18px/1.1 "Segoe UI",system-ui;color:#f2f6ff;
}
.kq-chem-winner-bonus{
  font:700 14px/1 "Segoe UI",system-ui;
  color:#57d59a;
}
.kq-chem-status{
  min-height:26px;text-align:center;
  font:700 15px/1.4 "Segoe UI",system-ui;
  color:#9fb3da;
}
.kq-chem-status.positive{color:#4ed690;}
.kq-chem-status.warning{color:#ffb36b;}
.kq-chem-actions{
  display:flex;justify-content:center;gap:12px;flex-wrap:wrap;
}
.kq-chem-btn{
  padding:11px 20px;border-radius:999px;
  border:1px solid rgba(70,94,168,.7);
  background:#16244a;color:#e1e9ff;
  font:800 14px/1 "Segoe UI",system-ui;
  cursor:pointer;transition:transform .15s ease,background .15s ease;
}
.kq-chem-btn:hover{
  transform:translateY(-1px);
  background:#1d2f63;
}
.kq-chem-btn.primary{
  background:#1c78f2;border-color:#3393ff;color:#f7fbff;
}
.kq-chem-btn.primary:hover{
  background:#1a6fe1;
}
@media (max-width:640px){
  .kq-chem-card{padding:18px;}
  .kq-chem-head{flex-direction:column-reverse;align-items:center;}
  .kq-chem-title{text-align:center;}
  .kq-chem-sub{text-align:center;}
  .kq-chem-timer{width:100%;justify-content:center;}
}
`;

    function mount() {
      if (mounted) return;
      styleEl = document.createElement("style");
      styleEl.textContent = css;
      document.head.appendChild(styleEl);

      wrap = document.createElement("div");
      wrap.className = "kq-chem-wrap";
      wrap.innerHTML = `
        <div class="kq-chem-card">
          <div class="kq-chem-head">
            <div class="kq-chem-title-wrap">
              <div class="kq-chem-title">Greit prad\u0117sime</div>
            </div>
            <div class="kq-chem-timer" data-role="timer">03:00</div>
          </div>
          <div class="kq-chem-question">
            <div class="kq-chem-label">Ie\u0161komas elementas</div>
            <div class="kq-chem-element">
              <span class="kq-chem-number" data-role="question-number">#1</span>
              <span data-role="question-name">Vandenilis</span>
            </div>
            <div class="kq-chem-countdown">Laikas atsakyti: <span data-role="question-timer">10</span>s</div>
          </div>
          <div class="kq-chem-winner" data-role="winner-card">
            <div class="kq-chem-avatar" data-role="winner-avatar"></div>
            <div class="kq-chem-winner-text">
              <div class="kq-chem-winner-name" data-role="winner-name"></div>
              <div class="kq-chem-winner-bonus" data-role="winner-bonus"></div>
            </div>
          </div>
          <div class="kq-chem-status" data-role="status">Mini \u017Eaidimas paruo\u0161tas. Laukiame atsakym\u0173!</div>
          <div class="kq-chem-actions">
            <button class="kq-chem-btn primary" data-act="resume">Gr\u012f\u017Eti \u012f \u017Eaidim\u0105</button>
          </div>
        </div>`;
      document.body.appendChild(wrap);

      refs.timerValue = wrap.querySelector("[data-role='timer']");
      refs.questionName = wrap.querySelector("[data-role='question-name']");
      refs.questionNumber = wrap.querySelector("[data-role='question-number']");
      refs.symbolReveal = wrap.querySelector("[data-role='symbol-reveal']");
      refs.status = wrap.querySelector("[data-role='status']");
      refs.winnerCard = wrap.querySelector("[data-role='winner-card']");
      refs.winnerAvatar = wrap.querySelector("[data-role='winner-avatar']");
      refs.winnerName = wrap.querySelector("[data-role='winner-name']");
      refs.winnerBonus = wrap.querySelector("[data-role='winner-bonus']");
      refs.questionTimer = wrap.querySelector("[data-role='question-timer']");
      refs.timerPauseBtn = wrap.querySelector("[data-act='pause-timer']");
      updateBreakTimerDisplay();

      wrap.addEventListener("click", (evt) => {
        const act = evt.target?.getAttribute?.("data-act");
        if (!act) return;
        if (act === "resume") {
          hide();
        } else if (act === "skip") {
          forceNextRound();
        } else if (act === "plus") {
          adjustBreakTime(60);
        } else if (act === "minus") {
          adjustBreakTime(-60);
        } else if (act === "pause-timer") {
          toggleBreakPause();
        }
      });

      document.addEventListener("keydown", onKeyDown, { passive: false });
      mounted = true;
    }

    function unmount() {
      if (!mounted) return;
      stopGame();
      document.removeEventListener("keydown", onKeyDown, { passive: false });
      try { wrap?.remove(); } catch {}
      try { styleEl?.remove(); } catch {}
      wrap = null;
      styleEl = null;
      mounted = false;
    }

    function onKeyDown(e) {
      const raw = e.key || "";
      if (raw === "+" || raw === "=") {
        e.preventDefault();
        if (!visible) show();
        adjustBreakTime(60);
        return;
      }
      if (raw === "-" || raw === "_") {
        e.preventDefault();
        if (!visible) show();
        adjustBreakTime(-60);
        return;
      }
      const key = raw.toLowerCase();
      if (!visible) return;
      if (key === " ") {
        e.preventDefault();
        toggleBreakPause();
        return;
      }
      if (key === "n") {
        e.preventDefault();
        forceNextRound();
        return;
      }
      if (key === "s") {
        e.preventDefault();
        hide();
      }
    }

    function show() {
      if (!mounted) mount();
      if (visible) return;
      if (breakLeftSec <= 0) breakLeftSec = 180;
      breakPaused = false;
      updateBreakTimerDisplay();
      startBreakTimer();
      visible = true;
      wrap.style.display = "flex";
      if (pauseMain && !pausedMain) {
        try { pauseMain(); pausedMain = true; } catch {}
      }
      setStatus("Pertrauka! Pirmas para�es teisinga simboli gauna +1 ta�ka.");
      startGame();
    }

    function hide() {
      if (!visible) return;
      visible = false;
      wrap.style.display = "none";
      stopBreakTimer();
      stopGame();
      if (resumeFlow && pausedMain) {
        try { resumeFlow(); } catch {}
      }
      pausedMain = false;
    }

    function setStatus(text, tone) {
      if (!refs.status) return;
      refs.status.textContent = text || "";
      refs.status.classList.remove("positive", "warning");
      if (tone === "positive") refs.status.classList.add("positive");
      else if (tone === "warning") refs.status.classList.add("warning");
    }

    function setWinnerCardVisible(state) {
      if (!refs.winnerCard) return;
      if (state) refs.winnerCard.classList.add("shown");
      else refs.winnerCard.classList.remove("shown");
    }

    function updateCountdownDisplay() {
      if (!refs.questionTimer) return;
      const remaining = Math.max(0, Math.ceil((questionEndsAt - performance.now()) / 1000));
      refs.questionTimer.textContent = String(remaining);
    }

    function formatBreak(seconds) {
      const total = Math.max(0, Math.floor(seconds));
      const minutes = Math.floor(total / 60);
      const secs = total % 60;
      return `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }

    function refreshPauseButton() {
      if (!refs.timerPauseBtn) return;
      refs.timerPauseBtn.textContent = breakPaused ? "Tęsti laikmatį" : "Pauzė laikmačio";
    }

    function updateBreakTimerDisplay() {
      if (refs.timerValue) {
        refs.timerValue.textContent = formatBreak(breakLeftSec);
      }
      refreshPauseButton();
    }

    function adjustBreakTime(delta) {
      breakLeftSec = Math.max(0, breakLeftSec + delta);
      updateBreakTimerDisplay();
    }

    function stopBreakTimer() {
      if (breakTickId) {
        clearInterval(breakTickId);
        breakTickId = null;
      }
    }

    function startBreakTimer() {
      stopBreakTimer();
      breakTickId = setInterval(() => {
        if (!visible || breakPaused) return;
        if (breakLeftSec > 0) {
          breakLeftSec -= 1;
          updateBreakTimerDisplay();
          if (breakLeftSec === 0) {
            setStatus("Laikmatis baigesi � gri�tame i �aidima.", "warning");
            hide();
          }
        }
      }, 1000);
    }

    function toggleBreakPause() {
      breakPaused = !breakPaused;
      updateBreakTimerDisplay();
      if (visible) {
        setStatus(
          breakPaused ? "Laikmatis sustabdytas. Tęsk su tarpo klavišu." : "Laikmatis paleistas.",
          breakPaused ? "warning" : undefined
        );
      }
    }

    function clearQuestionTimers() {
      if (questionTimer) {
        clearTimeout(questionTimer);
        questionTimer = null;
      }
      if (questionCountdownId) {
        clearInterval(questionCountdownId);
        questionCountdownId = null;
      }
    }

    function stopGame() {
      awaiting = false;
      clearQuestionTimers();
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      detachGuard();
      current = null;
      deck = [];
      answeredThisRound.clear();
      questionEndsAt = 0;
      if (refs.symbolReveal) refs.symbolReveal.textContent = "?";
      if (refs.questionTimer) refs.questionTimer.textContent = "0";
      setWinnerCardVisible(false);
    }

    function startGame() {
      clearQuestionTimers();
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      attachGuard();
      nextRound();
    }

    function forceNextRound() {
      if (!visible) return;
      clearQuestionTimers();
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      awaiting = false;
      roundStartedAt = 0;
      setWinnerCardVisible(false);
      setStatus("Elementas praleistas. Naujas klausimas!", "warning");
      nextRound();
    }

    function drawElement() {
      if (!deck.length) {
        deck = shuffle(ELEMENTS);
      }
      return deck.pop();
    }

    function nextRound() {
      if (!visible) return;
      current = drawElement();
      if (!current) return;
      answeredThisRound.clear();
      caseHintShown = false;
      awaiting = true;
      roundStartedAt = Date.now();
      setWinnerCardVisible(false);
      setStatus("Ira�yk simboli su teisingomis raidemis. Pvz. Na, Cl, He.");
      if (refs.symbolReveal) refs.symbolReveal.textContent = "?";
      if (refs.questionName) refs.questionName.textContent = current.name;
      if (refs.questionNumber) refs.questionNumber.textContent = `#${current.number}`;

      questionEndsAt = performance.now() + QUESTION_MS;
      updateCountdownDisplay();

      clearQuestionTimers();
      questionCountdownId = setInterval(() => {
        updateCountdownDisplay();
        if (performance.now() >= questionEndsAt) {
          clearInterval(questionCountdownId);
          questionCountdownId = null;
        }
      }, 200);
      questionTimer = setTimeout(() => { onQuestionTimeout(); }, QUESTION_MS);
    }

    function onQuestionTimeout() {
      awaiting = false;
      roundStartedAt = 0;
      clearQuestionTimers();
      if (refs.symbolReveal) refs.symbolReveal.textContent = current?.symbol || "?";
      setWinnerCardVisible(false);
      setStatus(`Nieks neatsp\u0117jo. Teisingas simbolis: ${current?.symbol || "?"}`, "warning");
      cooldownTimer = setTimeout(() => { nextRound(); }, CELEBRATION_MS);
    }

    function renderAvatar(node, avatarUrl, name) {
      if (!node) return;
      node.textContent = "";
      if (avatarUrl) {
        node.innerHTML = "";
        const img = document.createElement("img");
        img.src = avatarUrl;
        img.alt = name || "";
        img.referrerPolicy = "no-referrer";
        node.appendChild(img);
      } else {
        const initial = (name || "?").trim().charAt(0).toUpperCase() || "?";
        node.textContent = initial;
      }
    }

    function awardPoint(msg) {
      const players = ensurePlayersState();
      const name = getUserName(msg);
      const avatar = getUserAvatar(msg);
      const userKeyRaw = getUserId(msg) || `chem-${Math.random().toString(36).slice(2, 8)}`;
      const userKey = String(userKeyRaw);

      let playerId = userIdToPlayer.get(userKey);
      if (!playerId) {
        playerId = Object.keys(players).find((pid) => players[pid]?.name === name) || userKey;
        userIdToPlayer.set(userKey, playerId);
      }

      if (!players[playerId]) {
        players[playerId] = { name, score: 0, nextMilestone: 100, avatar: avatar || "" };
      }
      if (avatar && !players[playerId].avatar) {
        players[playerId].avatar = avatar;
      }
      const before = Number(players[playerId].score) || 0;
      const after = before + 2;
      players[playerId].score = after;
      try {
        window.KQuiz?.emit?.("scoresChanged", {
          id: playerId,
          before,
          after,
          player: players[playerId],
          correct: true
        });
      } catch (err) {
        console.warn("[chem-sprint] emit scoresChanged failed", err);
      }
      return { id: playerId, name, avatar: players[playerId].avatar || avatar || "", score: after };
    }

    const guardFn = (msg) => {
      if (!visible || !awaiting || !current) return false;
      const raw = String(msg?.parsedAnswer || msg?.text || "").trim();
      if (!raw) return false;
      const attempt = raw.replace(/\s+/g, "");
      const baseUserKey = getUserId(msg) || `${attempt}-${Math.random().toString(36).slice(2, 6)}`;
      const stableId = String(typeof baseUserKey === "string" && baseUserKey.length <= 30 ? baseUserKey.toLowerCase() : baseUserKey);
      if (answeredThisRound.has(stableId)) return true;
      answeredThisRound.add(stableId);

      const name = getUserName(msg);
      const avatar = getUserAvatar(msg);
      const isCorrect = attempt === current.symbol;
      const elapsedMs = roundStartedAt ? Date.now() - roundStartedAt : null;

      emitEvent("solo:attempt", {
        player: { id: stableId, name, avatar: avatar || "" },
        ok: isCorrect,
        seconds: elapsedMs != null ? Math.max(0, elapsedMs) / 1000 : null,
        attempt,
        correctText: current.symbol,
        element: { symbol: current.symbol, name: current.name, number: current.number }
      });

      if (isCorrect) {
        handleWinner(msg);
      } else if (attempt.toLowerCase() === current.symbol.toLowerCase()) {
        if (!caseHintShown) {
          caseHintShown = true;
          setStatus(`Raid�iu dydis svarbus! Teisingas simbolis: ${current.symbol}`, "warning");
        }
      }
      return true;
    };
    function handleWinner(msg) {
      awaiting = false;
      roundStartedAt = 0;
      clearQuestionTimers();
      if (refs.symbolReveal) refs.symbolReveal.textContent = current?.symbol || "?";
      const award = awardPoint(msg);
      renderAvatar(refs.winnerAvatar, award.avatar, award.name);
      if (refs.winnerName) refs.winnerName.textContent = award.name;
      if (refs.winnerBonus) refs.winnerBonus.textContent = "2 ta�kai";
      setWinnerCardVisible(true);
      setStatus(`${award.name} pa\u0117m\u0117 element\u0105 ir gavo +2 ta\u0161k\u0105!`, "positive");
      cooldownTimer = setTimeout(() => { nextRound(); }, CELEBRATION_MS);
    }

    function attachGuard() {
      if (guardAttached) return;
      if (typeof setChatGuard === "function") {
        try {
          setChatGuard(guardFn);
          guardAttached = true;
        } catch (err) {
          console.warn("[chem-sprint] setChatGuard failed", err);
        }
      }
    }

    function detachGuard() {
      if (!guardAttached) return;
      guardAttached = false;
      if (typeof clearChatGuard === "function") {
        try { clearChatGuard(); } catch (err) { console.warn("[chem-sprint] clearChatGuard failed", err); }
      }
    }

    window.KQ_StartSoonGame = window.KQ_StartSoonGame || {};
    window.KQ_StartSoonGame.show = show;
    window.KQ_StartSoonGame.hide = hide;
    window.KQ_StartSoonGame.skip = forceNextRound;

    return {
      id: ADDON_ID,
      name: "Pradedame netrukus � Elementu sprintas",
      description: "Pertraukos mini �aidimas: kas pirmas iveda elemento simboli, gauna +1 ta�ka.",
      defaultEnabled: true,
      enable() { mount(); },
      disable() { hide(); unmount(); }
    };
  }

  function register() {
    if (window.KQuiz?.registerAddon) {
      try {
        window.KQuiz.registerAddon(factory());
      } catch (err) {
        console.error("[chem-sprint] register failed", err);
      }
    } else {
      setTimeout(register, 200);
    }
  }

  register();
})();


