
/*!
 * KQuiz add-on: Lokatoriaus žemelapis (v2.3.2 locked, right-rail)
 * Recreated after accidental deletion. Restores map mini-game with refreshed Lithuanian UI text.
 */
(function(){
  "use strict";

  if(!window.KQuiz || !KQuiz.registerAddon || !KQuiz.util || !KQuiz.control){
    console.warn("[map-inline] KQuiz core not ready."); return;
  }

  // ---------------------------------------------------------------------------
  // Global lock helpers
  // ---------------------------------------------------------------------------
  const ADDON_ID = "map-inline";

  function acquireLock(id){
    if(!window.KQ_MINI_LOCK){ window.KQ_MINI_LOCK = { held:false, by:null }; }
    if(window.KQ_MINI_LOCK.held && window.KQ_MINI_LOCK.by && window.KQ_MINI_LOCK.by !== id) return false;
    window.KQ_MINI_LOCK.held = true;
    window.KQ_MINI_LOCK.by = id;
    return true;
  }

  function releaseLock(id){
    if(window.KQ_MINI_LOCK && window.KQ_MINI_LOCK.by === id){
      window.KQ_MINI_LOCK.held = false;
      window.KQ_MINI_LOCK.by = null;
    }
  }

  // ---------------------------------------------------------------------------
  // Config
  // ---------------------------------------------------------------------------
  const cfg = {
    revealHoldMs: 1200,
    questions: 5,
    secPerQ: 25,
    bonus: 50,
    breakMs: 1200,
    poolLimit: 800,
    imageWidth: 900,
    awardAllPerfect: true
  };

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  let enabled = true;
  let active = false;
  let phase = "idle";
  let qIdx = 0;

  let currentQuestion = null;
  let startMs = 0;
  let hudLeft = null;
  let hudFill = null;
  let hudTick = null;

  let correctKey = "A";
  let options = [];
  let ansCounts = [0,0,0,0];

  const perQ = [];
  const totals = new Map();

  let vipSuppressed = false;

  const { $, shuffle, parseAnswer } = KQuiz.util;
  const { pauseMain, resumeFlow, setChatGuard, clearChatGuard } = KQuiz.control;
  // ---------------------------------------------------------------------------
  // Fetch helpers
  // ---------------------------------------------------------------------------
  async function fetchJSON(url, { timeout = 10000, headers } = {}){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), timeout);
    try{
      const res = await fetch(url, { signal: ctrl.signal, headers: headers || { "Accept":"application/json" } });
      if(!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    }finally{
      clearTimeout(t);
    }
  }

  async function retry(fn, tries=3, base=700){
    let last;
    for(let i=0;i<tries;i++){
      try{
        return await fn();
      }catch(err){
        last = err;
        await new Promise(r=>setTimeout(r, base * Math.pow(2, i)));
      }
    }
    throw last;
  }

  // ---------------------------------------------------------------------------
  // Map data + runtime
  // ---------------------------------------------------------------------------
  const TOPO_URL = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";
  const GEO_URL  = "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson";
  const REST_ALL_URL = "https://restcountries.com/v3.1/all?fields=cca2,cca3,ccn3,name,translations,region,subregion,continents";
  const LAST_GOOD_KEY = "kquiz-map-inline-last-geometry";
  const SVG_NS = "http://www.w3.org/2000/svg";

  const continentOrder = ["Europe","Asia","Africa","NorthAmerica","SouthAmerica","Oceania"];
  const MIN_PLAYABLE_AREA = 1800;
  const MIN_PLAYABLE_DIM  = 34;
  const MICRO_AREA = 160;
  const MICRO_DIM  = 18;

  const mapRuntime = {
    features: [],
    geometrySource: "none",
    byIso: new Map(),
    continentIndex: new Map(),
    availableContinents: [],
    paths: new Map(),
    centroids: new Map(),
    container: null,
    svg: null,
    baseViewBox: null,
    ready: false,
    initPromise: null,
    geometryReady: false,
    projection: null,
    usedIso: new Set(),
    playableIso: new Set(),
    microIso: new Set(),
    nameCache: new Map(),
    metaCache: new Map(),
    lastQuestion: null
  };
  // ---------------------------------------------------------------------------
  // Normalisation helpers
  // ---------------------------------------------------------------------------
  function normalizeIso(value){
    if(!value) return null;
    const v = String(value).trim();
    if(!v || v === "-99") return null;
    if(v.length === 2 || v.length === 3) return v.toUpperCase();
    return null;
  }

  function normalizeNumeric(value){
    if(value === undefined || value === null) return null;
    const v = String(value).trim();
    if(/^(?:\d+)$/.test(v)) return v.padStart(3, "0");
    return null;
  }

  function normalizeContinent(value, region, subregion, continentsArr){
    const source = (value && String(value)) ||
      (Array.isArray(continentsArr) && continentsArr[0]) ||
      (subregion && String(subregion)) ||
      (region && String(region)) || "";
    const low = source.trim().toLowerCase();
    if(!low) return null;
    if(low.includes("europe")) return "Europe";
    if(low.includes("africa")) return "Africa";
    if(low.includes("asia")) return "Asia";
    if(low.includes("south america")) return "SouthAmerica";
    if(low.includes("north america")) return "NorthAmerica";
    if(low.includes("oceania") || low.includes("australia") || low.includes("melanesia") || low.includes("micronesia") || low.includes("polynesia")) return "Oceania";
    if(low.includes("antarctic")) return "Antarctica";
    return null;
  }

  function normalizeIsoKey(value){
    if(value === undefined || value === null) return null;
    let key = String(value).trim();
    if(!key) return null;
    if(/^num[:_]?/i.test(key)){
      const digits = key.replace(/^num[:_]?/i, "");
      return `NUM_${normalizeNumeric(digits) || digits.padStart(3,"0")}`;
    }
    if(/^NUM[:_]?/i.test(key)){
      const digits = key.replace(/^NUM[:_]?/i, "");
      return `NUM_${normalizeNumeric(digits) || digits.padStart(3,"0")}`;
    }
    return key.toUpperCase();
  }

  function getFeatureByKey(key){
    const norm = normalizeIsoKey(key);
    if(!norm) return null;
    return mapRuntime.byIso.get(norm)
      || (norm.startsWith("NUM_") ? mapRuntime.byIso.get(`num:${norm.slice(4)}`) : null)
      || null;
  }

  function isPlayableIso(key){
    const norm = normalizeIsoKey(key);
    if(!norm) return false;
    if(mapRuntime.playableIso.size === 0 && mapRuntime.microIso.size === 0) return true;
    return mapRuntime.playableIso.has(norm) || mapRuntime.microIso.has(norm);
  }
  // ---------------------------------------------------------------------------
  // Local storage helpers
  // ---------------------------------------------------------------------------
  function loadCachedGeometry(){
    try{
      const raw = localStorage.getItem(LAST_GOOD_KEY);
      if(!raw) return null;
      const parsed = JSON.parse(raw);
      if(parsed && Array.isArray(parsed.features)) return parsed.features;
    }catch{}
    return null;
  }

  function storeCachedGeometry(features, source){
    try{
      localStorage.setItem(LAST_GOOD_KEY, JSON.stringify({ source, features }));
    }catch{}
  }
  // ---------------------------------------------------------------------------
  // TopoJSON conversion
  // ---------------------------------------------------------------------------
  function decodeArc(arcs, transform, index){
    const arc = arcs[index < 0 ? ~index : index];
    let x = 0, y = 0;
    const points = [];
    for(const point of arc){
      x += point[0];
      y += point[1];
      if(transform){
        points.push([
          x * transform.scale[0] + transform.translate[0],
          y * transform.scale[1] + transform.translate[1]
        ]);
      }else{
        points.push([x,y]);
      }
    }
    if(index < 0) points.reverse();
    return points;
  }

  function decodePolygon(arcsIdx, topo){
    return arcsIdx.map(ring=>{
      let coords = [];
      ring.forEach((arcIdx,i)=>{
        const pts = decodeArc(topo.arcs, topo.transform, arcIdx);
        coords = coords.concat(i===0 ? pts : pts.slice(1));
      });
      return coords;
    });
  }

  function topoGeometryToGeo(geometry, topo){
    if(!geometry) return null;
    if(geometry.type === "Polygon") return { type: "Polygon", coordinates: decodePolygon(geometry.arcs, topo) };
    if(geometry.type === "MultiPolygon") return { type: "MultiPolygon", coordinates: geometry.arcs.map(poly=>decodePolygon(poly, topo)) };
    if(geometry.type === "GeometryCollection"){
      return { type:"GeometryCollection", geometries: geometry.geometries.map(g=>topoGeometryToGeo(g, topo)).filter(Boolean) };
    }
    if(geometry.type === "Point" || geometry.type === "MultiPoint"){
      const decode = coord=>{
        let x = coord[0], y = coord[1];
        if(topo.transform){
          x = x * topo.transform.scale[0] + topo.transform.translate[0];
          y = y * topo.transform.scale[1] + topo.transform.translate[1];
        }
        return [x,y];
      };
      if(geometry.type === "Point") return { type:"Point", coordinates: decode(geometry.coordinates) };
      return { type:"MultiPoint", coordinates: (geometry.coordinates || []).map(decode) };
    }
    return null;
  }

  function convertTopoToGeo(topo){
    if(!topo || !topo.objects) return [];
    const object = topo.objects.countries || Object.values(topo.objects)[0];
    if(!object) return [];
    const geoms = object.type === "GeometryCollection" ? object.geometries : [object];
    return geoms.map(geom=>{
      const geo = topoGeometryToGeo(geom, topo);
      if(!geo) return null;
      return {
        type: "Feature",
        id: geom.id || geom.properties?.iso_a3 || null,
        properties: geom.properties || {},
        geometry: geo
      };
    }).filter(Boolean);
  }
  // ---------------------------------------------------------------------------
  // Feature normalisation / metadata
  // ---------------------------------------------------------------------------
  function normalizeFeatures(features){
    let anon = 0;
    return features.map(f=>{
      if(!f || !f.geometry) return null;
      const props = f.properties || {};
      const iso3 = normalizeIso(props.ISO_A3 || props.iso_a3 || props.ADM0_A3 || props.adm0_a3 || props.A3);
      const iso2 = normalizeIso(props.ISO_A2 || props.iso_a2 || props.ADM0_A2 || props.adm0_a2 || props.A2);
      const numeric = normalizeNumeric(props.ISO_N3 || props.iso_n3 || props.UN_A3 || props.SU_A3 || props.ADM0_A3_US || props.ADM0_A3_UN || f.id);
      const continent = normalizeContinent(props.CONTINENT || props.continent || props.REGION_UN || props.SUBREGION);
      const name = (props.NAME || props.ADMIN || props.name || props.SOVEREIGNT || props.FORMAL_EN || props.formal_en || "").trim();
      const fallbackId = (iso3 || iso2 || (numeric ? `NUM_${numeric}` : `ANON_${anon++}`)).toUpperCase();
      return {
        type:"Feature",
        id:fallbackId,
        geometry:f.geometry,
        properties:{
          iso2: iso2 || null,
          iso3: iso3 || null,
          numeric: numeric || null,
          continent: continent || null,
          name,
          raw: props || {},
          rawId: f.id || null
        }
      };
    }).filter(Boolean);
  }

  function storeMeta(meta){
    if(!meta) return;
    const entry = {
      iso2: meta.iso2 || null,
      iso3: meta.iso3 || null,
      numeric: meta.numeric || null,
      nameLt: meta.nameLt || null,
      nameCommon: meta.nameCommon || null,
      region: meta.region || "",
      subregion: meta.subregion || "",
      continents: Array.isArray(meta.continents) ? meta.continents : []
    };
    const display = (entry.nameLt || entry.nameCommon || entry.iso3 || entry.iso2 || entry.numeric || "").trim();
    if(entry.iso3){
      const key = entry.iso3.toUpperCase();
      mapRuntime.metaCache.set(key, entry);
      if(display) mapRuntime.nameCache.set(key, display);
    }
    if(entry.iso2){
      const key = entry.iso2.toUpperCase();
      mapRuntime.metaCache.set(key, entry);
      if(display) mapRuntime.nameCache.set(key, display);
    }
    if(entry.numeric){
      const num = String(entry.numeric).padStart(3,"0");
      const key = `NUM_${num}`;
      mapRuntime.metaCache.set(key, entry);
      if(display) mapRuntime.nameCache.set(key, display);
    }
  }

  let metaLoaded = false;
  let metaLoading = null;

  async function ensureMetaCache(){
    if(metaLoaded) return;
    if(metaLoading) return metaLoading;
    metaLoading = (async()=>{
      try{
        const data = await retry(()=>fetchJSON(REST_ALL_URL, { timeout:15000 }), 2, 800);
        if(Array.isArray(data)){
          data.forEach(item=>{
            const iso2 = normalizeIso(item?.cca2);
            const iso3 = normalizeIso(item?.cca3);
            const numeric = normalizeNumeric(item?.ccn3);
            storeMeta({
              iso2,
              iso3,
              numeric,
              nameLt: item?.translations?.lt?.common || null,
              nameCommon: item?.name?.common || null,
              region: item?.region || "",
              subregion: item?.subregion || "",
              continents: item?.continents || []
            });
          });
        }
      }catch(err){
        console.warn("[map-inline] restcountries load failed", err);
      }finally{
        metaLoaded = true;
        metaLoading = null;
      }
    })();
    return metaLoading;
  }
  function getMetaForIso(code, feature){
    const props = feature?.properties || {};
    const candidates = [
      code,
      props.iso3,
      props.iso2,
      props.numeric ? `NUM_${props.numeric}` : null,
      feature?.id,
      props.rawId
    ];
    for(const cand of candidates){
      if(!cand) continue;
      const key = normalizeIsoKey(cand);
      if(!key) continue;
      const meta = mapRuntime.metaCache.get(key);
      if(meta) return meta;
    }
    const fallback = {
      iso2: props.iso2 || null,
      iso3: props.iso3 || null,
      numeric: props.numeric || null,
      nameLt: props.name || props.raw?.NAME || props.raw?.ADMIN || null,
      nameCommon: props.raw?.NAME || props.name || null,
      region: props.raw?.REGION_UN || props.region || "",
      subregion: props.raw?.SUBREGION || props.subregion || "",
      continents: props.continent ? [props.continent] : []
    };
    storeMeta(fallback);
    return fallback;
  }

  async function ensureRestMetadata(features){
    await ensureMetaCache();
    features.forEach((feature, idx)=>{
      const props = feature.properties || {};
      const meta = getMetaForIso(null, feature);
      if(meta){
        if(!props.iso2 && meta.iso2) props.iso2 = meta.iso2;
        if(!props.iso3 && meta.iso3) props.iso3 = meta.iso3;
        if(!props.numeric && meta.numeric) props.numeric = meta.numeric;
        if(!props.name) props.name = meta.nameLt || meta.nameCommon || props.iso3 || props.iso2 || props.numeric || `Šalis ${idx+1}`;
        if(!props.continent){
          props.continent = normalizeContinent(
            props.raw?.CONTINENT || props.raw?.continent,
            meta.region,
            meta.subregion,
            meta.continents
          ) || props.continent;
        }
      }
      if(!props.numeric){
        const guess = normalizeNumeric(feature.id);
        if(guess) props.numeric = guess;
      }
      if(!props.continent){
        props.continent = normalizeContinent(
          props.raw?.CONTINENT || props.raw?.continent || props.raw?.REGION_UN || props.raw?.SUBREGION,
          props.raw?.REGION_UN,
          props.raw?.SUBREGION,
          null
        ) || "World";
      }
      if(!props.iso3){
        const fallback = props.iso2 ? `${props.iso2}X` : (props.numeric ? `N${props.numeric}` : `ID${idx}`);
        props.iso3 = fallback.toUpperCase();
      }
    });
  }

  function buildIsoIndex(features){
    mapRuntime.byIso.clear();
    features.forEach(feature=>{
      const props = feature.properties || {};
      const iso3 = props.iso3 && String(props.iso3).toUpperCase();
      const iso2 = props.iso2 && String(props.iso2).toUpperCase();
      const numeric = props.numeric ? String(props.numeric).padStart(3,"0") : null;
      const fallback = feature.id && feature.id.toString().toUpperCase();
      if(iso3) mapRuntime.byIso.set(iso3, feature);
      if(iso2) mapRuntime.byIso.set(iso2, feature);
      if(numeric){
        mapRuntime.byIso.set(`NUM_${numeric}`, feature);
        mapRuntime.byIso.set(`num:${numeric}`, feature);
      }
      if(fallback) mapRuntime.byIso.set(fallback, feature);
    });
  }

  function refreshAvailableContinents(){
    const primary = continentOrder.filter(cont=>{
      const bucket = mapRuntime.continentIndex.get(cont) || [];
      return bucket.some(key=>isPlayableIso(key));
    });
    const fallback = Array.from(mapRuntime.continentIndex.keys())
      .filter(cont=>cont && cont !== "Antarctica")
      .filter(cont=>{
        const bucket = mapRuntime.continentIndex.get(cont)||[];
        return bucket.some(key=>isPlayableIso(key));
      });
    mapRuntime.availableContinents = primary.length ? primary : fallback;
  }

  function buildContinentIndex(features){
    mapRuntime.continentIndex.clear();
    features.forEach(feature=>{
      const props = feature.properties || {};
      const iso3 = props.iso3 && props.iso3.toUpperCase();
      const iso2 = props.iso2 && props.iso2.toUpperCase();
      const numeric = props.numeric;
      const key = iso3 || iso2 || (numeric ? `NUM_${numeric}` : feature.id);
      if(!key) return;
      const cont = props.continent || "World";
      if(cont === "Antarctica") return;
      if(!mapRuntime.continentIndex.has(cont)) mapRuntime.continentIndex.set(cont, []);
      const bucket = mapRuntime.continentIndex.get(cont);
      if(!bucket.includes(key)) bucket.push(key);
    });
    refreshAvailableContinents();
  }
  // ---------------------------------------------------------------------------
  // Geometry load
  // ---------------------------------------------------------------------------
  async function loadGeometry(){
    if(mapRuntime.geometryReady && mapRuntime.features.length) return mapRuntime.features;
    if(mapRuntime.initPromise) return mapRuntime.initPromise;
    mapRuntime.initPromise = (async()=>{
      let features = [];
      try{
        const topo = await retry(()=>fetchJSON(TOPO_URL, { timeout:15000 }), 2, 1000);
        features = normalizeFeatures(convertTopoToGeo(topo));
        mapRuntime.geometrySource = "topojson";
        storeCachedGeometry(features, mapRuntime.geometrySource);
      }catch(errTopo){
        try{
          const geo = await retry(()=>fetchJSON(GEO_URL, { timeout:15000 }), 2, 1000);
          features = normalizeFeatures(geo.features || []);
          mapRuntime.geometrySource = "geojson";
          storeCachedGeometry(features, mapRuntime.geometrySource);
        }catch(errGeo){
          const cached = loadCachedGeometry();
          if(cached && cached.length){
            features = cached;
            mapRuntime.geometrySource = "cache";
          }else{
            throw errGeo;
          }
        }
      }
      mapRuntime.features = features;
      await ensureRestMetadata(features);
      buildIsoIndex(features);
      buildContinentIndex(features);
      mapRuntime.geometryReady = true;
      return features;
    })().finally(()=>{ mapRuntime.initPromise = null; });
    return mapRuntime.initPromise;
  }
  // ---------------------------------------------------------------------------
  // SVG rendering helpers
  // ---------------------------------------------------------------------------
  function ensureBaseStyles(){
    if(document.getElementById("kq-map-inline-styles")) return;
    const style = document.createElement("style");
    style.id = "kq-map-inline-styles";
    style.textContent = `
      .kq-map-inline{position:relative;display:flex;align-items:center;justify-content:center;width:100%;height:100%;}
      .kq-map-inline svg{width:100%;height:100%;display:block;}
      .kq-map-inline path{fill:#1a2443;stroke:#0a1225;stroke-width:.45;transition:fill .25s ease,opacity .25s ease,stroke-width .25s ease;}
      .kq-map-inline path.dimmed{opacity:.12;pointer-events:none;}
      .kq-map-inline path.focused{fill:#ffd54f;stroke:#000;stroke-width:1.4;opacity:1;filter:drop-shadow(0 0 6px rgba(0,0,0,.55));}
    `;
    document.head.appendChild(style);
  }

  function ensureContainer(container){
    container.classList.add("kq-map-inline");
    ensureBaseStyles();
  }

  function computeProjection(features){
    let minLon=Infinity, maxLon=-Infinity, minLat=Infinity, maxLat=-Infinity;
    const visit = geom=>{
      if(!geom) return;
      if(geom.type === "Polygon"){
        geom.coordinates.forEach(ring=>{
          ring.forEach(([lon,lat])=>{
            if(!Number.isFinite(lon) || !Number.isFinite(lat)) return;
            minLon=Math.min(minLon,lon); maxLon=Math.max(maxLon,lon);
            minLat=Math.min(minLat,lat); maxLat=Math.max(maxLat,lat);
          });
        });
      }else if(geom.type === "MultiPolygon"){
        geom.coordinates.forEach(poly=>poly.forEach(ring=>ring.forEach(([lon,lat])=>{
          if(!Number.isFinite(lon) || !Number.isFinite(lat)) return;
          minLon=Math.min(minLon,lon); maxLon=Math.max(maxLon,lon);
          minLat=Math.min(minLat,lat); maxLat=Math.max(maxLat,lat);
        })));
      }else if(geom.type === "GeometryCollection" && Array.isArray(geom.geometries)){
        geom.geometries.forEach(visit);
      }
    };
    features.forEach(f=>visit(f.geometry));
    if(!Number.isFinite(minLon) || !Number.isFinite(minLat)){
      minLon=-180; maxLon=180; minLat=-90; maxLat=90;
    }
    const width=maxLon-minLon;
    const height=maxLat-minLat;
    const baseWidth=960;
    const scale=baseWidth/width;
    const project=(lon,lat)=>{
      const x=(lon-minLon)*scale;
      const y=(maxLat-lat)*scale;
      return {x,y};
    };
    return {project,width:baseWidth,height:height*scale};
  }

  function polygonToPath(polygon, project){
    return polygon.map(ring=>{
      if(!ring.length) return "";
      const cmds = ring.map(([lon,lat],idx)=>{
        const {x,y} = project(lon,lat);
        return `${idx===0?"M":"L"}${x.toFixed(2)},${y.toFixed(2)}`;
      }).join("");
      return cmds + "Z";
    }).join("");
  }

  function geometryToPath(geometry, project){
    if(!geometry) return "";
    if(geometry.type === "Polygon") return polygonToPath(geometry.coordinates, project);
    if(geometry.type === "MultiPolygon") return geometry.coordinates.map(poly=>polygonToPath(poly, project)).join("");
    if(geometry.type === "GeometryCollection") return geometry.geometries.map(g=>geometryToPath(g, project)).join("");
    return "";
  }

  function createSvg(container){
    ensureContainer(container);
    const {project,width,height} = computeProjection(mapRuntime.features);
    mapRuntime.projection = project;
    container.innerHTML="";
    const svg=document.createElementNS(SVG_NS,"svg");
    const baseViewBox=`0 0 ${width.toFixed(2)} ${height.toFixed(2)}`;
    svg.setAttribute("viewBox",baseViewBox);
    svg.setAttribute("preserveAspectRatio","xMidYMid meet");
    const g=document.createElementNS(SVG_NS,"g");
    svg.appendChild(g);
    mapRuntime.paths.clear();
    mapRuntime.centroids.clear();
    mapRuntime.playableIso.clear();
    mapRuntime.microIso.clear();

    mapRuntime.features.forEach(feature=>{
      const props = feature.properties || {};
      const iso3 = props.iso3 && props.iso3.toUpperCase();
      const iso2 = props.iso2 && props.iso2.toUpperCase();
      const numeric = props.numeric;
      const key = iso3 || iso2 || (numeric ? `NUM_${numeric}` : feature.id);
      if(!key) return;

      const path=document.createElementNS(SVG_NS,"path");
      const d = geometryToPath(feature.geometry, project);
      if(!d) return;
      path.setAttribute("d", d);
      path.dataset.iso = key;
      g.appendChild(path);
      mapRuntime.paths.set(key, path);
      try{
        const box = path.getBBox();
        if(Number.isFinite(box.x) && Number.isFinite(box.width)){
          const area = box.width * box.height;
          const maxDim = Math.max(box.width, box.height);
          const norm = normalizeIsoKey(key);
          if(area >= MIN_PLAYABLE_AREA || maxDim >= MIN_PLAYABLE_DIM){
            mapRuntime.playableIso.add(norm);
          }else if(area >= MICRO_AREA || maxDim >= MICRO_DIM){
            mapRuntime.microIso.add(norm);
          }else{
            mapRuntime.microIso.add(norm);
          }
        }
      }catch{}
    });

    container.appendChild(svg);
    mapRuntime.svg = svg;
    mapRuntime.container = container;
    mapRuntime.baseViewBox = baseViewBox;
    mapRuntime.ready = true;

    const updateCentroids = ()=>{
      mapRuntime.paths.forEach((path, iso)=>{
        try{
          const box = path.getBBox();
          if(Number.isFinite(box.x) && Number.isFinite(box.y)){
            mapRuntime.centroids.set(iso, {x:box.x+box.width/2, y:box.y+box.height/2});
          }
        }catch{}
      });
    };
    updateCentroids();
    requestAnimationFrame(updateCentroids);
    refreshAvailableContinents();
  }
  // ---------------------------------------------------------------------------
  // Overlay initialisation
  // ---------------------------------------------------------------------------
  async function initOnlineMapAddon(container){
    if(!container) return;
    const needsRender = !mapRuntime.ready || mapRuntime.container !== container || !container.querySelector("svg");
    if(!needsRender){
      spotlight(null, null);
      return;
    }
    ensureContainer(container);
    container.innerHTML = `<div class="kq-map-loading" style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;min-height:220px;font-weight:700;color:#9fb7ff">Kraunama... žemėlapio duomenys...</div>`;
    try{
      const features = await loadGeometry();
      if(!features || !features.length) throw new Error("empty geometry");
      createSvg(container);
      if(mapRuntime.lastQuestion){
        spotlight(mapRuntime.lastQuestion.continent, mapRuntime.lastQuestion.target);
      }else{
        spotlight(null, null);
      }
    }catch(err){
      console.warn("[map-inline] initOnlineMapAddon failed", err);
      container.innerHTML = `<div class="kq-map-error" style="padding:18px;text-align:center;font-weight:700;color:#ff8489">Nepavyko įkelti žemėlapio.</div>`;
      throw err;
    }
  }

  function unmountOverlay(){ document.getElementById("kq-map-overlay")?.remove(); }

  function mountOverlay(){
    unmountOverlay();
    const overlay = document.createElement("div");
    overlay.id = "kq-map-overlay";
    overlay.style.cssText = "position:fixed;inset:0;z-index:10040;background:rgba(7,10,20,.88);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:18px";
    overlay.innerHTML = `
      <div class="kq-shell" style="width:min(1180px,100%);max-height:94vh;overflow:hidden;border-radius:18px;border:1px solid #273149;background:#0b1124;box-shadow:0 28px 66px rgba(0,0,0,.55);display:flex;flex-direction:column">
        <div class="kq-top" style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid #1d273a;gap:18px">
          <div style="display:flex;flex-direction:column;gap:2px">
            <div style="font-size:20px;font-weight:800;letter-spacing:.4px;color:#edf2ff">Lokatoriaus žemėlapis</div>
            <div style="font-size:13px;color:#7f8fb9">Surask šalį greičiau nei kiti ir laimėk papildomus taškus.</div>
          </div>
          <div style="display:flex;align-items:center;gap:16px">
            <div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px">
              <div style="font-size:11px;font-weight:700;color:#7f8fb9;text-transform:uppercase;letter-spacing:.6px">Laikas</div>
              <div style="display:flex;align-items:center;gap:12px">
                <div id="kq-left" style="font-size:26px;font-weight:800;color:#ffd54f">${cfg.secPerQ}</div>
                <div style="width:180px;height:6px;border-radius:999px;background:#1a2747;overflow:hidden">
                  <div id="kq-fill" style="width:0%;height:100%;background:linear-gradient(90deg,#3ddcff,#00a5ff)"></div>
                </div>
              </div>
            </div>
            <button id="kq-close" type="button" style="width:36px;height:36px;border-radius:50%;border:1px solid #2a365f;background:#121a35;color:#d2dcff;font-size:18px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .2s ease">×</button>
          </div>
        </div>
        <div class="kq-body" style="flex:1;display:flex;flex-direction:column;padding:18px;gap:18px;overflow:hidden">
          <div id="kq-live" style="display:none;flex-direction:column;gap:22px;align-items:stretch;flex:1;overflow:hidden">
            <div id="kq-media" style="background:#0f1730;border:1px solid #243251;border-radius:16px;min-height:320px;height:clamp(320px,45vw,460px);width:100%;display:flex;align-items:center;justify-content:center;padding:12px;overflow:hidden;flex:0 0 auto"></div>
            <div style="display:flex;flex-direction:column;gap:12px;width:100%;flex:0 0 auto">
              <div style="font-size:16px;font-weight:700;color:#dce6ff">Pasirink atsakymą</div>
              <div id="kq-ans" style="display:flex;flex-direction:column;gap:10px;overflow:auto;padding-right:4px"></div>
            </div>
          </div>
          <div id="kq-break" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;padding:12px;text-align:center">
            <div id="kq-break-msg" style="font-size:18px;font-weight:700;color:#dce6ff;max-width:640px"></div>
            <button id="kq-next" type="button" style="min-width:180px;border-radius:999px;border:1px solid #2a365f;background:#1a2b52;color:#e2ebff;font-weight:800;padding:12px 36px;font-size:15px;cursor:pointer;transition:background .2s ease">Pradėti</button>
          </div>
        </div>
        <audio id="tickAudio" preload="auto" style="display:none"></audio>
      </div>`;
    document.body.appendChild(overlay);
    const closeBtn = overlay.querySelector("#kq-close");
    if(closeBtn){
      closeBtn.addEventListener("click", ()=>{ hardClose(); });
    }
  }
  // ---------------------------------------------------------------------------
  // HUD
  // ---------------------------------------------------------------------------
  function setHud(sec){
    if(hudLeft) hudLeft.textContent=String(Math.max(0,sec));
    const t=cfg.secPerQ;
    const pct=t?(100*(t-sec)/t):0;
    if(hudFill) hudFill.style.width=pct+"%";
  }

  function startHud(){
    const endAt=performance.now()+cfg.secPerQ*1000;
    hudLeft=$("#kq-left"); hudFill=$("#kq-fill"); setHud(cfg.secPerQ);
    try{ $("#tickAudio")?.play(); }catch{}
    if(hudTick) clearInterval(hudTick);
    hudTick=setInterval(()=>{
      const left=Math.max(0,Math.ceil((endAt-performance.now())/1000));
      setHud(left);
      if(left<=0){ clearInterval(hudTick); hudTick=null; reveal(); }
    },200);
  }

  function stopHud(){
    try{ $("#tickAudio")?.pause(); }catch{}
    if(hudTick){ clearInterval(hudTick); hudTick=null; }
  }

  // ---------------------------------------------------------------------------
  // Zoom helpers
  // ---------------------------------------------------------------------------
  function autoZoom(continent){
    if(!mapRuntime.svg) return;
    const list = mapRuntime.continentIndex.get(continent)||[];
    if(!list.length){
      if(mapRuntime.baseViewBox) mapRuntime.svg.setAttribute("viewBox", mapRuntime.baseViewBox);
      return;
    }
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    list.forEach(iso=>{
      const path = mapRuntime.paths.get(iso);
      if(!path) return;
      try{
        const box = path.getBBox();
        if(!Number.isFinite(box.x) || !Number.isFinite(box.y)) return;
        minX=Math.min(minX, box.x);
        minY=Math.min(minY, box.y);
        maxX=Math.max(maxX, box.x+box.width);
        maxY=Math.max(maxY, box.y+box.height);
      }catch{}
    });
    if(!Number.isFinite(minX) || !Number.isFinite(minY)) return;
    const padX=(maxX-minX)*0.12;
    const padY=(maxY-minY)*0.12;
    const viewBox=`${Math.max(0,minX-padX).toFixed(2)} ${Math.max(0,minY-padY).toFixed(2)} ${(maxX-minX+padX*2).toFixed(2)} ${(maxY-minY+padY*2).toFixed(2)}`;
    mapRuntime.svg.setAttribute("viewBox", viewBox);
  }

  function focusOnTarget(targetKey){
    if(!mapRuntime.svg || !targetKey) return false;
    const key = normalizeIsoKey(targetKey);
    const path = key && mapRuntime.paths.get(key);
    if(!path) return false;
    try{
      const box = path.getBBox();
      if(!Number.isFinite(box.x) || !Number.isFinite(box.y)) return false;
      let minX = box.x;
      let minY = box.y;
      let width = box.width;
      let height = box.height;
      const isTiny = mapRuntime.microIso.has(key) || width * height <= MIN_PLAYABLE_AREA;
      const minSpan = isTiny ? 28 : 72;
      if(width < minSpan){
        const delta = (minSpan - width) / 2;
        minX -= delta;
        width = minSpan;
      }
      if(height < minSpan){
        const delta = (minSpan - height) / 2;
        minY -= delta;
        height = minSpan;
      }
      const aspėct = width && height ? width/height : 1;
      if(aspėct > 3){
        const targetHeight = width/2;
        const extra = Math.max(0, targetHeight - height)/2;
        minY -= extra;
        height = targetHeight;
      }
      const padX = Math.max(width * (isTiny ? 0.32 : 0.40), isTiny ? 18 : 45);
      const padY = Math.max(height * (isTiny ? 0.32 : 0.48), isTiny ? 18 : 60);
      const viewBox = `${Math.max(0, minX - padX).toFixed(2)} ${Math.max(0, minY - padY).toFixed(2)} ${(width + padX * 2).toFixed(2)} ${(height + padY * 2).toFixed(2)}`;
      mapRuntime.svg.setAttribute("viewBox", viewBox);
      return true;
    }catch(err){
      console.warn("[map-inline] focusOnTarget failed", err);
      return false;
    }
  }

  function spotlight(continentName, targetISO){
    const list = mapRuntime.continentIndex.get(continentName) || [];
    const hasContinent = !!continentName && list.length > 0;
    const target = normalizeIsoKey(targetISO);
    mapRuntime.paths.forEach((path, iso)=>{
      if(!hasContinent){
        path.classList.remove("dimmed");
        path.classList.remove("focused");
        return;
      }
      if(list.indexOf(iso) === -1){
        if(!path.classList.contains("dimmed")) path.classList.add("dimmed");
        path.classList.remove("focused");
        return;
      }
      path.classList.remove("dimmed");
      if(target && iso === target) path.classList.add("focused");
      else path.classList.remove("focused");
    });
    let focused = false;
    if(target){
      focused = focusOnTarget(target);
    }
    if(!focused){
      if(hasContinent) autoZoom(continentName);
      else if(mapRuntime.baseViewBox && mapRuntime.svg){ mapRuntime.svg.setAttribute("viewBox", mapRuntime.baseViewBox); }
    }
    mapRuntime.lastQuestion = { continent: hasContinent ? continentName : null, target: target || null };
  }
  // ---------------------------------------------------------------------------
  // Avatars rail
  // ---------------------------------------------------------------------------
  function makeAvatar(url,name){
    if(url){
      const img=document.createElement("img");
      img.src=url;
      img.referrerPolicy="no-referrer";
      img.style.cssText="width:28px;height:28px;border-radius:50%;object-fit:cover;border:1px solid #2a365f;box-shadow:0 2px 6px rgba(0,0,0,.3);flex:0 0 28px";
      img.alt=name||"";
      img.className="kq-av kquiz-avatar";
      return img;
    }
    const d=document.createElement("div");
    d.textContent=(name||"?").trim().charAt(0).toUpperCase()||"Ž";
    d.style.cssText="width:28px;height:28px;border-radius:50%;background:#1b2544;color:#cfe0ff;display:flex;align-items:center;justify-content:center;font-weight:900;border:1px solid #2a365f;flex:0 0 28px";
    d.className="kq-av";
    return d;
  }

  function addToRail(idx, avatarUrl, name, uid){
    const rail=document.querySelector(`#kq-ans .choice[data-idx="${idx}"] .rail`);
    if(!rail) return;
    if(uid){
      const exists = rail.querySelector(`[data-uid="${uid}"]`);
      if(exists) return;
    }
    ansCounts[idx]=(ansCounts[idx]||0)+1;
    const count=ansCounts[idx];
    let more=rail.querySelector(".more-bubble");
    if(!more){
      more=document.createElement("div");
      more.className="more-bubble";
      more.style.cssText="display:none;width:28px;height:28px;border-radius:50%;background:#1b2a4a;color:#cfe0ff;display:flex;align-items:center;justify-content:center;font-weight:800;border:1px solid #2a365f;flex:0 0 28px";
      rail.appendChild(more);
    }
    if(count<=5){
      const av = makeAvatar(avatarUrl,name);
      try{
        if(uid && av) av.dataset.uid = uid;
        if(av) av.setAttribute("data-name", name||"");
      }catch{}
      rail.insertBefore(av, more);
      more.style.display="none";
    }else{
      more.textContent="+"+(count-5);
      more.style.display="flex";
    }
  }

  // ---------------------------------------------------------------------------
  // Options rendering
  // ---------------------------------------------------------------------------
  function renderOptions(opts){
    const keys = ["A","B","C","D"];
    const list = $("#kq-ans"); if(!list) return;
    list.innerHTML=""; ansCounts=[0,0,0,0];
    opts.forEach((text,i)=>{
      const row=document.createElement("div");
      row.className="choice";
      row.dataset.idx=String(i);
      row.style.cssText="display:grid;grid-template-columns:48px minmax(0,1fr) minmax(150px,42%);align-items:center;gap:8px;border:1px solid #263154;background:#0d1327;border-radius:14px;padding:10px 12px;height:44px;min-height:44px";
      row.innerHTML = `
        <div class="key" style="width:28px;height:28px;border-radius:8px;background:#1a2443;display:flex;align-items:center;justify-content:center;font-weight:900">${keys[i]}</div>
        <div class="txt" style="font-weight:700;color:#e4ecff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></div>
        <div class="rail" style="display:flex;align-items:center;gap:6px;flex-wrap:nowrap;justify-content:flex-end;min-width:150px;max-width:100%;overflow:hidden;white-space:nowrap;contain:layout paint style;transform:translateZ(0)"></div>`;
      const txtEl = row.querySelector(".txt"); if(txtEl) txtEl.textContent = text || "???";
      list.appendChild(row);
    });
  }

  function presentQuestionMap(question){
    if(!question || !mapRuntime.ready || !mapRuntime.paths.size) return;
    requestAnimationFrame(()=>{
      spotlight(question.continent || null, question.targetIso || null);
    });
  }

  // ---------------------------------------------------------------------------
  // Display names
  // ---------------------------------------------------------------------------
function getDisplayName(feature){
  if(!feature) return "???";
  const props = feature.properties || {};
  const keys = [
    props.iso3 && props.iso3.toUpperCase(),
    props.iso2 && props.iso2.toUpperCase(),
    props.numeric ? `NUM_${String(props.numeric).padStart(3,"0")}` : null,
    feature.id ? String(feature.id).toUpperCase() : null
  ];
  for(const k of keys){
    const v = k && mapRuntime.nameCache.get(k);
    if(v && String(v).trim()) return String(v).trim(); // reject empty
  }
  const meta = getMetaForIso(null, feature);
  const name = String(
    meta?.nameLt || meta?.nameCommon ||
    props.name || props.raw?.NAME || props.raw?.ADMIN ||
    props.iso3 || props.iso2 || props.numeric || "???"
  ).trim();
  keys.forEach(k => { if(k && name) mapRuntime.nameCache.set(k, name); });
  return name || "???";
}

  function shuffled(list){
    if(!Array.isArray(list)) return [];
    const copy = list.slice();
    const result = shuffle(copy);
    return Array.isArray(result) ? result : copy;
  }

  function playableCount(){
    return mapRuntime.playableIso.size + mapRuntime.microIso.size || mapRuntime.features.length || 1;
  }

  function deriveFeatureKey(feature){
    if(!feature) return null;
    const props = feature.properties || {};
    const rawKey = props.iso3 || props.iso2 || (props.numeric ? `NUM_${props.numeric}` : null) || feature.id;
    return normalizeIsoKey(rawKey);
  }

  async function nextQuestion(requestedContinent){
    await loadGeometry();
    const pickKeysForContinent = cont=>{
      if(!cont) return [];
      const base = mapRuntime.continentIndex.get(cont) || [];
      return base.map(normalizeIsoKey).filter(key=>isPlayableIso(key) && !!getFeatureByKey(key));
    };

    let continent = requestedContinent || null;
    let pool = pickKeysForContinent(continent);
    if(!pool.length){
      const fallback = shuffled(mapRuntime.availableContinents)
        .find(name => (mapRuntime.continentIndex.get(name)||[]).length);
      if(fallback){
        continent = fallback;
        pool = pickKeysForContinent(continent);
      }
    }
    if(!pool.length){
      pool = shuffled(mapRuntime.features.map(deriveFeatureKey).filter(key=>isPlayableIso(key)));
      continent = null;
    }
    if(!pool.length) throw new Error("No countries available for map question");

    let candidatePool = pool.filter(key=>isPlayableIso(key) && !mapRuntime.usedIso.has(normalizeIsoKey(key)));
    if(!candidatePool.length){
      const globalUnused = mapRuntime.features
        .map(deriveFeatureKey)
        .filter(key=>isPlayableIso(key))
        .filter(key=>!mapRuntime.usedIso.has(normalizeIsoKey(key)));
      if(globalUnused.length){
        pool = globalUnused;
        candidatePool = globalUnused;
        continent = null;
      }
    }
    if(!candidatePool.length){
      if(mapRuntime.usedIso.size >= playableCount() - 1){
        mapRuntime.usedIso.clear();
      }
      pool = pool.length ? pool : shuffled(mapRuntime.features.map(deriveFeatureKey).filter(key=>isPlayableIso(key)));
      candidatePool = pool.filter(key=>isPlayableIso(key) && !!getFeatureByKey(key));
    }
    if(!candidatePool.length) throw new Error("No valid candidates for map question");

    const poolShuffled = shuffled(candidatePool);
    const targetKeyRaw = poolShuffled.find(key=>!!getFeatureByKey(key)) || candidatePool.find(key=>!!getFeatureByKey(key));
    if(!targetKeyRaw) throw new Error("Failed to identify target country");
    const targetKey = normalizeIsoKey(targetKeyRaw);
    const targetFeature = getFeatureByKey(targetKey);
    if(!targetFeature) throw new Error("Missing feature for selected country");

    if(mapRuntime.usedIso.size > cfg.poolLimit || mapRuntime.usedIso.size >= playableCount()){
      mapRuntime.usedIso.clear();
    }
    mapRuntime.usedIso.add(targetKey);

    const targetName = getDisplayName(targetFeature);
    const distractors = [];
    const seenKeys = new Set([targetKey]);
    const seenNames = new Set([(targetName||"").toLowerCase()]);

    const ensureCandidate = keyCandidate=>{
      const normKey = normalizeIsoKey(keyCandidate);
      if(!normKey || seenKeys.has(normKey)) return false;
      const feat = getFeatureByKey(normKey);
      if(!feat) return false;
      const label = getDisplayName(feat);
      const lower = (label||"").toLowerCase();
      if(!label || seenNames.has(lower)) return false;
      distractors.push({ key: normKey, feature: feat, name: label });
      seenKeys.add(normKey);
      seenNames.add(lower);
      return true;
    };

    poolShuffled.forEach(key=>{
      if(distractors.length>=3) return;
      ensureCandidate(key);
    });

    if(distractors.length < 3){
      const globalKeys = shuffled(mapRuntime.features.map(deriveFeatureKey).filter(key=>isPlayableIso(key)));
      for(const key of globalKeys){
        if(distractors.length>=3) break;
        ensureCandidate(key);
      }
    }

    const optionStructs = [
      { key: targetKey, feature: targetFeature, name: targetName },
      ...distractors.slice(0,3)
    ];

    const uniqueOptions = [];
    const usedNames = new Set();
    optionStructs.forEach(opt=>{
      const label = (opt.name||"").trim();
      const lower = label.toLowerCase();
      if(!label || usedNames.has(lower)) return;
      usedNames.add(lower);
      uniqueOptions.push(opt);
    });

    if(uniqueOptions.length < 4){
      const extras = shuffled(mapRuntime.features.map(deriveFeatureKey).filter(key=>isPlayableIso(key)));
      for(const key of extras){
        if(uniqueOptions.length >= 4) break;
        const normKey = normalizeIsoKey(key);
        if(!normKey || seenKeys.has(normKey)) continue;
        const feat = getFeatureByKey(normKey);
        if(!feat) continue;
        const label = getDisplayName(feat);
        const lower = (label||"").toLowerCase();
        if(!label || usedNames.has(lower)) continue;
        uniqueOptions.push({ key: normKey, feature: feat, name: label });
        usedNames.add(lower);
        seenKeys.add(normKey);
      }
    }

    if(uniqueOptions.length < 4) throw new Error("Not enough answer options for map question");

    const finalOptions = shuffled(uniqueOptions).slice(0,4);
    const isoOptions = finalOptions.map(opt=>opt.key);
    const labels = finalOptions.map(opt=>opt.name);
    const correctIdx = finalOptions.findIndex(opt=>opt.key === targetKey);
    const keys=["A","B","C","D"];
    return {
      continent: continent && mapRuntime.continentIndex.has(continent) ? continent : null,
      targetIso: targetKey,
      targetName,
      isoOptions,
      options: labels,
      correctKey: keys[correctIdx>=0 ? correctIdx : 0]
    };
  }
  function showIntro(){
    phase="intro";
    const live=$("#kq-live");
    const br=$("#kq-break");
    const msg=$("#kq-break-msg");
    const btn=$("#kq-next");
    const ans=$("#kq-ans");
    const media=$("#kq-media");
    const left=$("#kq-left");
    const fill=$("#kq-fill");
    if(live) live.style.display="none";
    if(br) br.style.display="flex";
    if(ans) ans.innerHTML="";
    if(media) media.innerHTML="";
    if(msg){
      msg.innerHTML = `Mini žaidimas „Lokatoriaus žemėlapis“. Atsakyk į ${cfg.questions} klausimus iš eilės ir nepraleisk teisingo atsakymo. Visi, kurie surinks ${cfg.questions}/${cfg.questions}, gauna +${cfg.bonus} taškų.`;
    }
    if(btn){
      btn.disabled=false;
      btn.textContent="Pradėti";
      btn.onclick=()=>{
        btn.disabled=true;
        showQ();
      };
    }
    if(left) left.textContent=String(cfg.secPerQ);
    if(fill) fill.style.width="0%";
  }

  async function showQ(){
    try{
      $("#kq-live").style.display="flex";
      $("#kq-break").style.display="none";
      phase="play";
      const media = $("#kq-media");
      if(media){ media.innerHTML = ""; }
      await initOnlineMapAddon(media);
      if(!mapRuntime.centroids.size){
        await new Promise(res=>requestAnimationFrame(()=>res()));
      }
      const avail = mapRuntime.availableContinents.length ? mapRuntime.availableContinents : Array.from(mapRuntime.continentIndex.keys());
      if(!avail.length) throw new Error("No continents available");
      const viableContinents = avail.filter(cont=>{
        const bucket = mapRuntime.continentIndex.get(cont)||[];
        return bucket.some(key=>!mapRuntime.usedIso.has(normalizeIsoKey(key)));
      });
      const continentChoices = viableContinents.length ? viableContinents : avail;
      const pickContinent = continentChoices[(Math.random()*continentChoices.length)|0];
      const q = await retry(()=>nextQuestion(pickContinent), 2, 600);
      options = q.options || [];
      correctKey = q.correctKey;
      currentQuestion = q;
      perQ[qIdx-1] = {
        correctKey,
        options:[...options],
        answers:[],
        isoOptions:q.isoOptions||[],
        targetIso:q.targetIso||null,
        continent:q.continent||pickContinent
      };
      renderOptions(options);
      presentQuestionMap(q);

      setChatGuard((msg)=>{
        if(phase!=="play") return false;
        const key = (msg.parsedAnswer || parseAnswer(String(msg.text||"")));
        if(!key) return false;
        const idx=["A","B","C","D"].indexOf(key);
        if(idx<0) return true;
        const name=msg.displayName||msg.user?.nickname||"Žaidejas";
        const uid = (msg.user && (msg.user.userId || msg.user.uniqueId)) || (name||"").toLowerCase();
        const avatar=msg.profilePicture||msg.profilePictureUrl||msg.user?.profilePicture||msg.user?.profilePictureUrl||"";
        const rec = perQ[qIdx-1];
        if(rec.answers.some(a=>a.uid===uid)) return true;
        const ms=performance.now()-startMs;
        const ok = key===correctKey;
        rec.answers.push({uid,name,key,ok,ms,avatar});
        addToRail(idx, avatar, name, uid);
        const agg=totals.get(uid)||{name,corrects:0,totalMs:0,answers:[],avatar};
        if(ok){ agg.corrects++; agg.totalMs+=ms; }
        agg.answers.push({q:qIdx, ms, wrong:!ok});
        if(avatar) agg.avatar=avatar;
        totals.set(uid,agg);
        return true;
      });

      if(media){
        const svg = media.querySelector("svg");
        if(svg) svg.style.opacity = "1";
      }
      startMs=performance.now(); startHud();
    }catch(e){
      console.warn("[map-inline] showQ failed, skipping question", e);
      qIdx++;
      if(qIdx<=cfg.questions){ showQ(); } else { finishEvent(); }
    }
  }

  function reveal(){
    phase="break";
    stopHud();
    clearChatGuard();
    if(currentQuestion){
      spotlight(currentQuestion.continent, currentQuestion.targetIso);
    }
    const keys=["A","B","C","D"];
    const idx=keys.indexOf(correctKey);
    const row=document.querySelector(`#kq-ans .choice[data-idx="${idx}"]`);
    if(row){ row.style.outline="2px solid #2b6b43"; row.classList.add("correct"); }
    $("#kq-break-msg").innerHTML = (qIdx < cfg.questions)
      ? `Teisingas atsakymas: <span class="kudos">${options[idx]}</span>. Paspausk „Kitas klausimas“.`
      : `Teisingas atsakymas: <span class="kudos">${options[idx]}</span>. Paspausk „Baigti“.`
    ;
    const btn = $("#kq-next");
    if(btn){
      btn.textContent = (qIdx < cfg.questions) ? "Kitas klausimas" : "Baigti";
      btn.disabled=true;
    }
    $("#kq-break").style.display="flex";
    setTimeout(()=>{
      if(btn) btn.disabled=false;
      btn.onclick=()=>{ if(qIdx <= cfg.questions) showQ(); else finishEvent(); };
    }, cfg.breakMs);
    qIdx++;
  }
  function resultModal(rows, winners){
    const modal=document.createElement("div");
    modal.id="kq-result-modal";
    modal.style.cssText="position:fixed;inset:0;z-index:10050;background:rgba(5,8,14,.8);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;padding:12px";
    const thQ = Array.from({length: cfg.questions}, (_,i)=>`<th>Q${i+1}</th>`).join("");
    const trs = rows.map((r,i)=>{
      const seq = Array.from({length: cfg.questions}, (_,qi)=>{
        const a = r.answers.find(t=>t.q===qi+1);
        if(!a) return `<td>—</td>`;
        if(a.wrong) return `<td style="color:#ff5964">X</td>`;
        return `<td style="color:#3bd671">${(a.ms/1000).toFixed(2)}s</td>`;
      }).join("");
      const award = winners.some(w=>w.uid===r.uid) ? ` <span style="color:#ffd166">+${cfg.bonus}</span>` : "";
      return `<tr>
        <td>${i+1}</td>
        <td style="display:flex;align-items:center;gap:6px">${r.avatar?`<img src="${r.avatar}" referrerpolicy="no-referrer" style="width:28px;height:28px;border-radius:50%">`:""} ${r.name}</td>
        <td>${r.corrects}</td><td>${(r.totalMs/1000).toFixed(2)}s</td><td>${r.corrects? (r.avg/1000).toFixed(2)+"s":"—"}</td>
        ${seq}
        <td>${award}</td>
      </tr>`;
    }).join("");

    modal.innerHTML = `
      <div style="width:min(1100px,100%);max-height:90vh;overflow:auto;border:1px solid #273149;border-radius:16px;background:#0b1124;box-shadow:0 24px 60px rgba(0,0,0,.5)">
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #1e2a35">
          <div id="kq-winner" style="font-weight:900;letter-spacing:.5px"></div>
          <div><button id="kq-close2" style="cursor:pointer;border:1px solid #2a365f;background:#121a35;color:#cfe0ff;border-radius:999px;padding:8px 12px;font-weight:700">Grįžti į žaidimą</button></div>
        </div>
        <div id="kq-rules" class="sub" style="padding:10px 14px;border-bottom:1px solid #1e2a35"></div>
        <div id="kq-table" style="padding:10px 14px">
          <table style="width:100%;border-collapse:collapse;font-size:13px">
            <thead><tr><th>#</th><th>Žaidėjas</th><th>ŽŪ</th><th>Bendra</th><th>Vid.</th>${thQ}<th>+</th></tr></thead>
            <tbody>${trs||"<tr><td colspan='99'>–</td></tr>"}</tbody>
          </table>
        </div>
      </div>`;
    document.body.appendChild(modal);
    return modal;
  }

  function finishEvent(){
    stopHud(); clearChatGuard();
    spotlight(null, null);
    mapRuntime.lastQuestion = null;
    mapRuntime.usedIso.clear();
    currentQuestion = null;
    const rows=[...totals.entries()].map(([uid,v])=>({
      uid, name:v.name, corrects:v.corrects,totalMs:v.totalMs,
      avg:v.corrects? v.totalMs/v.corrects : 0, avatar:v.avatar||"", answers:v.answers
    })).sort((a,b)=> b.corrects-a.corrects || a.totalMs-b.totalMs);
    let winners = cfg.awardAllPerfect ? rows.filter(r=>r.corrects===cfg.questions) : (rows[0]? [rows[0]] : []);
    if((!winners || winners.length===0) && rows.length){ winners = [rows[0]]; }

    winners.forEach(w=>{
      const pid = Object.keys(KQuiz.state.players||{}).find(pid=>KQuiz.state.players[pid]?.name===w.name) || w.uid;
      const before=(KQuiz.state.players?.[pid]?.score)||0;
      if(!KQuiz.state.players[pid]) KQuiz.state.players[pid]={ name:w.name, score:before, nextMilestone:100, avatar:w.avatar||"" };
      KQuiz.state.players[pid].score=before+cfg.bonus;
      try{ KQuiz.emit("scoresChanged",{ id:pid, before, after:KQuiz.state.players[pid].score, player:KQuiz.state.players[pid], correct:true }); }catch{}
    });

    const modal = resultModal(rows, winners);
    const rules = `Taisyklės: pirma vertinamas teisingų atsakymų skaičius (maks. ${cfg.questions}), tada bendra reakcijos trukmė. ${cfg.awardAllPerfect ? "Visi su 5 iš 5 gauna taškus." : "Tik vienas nugalėtojas."}`;
    $("#kq-rules").textContent = rules;
    $("#kq-winner").innerHTML = (rows.length ? winners.length : 0)
      ? (winners.length>1
         ? `Nugalėtojai (${winners.length}): ${winners.map(w=>`<strong>${w.name}</strong>`).join(", ")} • +${cfg.bonus}`
         : `Nugalėtojas: <strong>${winners[0].name}</strong> • +${cfg.bonus}`)
      : (rows.length? "Nugalėtojas pagal taisykles neišrinktas, priskirtas geriausias pagal reitingą." : "Nėra nugalėtojo.");

    $("#kq-close2").onclick = ()=>{ hardClose(); };
  }

  function hardClose(){
    active=false; phase="idle";
    stopHud(); clearChatGuard();
    spotlight(null, null);
    mapRuntime.usedIso.clear();
    mapRuntime.lastQuestion = null;
    currentQuestion = null;
    try{ document.getElementById("kq-result-modal")?.remove(); }catch{}
    try{ document.getElementById("kq-map-overlay")?.remove(); }catch{}
    try{ resumeFlow(); }catch{}
    releaseLock(ADDON_ID);
    if(vipSuppressed){
      try{ KQuiz.control?.releaseVip?.(ADDON_ID); }catch{}
      vipSuppressed = false;
    }
  }
async function startInline(){
  if(active) return;
  if(!acquireLock(ADDON_ID)){ console.warn("[map-inline] start skipped; another mini active"); return; }
  active = true; phase = "intro"; qIdx = 1;
  mapRuntime.usedIso.clear(); perQ.length = 0; totals.clear();
  currentQuestion = null; mapRuntime.lastQuestion = null;

  if(!vipSuppressed){
    try{ KQuiz.control?.suppressVip?.(ADDON_ID); }catch{}
    vipSuppressed = true;
  }

  try{ pauseMain(); }catch{}
  mountOverlay();

  // ✅ wire the intro screen and CTA
  showIntro();

  // ✅ harden: if something rewrites handlers, keep the CTA alive
  const btn = document.getElementById("kq-next");
  if(btn && !btn._kqBound){
    btn.addEventListener("click", ()=>{
      if(phase === "intro") { showQ(); }
    });
    btn._kqBound = true;
  }
}


  // ---------------------------------------------------------------------------
  // Deterministic trigger on 10/20/30...
  // ---------------------------------------------------------------------------
  let lastBlock = -1;
  function onQuestionEnd(){
    if(!enabled || active) return;
    const rawDone = (KQuiz.state?.session?.done|0);
    let triggerTotal = 0;
    if(rawDone>0 && rawDone % 10 === 0){
      triggerTotal = rawDone;
    }else if((rawDone+1)>0 && (rawDone+1) % 10 === 0){
      triggerTotal = rawDone + 1;
    }
    if(triggerTotal>0){
      const block = Math.floor(triggerTotal/10);
      if (block !== lastBlock) {
        lastBlock = block;
        try { KQuiz.control && KQuiz.control.pauseMain && KQuiz.control.pauseMain(); } catch {}
        setTimeout(() => { startInline(); }, cfg.revealHoldMs || 1200);
      }
    }
  }

  function disable(){
    enabled=false;
    KQuiz.off("questionEnd", onQuestionEnd);
    if(active) hardClose();
  }

  function enable(){
    enabled=true;
    KQuiz.on("questionEnd", onQuestionEnd);
  }

  // ---------------------------------------------------------------------------
  // Register addon
  // ---------------------------------------------------------------------------
  KQuiz.registerAddon({
    id: ADDON_ID,
    name: "Lokatoriaus žemelapis (v2.3.2 locked — right-rail)",
    description: "Avatarai i dešine, fiksuotas aukštis, #10/20/30, mini lock, intro, griežta pauze.",
    defaultEnabled: true,
    enable,
    disable
  });

  window.KQ_MapInline = { start: startInline, close: hardClose, initOnlineMapAddon, spotlight, nextQuestion };
})();
