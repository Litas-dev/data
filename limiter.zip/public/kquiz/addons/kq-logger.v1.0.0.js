﻿/* KQuiz Add-on: Full Activity Logger v1.3.1.max
   - Captures main + minis (money, map, solo, teamBattle)
   - Works with colon and camelCase events
   - Records answers even if question:start was missed (auto-start)
   - Autosave, periodic JSON download, optional webhook, heartbeat
*/
(function(){
  "use strict";

  function waitReady(cb, t0=Date.now()){
    if (window.KQuiz && typeof KQuiz.registerAddon==="function") { cb(); return; }
    if (Date.now()-t0>15000){ console.warn("[kq-logger] core not ready"); return; }
    setTimeout(()=>waitReady(cb,t0),200);
  }
  waitReady(init);
  return;

  function init(){
    const K = KQuiz;

    const ADDON_ID="kq-logger";
    const VERSION="1.3.1.max";
    const DAY_ISO=new Date().toISOString().slice(0,10);
    const LS_KEY=`KQ_LOG_${DAY_ISO}`;
    const now=()=>Date.now();
    const toSec=(msLike)=> msLike==null ? null : +(Number(msLike)/1000).toFixed(3);

    // visible probe
    window.__KQLOG_VER__ = VERSION;
    console.info("[kq-logger] loaded", VERSION);

    const state = {
      meta:{ day:DAY_ISO, startedAt:now(), sessionId:Date.now(), endedAt:null, appVersion:K.version||null, liveMode:!!K.liveMode, addonVersion:VERSION },
      players:{},
      mainGame:{ questions:[], totals:{} },
      miniGames:{
        money:{ questions:[], totals:{} },
        map:{ questions:[], totals:{} },
        solo:{ attempts:[] },
        teamBattle:{ events:[] }
      },
      shares:{ awards:[] },
      scores:{ snapshots:[] },
      raw:{ ring:[], max:1000 },
      sessionMeta:{ events:[] },
      _current:{
        main:{ qid:null, t0:null, options:null, correctKey:null, answered:{} },
        money:{ qid:null, t0:null, answered:{} },
        map:{ qid:null, t0:null, answered:{} },
      },
      _cfg:{ autosaveSec:8, autodlMin:10, enableAutodl:true, webhookUrl:"", rawEnabled:true, heartbeatSec:30 },
      _timers:{ save:null, dl:null, hb:null }
    };

    // restore
    try{
      const ls=localStorage.getItem(LS_KEY);
      if(ls){
        const p=JSON.parse(ls);
        if(p?.meta?.day===DAY_ISO && !p?.meta?.endedAt){
          Object.assign(state,p,{ _current:state._current,_cfg:state._cfg,_timers:state._timers });
          state.meta.sessionId = Date.now();
          state.meta.startedAt = now();
          state.meta.endedAt = null;
          console.info("[kq-logger] restored");
        } else {
          localStorage.removeItem(LS_KEY);
        }
      }
    }catch(e){ console.warn("[kq-logger] restore fail",e); }

    // helpers
    const clone=(o)=>JSON.parse(JSON.stringify(o||null));
    function filename(){
      const t=new Date();
      return `kqlog-${DAY_ISO}-${String(t.getHours()).padStart(2,"0")}${String(t.getMinutes()).padStart(2,"0")}${String(t.getSeconds()).padStart(2,"0")}.json`;
    }
    function blobDownload(name,obj){
      try{
        const b=new Blob([JSON.stringify(obj,null,2)],{type:"application/json"});
        const a=document.createElement("a"); a.href=URL.createObjectURL(b); a.download=name;
        document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},1200);
      }catch(e){ console.warn("[kq-logger] download failed",e); }
    }
    async function postWebhook(url,obj){
      if(!url) return;
      try{ await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},keepalive:true,body:JSON.stringify(obj)}); }
      catch(e){ console.warn("[kq-logger] webhook failed",e); }
    }

    // players
    function markPlayer(p){
      if(!p) return null;
      const id=String(p.id||p.userId||p.uid||p.uniqueId||"").toLowerCase();
      if(!id) return null;
      const ent=state.players[id]||{};
      ent.name = p.name||p.displayName||p.nickname||p.username||ent.name||id;
      ent.avatar = p.avatar||p.picture||p.photo||ent.avatar||"";
      if(!ent.firstSeen) ent.firstSeen = now();
      ent.lastSeen = now();
      if(typeof p.score==="number") ent.finalScore = p.score;
      state.players[id]=ent;
      return id;
    }
    function bumpTotals(totals, uid, ok, secs){
      const t= totals[uid] || {corrects:0, wrongs:0, secOnCorrect:0, answers:0};
      t.answers++;
      if(ok===true){ t.corrects++; if(secs!=null) t.secOnCorrect += secs; }
      else if(ok===false){ t.wrongs++; }
      totals[uid]=t;
    }

    // main
    function mainStart(payload){
      const qid = payload?.qid ?? (state.mainGame.questions.length+1);
      const options = Array.isArray(payload?.options) ? payload.options.slice(0,4) : null;
      const rec = { qid, correctKey: payload?.correctKey ?? null, options, revealedAt: now(), firstAnswer:null, fastestCorrect:null, answers:[] };
      state._current.main={ qid, t0: now(), options, correctKey: rec.correctKey, answered:{} };
      state.mainGame.questions.push(rec);
    }
    function mainAnswer(player,key){
      // synthesize start if missed
      if(!state._current.main.qid){
        const qs = K.state?.question || {};
        const qid = qs.id ?? qs.qid ?? Date.now();
        mainStart({ qid, options: Array.isArray(qs.options)? qs.options.slice(0,4):null, correctKey: qs.correctKey ?? null });
      }
      const cur=state._current.main;
      const uid=markPlayer(player); if(!uid) return;
      if(cur.answered[uid]) return;
      const secs = toSec(now()-cur.t0);
      const ok = cur.correctKey? key===cur.correctKey : null;

      const list=state.mainGame.questions;
      const last=list[list.length-1];
      if(last && last.qid===cur.qid){
        last.answers.push({ userId:uid, key, ok, sec:secs, avatar: state.players[uid].avatar||"" });
        if(!last.firstAnswer) last.firstAnswer={ userId:uid, sec:secs };
        if(ok===true){
          if(!last.fastestCorrect || secs < last.fastestCorrect.sec){
            last.fastestCorrect = { userId:uid, sec:secs };
          }
        }
      }
      bumpTotals(state.mainGame.totals, uid, ok, secs);
      cur.answered[uid]=true;
    }
    function mainCorrect(payload){
      const key = payload?.correctKey ?? null;
      const cur=state._current.main; if(!cur.qid){
        // allow correct to arrive first
        mainStart({ qid: Date.now(), options:null, correctKey:key });
      }
      const list=state.mainGame.questions; const last=list[list.length-1];
      if(last){ last.correctKey = last.correctKey ?? key; }
      state._current.main={ qid:null, t0:null, options:null, correctKey:null, answered:{} };
    }

    // minis
    function miniStart(section, payload){
      state._current[section]={ qid: payload?.qid ?? Date.now(), t0: now(), answered:{} };
      const store = state.miniGames[section];
      store.questions.push({ qid: state._current[section].qid, revealedAt: now(), correctKey:null, options: payload?.options??null, firstAnswer:null, fastestCorrect:null, answers:[] });
    }
    function miniAnswer(section, payload){
      if(!state._current[section]?.qid){
        const live = (K.state?.mini||{})[section] || {};
        miniStart(section, { qid: live.id ?? live.qid ?? Date.now(), options: live.options ?? null });
      }
      const cur=state._current[section];
      const uid=markPlayer(payload?.player); if(!uid) return;
      if(cur.answered[uid]) return;
      const secs = toSec(now()-cur.t0);
      const store = state.miniGames[section];
      const q = store.questions[store.questions.length-1];
      const key = payload?.key ?? payload?.answer ?? payload?.selected ?? null;
      const okExplicit = typeof payload?.ok==="boolean" ? payload.ok : null;
      const ok = okExplicit ?? (q.correctKey ? key===q.correctKey : null);
      q.answers.push({ userId:uid, key, ok, sec:secs, avatar:state.players[uid].avatar||"" });
      if(!q.firstAnswer) q.firstAnswer={ userId:uid, sec:secs };
      if(ok===true){
        if(!q.fastestCorrect || secs < q.fastestCorrect.sec){
          q.fastestCorrect = { userId:uid, sec:secs };
        }
      }
      bumpTotals(store.totals, uid, ok, secs);
      cur.answered[uid]=true;
    }
    function miniEnd(section, payload){
      const cur=state._current[section];
      const store = state.miniGames[section];
      const q = store.questions[store.questions.length-1];
      if(q){ q.correctKey = q.correctKey ?? payload?.correctKey ?? payload?.correct ?? null; }
      state._current[section]={ qid:null, t0:null, answered:{} };
    }

    // solo
    function soloAttempt(payload){
      const uid=markPlayer(payload?.player); if(!uid) return;
      const secs = Math.max(0, Number(payload?.secsTotal ?? payload?.seconds ?? 0));
      state.miniGames.solo.attempts.push({
        userId:uid,
        startedAt: now()-(secs*1000),
        t: payload?.timestamp || now(),
        secsTotal: secs,
        ok: !!payload?.ok,
        correctText: payload?.correctText ?? null,
        correctKey: payload?.correctKey ?? null,
        attemptKey: payload?.attemptKey ?? null,
        attemptText: payload?.attemptText ?? payload?.attempt ?? null,
        scoreDelta: typeof payload?.scoreDelta === "number" ? payload.scoreDelta : null,
        beforeScore: typeof payload?.beforeScore === "number" ? payload.beforeScore : null,
        afterScore: typeof payload?.afterScore === "number" ? payload.afterScore : null,
        question: clone(payload?.question || null),
        reason: payload?.reason || null
      });
    }

    // team
    function teamEvent(ev){
      state.miniGames.teamBattle.events.push(Object.assign({t:now()}, clone(ev||{})));
    }

    function shareAward(payload){
      const player = payload?.player || {};
      const baseId = player.id || payload?.playerId || (payload?.name ? `share:${String(payload.name).toLowerCase()}` : null);
      const marked = markPlayer({
        id: baseId,
        name: player.name || payload?.name || baseId || "share",
        avatar: player.avatar || payload?.avatar || "",
        score: typeof payload?.after === "number" ? payload.after : undefined
      }) || (baseId ? String(baseId).toLowerCase() : null);
      state.shares.awards.push({
        t: payload?.timestamp || now(),
        userId: marked,
        name: player.name || payload?.name || marked,
        points: Number(payload?.points || 0),
        shares: Number(payload?.shares || (payload?.points ? payload.points/2 : 0)),
        rawShares: payload?.rawShares ?? null,
        appliedShares: payload?.appliedShares ?? null,
        totalShares: payload?.totalShares ?? null,
        before: payload?.before ?? null,
        after: payload?.after ?? null,
        capApplied: !!payload?.capApplied,
        messageId: payload?.messageId ?? null,
        raw: clone(payload || null)
      });
    }

    // scores
    function snapshotScores(){
      const snap={t:now(), players:{}};
      const src = K.state?.players || K.players || {};
      Object.keys(src).forEach(id=>{
        const pid=String(id).toLowerCase();
        const p = src[id] || {};
        markPlayer({id:pid, name:p.name||p.nickname||id, avatar:p.avatar||p.picture||"", score:p.score||0});
        snap.players[pid]={ score:p.score||0 };
      });
      state.scores.snapshots.push(snap);
    }

    // raw/meta
    function pushRaw(name,payload){
      if(!state._cfg.rawEnabled) return;
      const R=state.raw.ring, max=state.raw.max;
      R.push({t:now(), name, data: clone(payload||null) });
      if(R.length>max) R.shift();
    }
    function recordMeta(ev){
      state.sessionMeta.events.push(Object.assign({t:now()}, clone(ev||{})));
    }

    // save/dl/hb
    function snapshot(){
      return {
        day: state.meta.day,
        meta: state.meta,
        players: state.players,
        mainGame: state.mainGame,
        miniGames: state.miniGames,
        shares: state.shares,
        scores: state.scores,
        raw: { max: state.raw.max, events: state.raw.ring },
        sessionMeta: { startedAt: state.meta.startedAt, endedAt: state.meta.endedAt||null, events: state.sessionMeta.events }
      };
    }
    function saveLocal(){ try{ localStorage.setItem(LS_KEY, JSON.stringify(snapshot())); }catch(e){ console.warn("[kq-logger] save fail",e); } }
    function scheduleSave(){ if(state._timers.save) clearInterval(state._timers.save); state._timers.save=setInterval(saveLocal, Math.max(3,state._cfg.autosaveSec)*1000); }
    function scheduleDl(){
      if(state._timers.dl) clearInterval(state._timers.dl);
      if(!state._cfg.enableAutodl) return;
      state._timers.dl=setInterval(()=>{ const snap=snapshot(); blobDownload(filename(),snap); postWebhook(state._cfg.webhookUrl,snap); }, Math.max(1,state._cfg.autodlMin)*60*1000);
    }
    function scheduleHeartbeat(){
      if(state._timers.hb) clearInterval(state._timers.hb);
      const s=Math.max(10,state._cfg.heartbeatSec);
      state._timers.hb=setInterval(()=>{ const online=Object.keys(K.state?.players||K.players||{}).length||0; recordMeta({tag:"heartbeat",online}); saveLocal(); }, s*1000);
    }
    scheduleSave(); scheduleDl(); scheduleHeartbeat();

    window.addEventListener("beforeunload",()=>{
      state.meta.endedAt=now();
      const snap=snapshot();
      saveLocal();
      blobDownload(filename(),snap);
      postWebhook(state._cfg.webhookUrl,snap);
    });

    // API
    K.logEvent = function(name,payload){
      try{
        pushRaw(name,payload);
        switch(name){
          case "main:question:start": return mainStart(payload);
          case "main:answer":         return mainAnswer(payload?.player, payload?.key ?? payload?.answer ?? payload?.selected);
          case "main:question:correct": return mainCorrect(payload);

          case "money:start":  return miniStart("money", payload);
          case "money:answer": return miniAnswer("money", payload);
          case "money:end":    return miniEnd("money", payload);

          case "map:start":    return miniStart("map", payload);
          case "map:answer":   return miniAnswer("map", payload);
          case "map:end":      return miniEnd("map", payload);

          case "solo:attempt": return soloAttempt(payload);
          case "share:award":  return shareAward(payload);
          case "team:event":   return teamEvent(payload);
          default: return recordMeta({tag:name, data:payload||null});
        }
      }catch(e){ console.warn("[kq-logger] logEvent error",e); }
    };

    // bus wiring
    if(typeof K.on==="function"){
      try{
        // colon
        K.on("question:start", q=>{ pushRaw("question:start",q); mainStart(q); });
        K.on("answer:submit", a=>{ pushRaw("answer:submit",a); mainAnswer(a?.player, a?.key); });
        K.on("question:correct", q=>{ pushRaw("question:correct",q); mainCorrect(q); });

        K.on("money:start", q=>{ pushRaw("money:start",q); miniStart("money",q); });
        K.on("money:answer", a=>{ pushRaw("money:answer",a); miniAnswer("money",a); });
        K.on("money:end", q=>{ pushRaw("money:end",q); miniEnd("money",q); });

        K.on("map:start", q=>{ pushRaw("map:start",q); miniStart("map",q); });
        K.on("map:answer", a=>{ pushRaw("map:answer",a); miniAnswer("map",a); });
        K.on("map:end", q=>{ pushRaw("map:end",q); miniEnd("map",q); });

        K.on?.("solo:attempt", a=>{ pushRaw("solo:attempt",a); soloAttempt(a); });
        K.on?.("share:award", a=>{ pushRaw("share:award",a); shareAward(a); });
        K.on?.("team:event", e=>{ pushRaw("team:event",e); teamEvent(e); });
        K.on?.("scoresChanged", ()=>{ pushRaw("scoresChanged",null); snapshotScores(); });

        // camelCase compat
        K.on?.("questionStart", q=>{
          const qid = q?.id ?? q?.qid; const options = q?.options ?? q?.opts ?? null;
          mainStart({ qid, options });
        });
        K.on?.("answerSubmit", a=>{
          const key = a?.key ?? a?.answer ?? a?.selected ?? null;
          mainAnswer(a?.player || a?.user, key);
        });
        K.on?.("questionCorrect", q=>{
          const correctKey = q?.correctKey ?? q?.correct ?? K.state?.question?.correctKey ?? null;
          mainCorrect({ correctKey });
        });

        K.on?.("moneyStart", q=>miniStart("money", q));
        K.on?.("moneyAnswer", a=>miniAnswer("money", a));
        K.on?.("moneyEnd", q=>miniEnd("money", q));

        K.on?.("mapStart", q=>miniStart("map", q));
        K.on?.("mapAnswer", a=>miniAnswer("map", a));
        K.on?.("mapEnd", q=>miniEnd("map", q));
      }catch(e){ console.warn("[kq-logger] on wiring fail",e); }
    }

    if(typeof K.emit==="function"){
      const origEmit=K.emit.bind(K);
      K.emit=function(name,payload){
        try{
          pushRaw(name,payload);
          if(name.startsWith("question:")){
            if(name.includes("start")) mainStart(payload);
            if(name.includes("correct")) mainCorrect(payload);
          } else if(name.startsWith("answer:")) {
            mainAnswer(payload?.player, payload?.key ?? payload?.answer ?? payload?.selected);
          } else if(name.startsWith("money:")) {
            if(name.endsWith(":start")) miniStart("money",payload);
            else if(name.endsWith(":answer")) miniAnswer("money",payload);
            else if(name.endsWith(":end")) miniEnd("money",payload);
          } else if(name.startsWith("map:")) {
            if(name.endsWith(":start")) miniStart("map",payload);
            else if(name.endsWith(":answer")) miniAnswer("map",payload);
            else if(name.endsWith(":end")) miniEnd("map",payload);
          } else if(name.startsWith("solo:")) {
            if(name.endsWith(":attempt")) soloAttempt(payload);
          } else if(name.startsWith("share:")) {
            if(name.endsWith(":award")) shareAward(payload);
          } else if(name.startsWith("team:")) {
            teamEvent(payload);
          } else if(name==="scoresChanged"){
            snapshotScores();
          }
          // camelCase
          if(name==="questionStart") mainStart(payload);
          if(name==="answerSubmit")  mainAnswer(payload?.player||payload?.user, payload?.key ?? payload?.answer ?? payload?.selected);
          if(name==="questionCorrect") mainCorrect({ correctKey: payload?.correctKey ?? payload?.correct ?? K.state?.question?.correctKey ?? null });

          if(name==="moneyStart")  miniStart("money", payload);
          if(name==="moneyAnswer") miniAnswer("money", payload);
          if(name==="moneyEnd")    miniEnd("money", payload);

          if(name==="mapStart")    miniStart("map", payload);
          if(name==="mapAnswer")   miniAnswer("map", payload);
          if(name==="mapEnd")      miniEnd("map", payload);

          if(name==="shareAward")  shareAward(payload);
        }catch(e){ console.warn("[kq-logger] emit sniffer error",e); }
        return origEmit(name,payload);
      };
    }

    // safety nets on control paths
    if(K.control){
      if (typeof K.control.submitAnswer==="function"){
        const orig=K.control.submitAnswer.bind(K.control);
        K.control.submitAnswer=function(player,key){
          try{ K.logEvent("main:answer",{player,key}); }catch(_){}
          return orig(player,key);
        };
      }
      if (typeof K.control.revealCorrect==="function"){
        const origR=K.control.revealCorrect.bind(K.control);
        K.control.revealCorrect=function(correctKey){
          try{ K.logEvent("main:question:correct",{correctKey}); }catch(_){}
          return origR(correctKey);
        };
      }
    }

    // settings card
    function mountCard(){
      if(!K.settings || typeof K.settings.registerCard!=="function") return false;
      K.settings.registerCard({
        id:ADDON_ID,
        title:"Daily Log (JSON)",
        badge:"Logger",
        render(el){
          el.innerHTML = `
            <div style="display:flex;flex-direction:column;gap:8px">
              <div>
                Full activity log controls. These options manage autosave, auto-download, and webhooks. Today: <b>${DAY_ISO}</b>.
              </div>
              <label style="display:flex;align-items:center;gap:8px">
                Autosave every <input id="kql_auto_sec" type="number" min="3" value="${state._cfg.autosaveSec}" style="width:64px"> s
              </label>
              <label style="display:flex;align-items:center;gap:8px">
                Auto download every <input id="kql_adl_min" type="number" min="1" value="${state._cfg.autodlMin}" style="width:64px"> min
                <input id="kql_adl_en" type="checkbox" ${state._cfg.enableAutodl?"checked":""}> enabled
              </label>
              <label style="display:flex;align-items:center;gap:8px">
                Raw stream <input id="kql_raw_en" type="checkbox" ${state._cfg.rawEnabled?"checked":""}>
                Ring size <input id="kql_raw_max" type="number" min="100" value="${state.raw.max}" style="width:80px">
              </label>
              <label style="display:flex;flex-direction:column;gap:4px">
                Webhook URL:
                <input id="kql_hook" type="text" value="${state._cfg.webhookUrl||""}" placeholder="https://example.com/kqlog">
              </label>
              <div style="display:flex;gap:8px;flex-wrap:wrap">
                <button id="kql_dl">Download JSON</button>
                <button id="kql_clear">Clear localStorage</button>
                <button id="kql_ping">Test webhook</button>
              </div>
            </div>`;
          el.querySelector("#kql_auto_sec").onchange = e => { state._cfg.autosaveSec = Math.max(3, parseInt(e.target.value || "8", 10)); scheduleSave(); saveLocal(); };
          el.querySelector("#kql_adl_min").onchange = e => { state._cfg.autodlMin = Math.max(1, parseInt(e.target.value || "10", 10)); scheduleDl(); saveLocal(); };
          el.querySelector("#kql_adl_en").onchange = e => { state._cfg.enableAutodl = !!e.target.checked; scheduleDl(); saveLocal(); };
          el.querySelector("#kql_raw_en").onchange = e => { state._cfg.rawEnabled = !!e.target.checked; saveLocal(); };
          el.querySelector("#kql_raw_max").onchange = e => { state.raw.max = Math.max(100, parseInt(e.target.value || "1000", 10)); saveLocal(); };
          el.querySelector("#kql_hook").onchange = e => { state._cfg.webhookUrl = String(e.target.value || "").trim(); saveLocal(); };
          el.querySelector("#kql_dl").onclick = () => blobDownload(filename(), snapshot());
          el.querySelector("#kql_clear").onclick = () => localStorage.removeItem(LS_KEY);
          el.querySelector("#kql_ping").onclick = () => postWebhook(state._cfg.webhookUrl, { test: true, t: now(), addon: ADDON_ID, day: DAY_ISO });
        }
      });
      return true;
    }
    (function retry(i=0){ if(mountCard()||i>60) return; setTimeout(()=>retry(i+1),200); })();

    // register + chip
    K.registerAddon({
      id:ADDON_ID,
      name:"Veiklos žurnalas",
      description:"Fiksuoja viktorinos eigą, automatiškai išsaugo ir leidžia parsisiųsti JSON momentines kopijas.",
      enable(){
        recordMeta({tag:"addon:enable",ver:VERSION});
        saveLocal();
        attachChip();
      },
      disable(){
        recordMeta({tag:"addon:disable"});
        saveLocal();
        detachChip();
      }
    });

    function attachChip(){
      if(document.getElementById("kqlog_chip")) return;
      const d=document.createElement("div");
      d.id="kqlog_chip";
      d.style.cssText="position:fixed;right:10px;bottom:10px;padding:6px 10px;border-radius:10px;background:#122033;color:#cfe0fa;border:1px solid #22324a;font:12px system-ui;z-index:99999;cursor:pointer";
      d.textContent="Žurnalas įjungtas";
      d.title="Spustelk ir atsisiųsk naujausią JSON momentinę kopiją";
      d.onclick=()=> blobDownload(filename(), snapshot());
      document.body.appendChild(d);
    }
    function detachChip(){
      const d=document.getElementById("kqlog_chip");
      if(d) d.remove();
    }
  }
})();



