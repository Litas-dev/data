/* KQuiz Addon: Halloween Blackout — v1.0
   Trigger: press "D" key (case-insensitive)
   Effect: fade to full black, hold 3s, fade out, remove
*/
(function(){
  "use strict";
  function factory(){
    const ID="halloweenBlackout";
    let K=null, running=false, layer=null;

    const FADE_MS=1200, HOLD_MS=3000, OUT_MS=600; // tune if needed

    function cssOnce(){
      if(document.getElementById("kq-halloween-css")) return;
      const s=document.createElement("style"); s.id="kq-halloween-css"; s.textContent=`
.kq-hollow-wrap{position:fixed;inset:0;z-index:2147483000;background:#000;opacity:0;pointer-events:none}
.kq-hollow-wrap.kq-anim{animation:kq_hollow  ${FADE_MS+HOLD_MS+OUT_MS}ms ease-in-out 1 forwards}
@keyframes kq_hollow{
  0%{opacity:0}
  ${Math.round((FADE_MS/(FADE_MS+HOLD_MS+OUT_MS))*100)}%{opacity:1}
  ${Math.round(((FADE_MS+HOLD_MS)/(FADE_MS+HOLD_MS+OUT_MS))*100)}%{opacity:1}
  100%{opacity:0}
}
      `;
      document.head.appendChild(s);
    }

    function blackout(){
      if(running) return;
      running=true; cssOnce();
      layer=document.createElement("div");
      layer.className="kq-hollow-wrap kq-anim";
      document.body.appendChild(layer);

      const total=FADE_MS+HOLD_MS+OUT_MS;
      setTimeout(()=>{ try{ layer.remove(); }catch{} layer=null; running=false; }, total+50);
    }

    // Admin quick button (optional)
    function isAdmin(){
      try{
        if(window.KQ_DEBUG_HOLLOWEEN) return true;
        if(new URLSearchParams(location.search).get("admin")==="1") return true;
        return localStorage.getItem("kqAdmin")==="1";
      }catch{ return false; }
    }
    function addTest(){
      if(!isAdmin() || document.getElementById("kq-hollow-test")) return;
      const box=document.createElement("div"); box.id="kq-hollow-test";
      box.style.cssText="position:fixed;right:10px;bottom:58px;z-index:2147483646";
      const b=document.createElement("button");
      b.textContent="BLACKOUT";
      b.style.cssText="padding:8px 12px;border-radius:10px;border:1px solid #244;background:#0e162b;color:#cfe0ff;font-weight:800;cursor:pointer";
      b.onclick=blackout; box.appendChild(b); document.body.appendChild(box);
    }

    function keyHandler(e){
      const k=(e.key||"").toLowerCase();
      if(k==="d") blackout();
    }

    function enable(KQuiz){
      K=KQuiz;
      cssOnce(); addTest();
      window.addEventListener("keydown", keyHandler);
      // API
      K.control=K.control||{};
      K.control.blackout = blackout;
    }
    function disable(){
      window.removeEventListener("keydown", keyHandler);
      try{ layer?.remove(); }catch{}
      layer=null; running=false; K=null;
    }

    return { id:ID, name:"Halloween Blackout", version:"1.0.0",
      description:"Press D to fade to black, hold 3s, fade out.",
      defaultEnabled:true, enable, disable };
  }
  function register(){ if(!window.KQuiz?.registerAddon) return setTimeout(register,120); KQuiz.registerAddon(factory()); }
  register();
})();
