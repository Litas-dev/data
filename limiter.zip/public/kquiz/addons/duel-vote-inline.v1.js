/* Community Duel Vote v1.7 — single fire per Q2/12/22/…; red vs blue; 25s; +20/-20; admin test */
(function(){
  "use strict";
  function factory(){
    const ID="duelVote";
    const VOTE_SECONDS=25, POINTS_WIN=20, POINTS_LOSE=20;
    const shouldQ = q => Number.isInteger(q) && (q===2 || (q>=12 && q%10===2));

    let active=false, pending=false, overlay=null, hud=null, startAt=0;
    let lastQFired=null;                    // per-question gate
    const seen=new Map(); let lastPairKey=null; const votes=new Map();
    let tickOsc=null, tickTimer=null;       // audio tick

    const $=(s,r=document)=>r.querySelector(s);
    const norm=s=>(s||"").normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const minisActive=()=>{
   const els = document.querySelectorAll("#kq-map-overlay,#kq-money-overlay,.kq-solo-overlay");
   for (const el of els){
     const cs = window.getComputedStyle(el);
     // treat as active only if actually shown
     if (cs.display!=="none" && cs.visibility!=="hidden" && parseFloat(cs.opacity||"1")>0) return true;
   }
   return false;
 };
    function currentQ(K){
      try{
        const s=K?.state?.session;
        if(Number.isInteger(s?.done)) return s.done;   // after question ends
        if(Number.isInteger(s?.i))    return s.i+1;    // during question
      }catch{}
      const el=document.getElementById("roundNum");
      if(el){ const m=String(el.textContent||"").match(/\d+/); if(m) return parseInt(m[0],10); }
      return null;
    }

    function top5(K){
      const P=K?.state?.players||{};
      return Object.entries(P).map(([id,p])=>({id, name:p.name||id, score:+(p.score||0), avatar:p.avatar||""}))
        .sort((a,b)=>b.score-a.score).slice(0,5).filter(p=>p.score>0);
    }
    function pickPair(list){
      if(list.length<2) return null;
      const w=id=>1/(1+(seen.get(id)||0));
      let pairs=[];
      for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
        const a=list[i], b=list[j], key=[a.id,b.id].sort().join("|");
        if(key!==lastPairKey) pairs.push({a,b,W:w(a.id)+w(b.id)});
      }
      if(!pairs.length){
        for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
          const a=list[i], b=list[j]; pairs.push({a,b,W:w(a.id)+w(b.id)});
        }
      }
      const tot=pairs.reduce((s,p)=>s+p.W,0); let r=Math.random()*tot;
      for(const p of pairs){ if((r-=p.W)<=0) return {A:p.a,B:p.b}; }
      const p0=pairs[(Math.random()*pairs.length)|0]; return {A:p0.a,B:p0.b};
    }

    function awardByName(K,name,pts){
      const players=K.state.players||(K.state.players={});
      const key=norm(name);
      let pid=Object.keys(players).find(id=>norm(players[id]?.name)===key);
      if(!pid && window.KQ_NameToId && KQ_NameToId[key]) pid=KQ_NameToId[key];
      if(!pid) return;
      const before=+(players[pid].score||0);
      const after=Math.max(0, before + pts);
      players[pid].score=after;
      try{ K.emit("scoresChanged",{id:pid,before,after,player:players[pid],correct:pts>=0}); }catch{}
    }

    function cssOnce(){
      if(document.getElementById("kq-duel-style")) return;
      const style=document.createElement("style"); style.id="kq-duel-style"; style.textContent=`
        .kq-duel-overlay{position:fixed;inset:0;z-index:10060;background:radial-gradient(1200px 800px at 50% 50%,rgba(18,24,46,.92),rgba(7,10,18,.96));display:flex;align-items:center;justify-content:center;padding:12px}
        .kq-duel-card{width:min(1000px,100%);background:#0b1124;border:1px solid #273149;border-radius:18px;padding:14px;display:grid;gap:12px;box-shadow:0 20px 48px rgba(0,0,0,.35)}
        .kq-row{display:flex;align-items:center;justify-content:space-between;gap:10px}
        .kq-pill{min-width:44px;text-align:center;border:1px solid #233154;border-radius:999px;padding:6px 10px;background:#0f1730;color:#cfe0ff;font-weight:800}
        .kq-track{position:relative;height:14px;border-radius:999px;background:#0d1530;overflow:hidden;border:1px solid #233154}
        .kq-duel-fill{position:absolute;inset:0;display:flex}
        .kq-aFill{height:100%;width:50%;background:linear-gradient(90deg,#c81e1e,#ef4444)}
        .kq-bFill{height:100%;width:50%;background:linear-gradient(90deg,#2563eb,#38bdf8)}
        .kq-divider{position:absolute;left:50%;top:0;bottom:0;width:2px;background:rgba(255,255,255,.08)}
        .kq-col{flex:1;display:grid;gap:10px;justify-items:center;align-items:center}
        .kq-side{border-radius:16px;padding:12px; width:100%; display:grid;gap:8px;justify-items:center}
        .kq-side.red{background:linear-gradient(180deg,rgba(120,20,30,.18),rgba(120,20,30,.08)); border:1px solid rgba(239,68,68,.25)}
        .kq-side.blue{background:linear-gradient(180deg,rgba(20,70,160,.18),rgba(20,70,160,.08)); border:1px solid rgba(59,130,246,.25)}
        .kq-pfp{width:108px;height:108px;border-radius:50%;object-fit:cover;border:2px solid #2a365f;box-shadow:0 8px 24px rgba(0,0,0,.35)}
        .kq-name{font-weight:900}
        .kq-key{font-weight:900;border:1px solid #233154;background:#0f1730;border-radius:10px;padding:6px 10px}
        .kq-count{font-weight:900;color:#cfe0ff}
        .kq-vs{position:relative;font-weight:900;opacity:.9}
        .kq-beam{position:absolute;left:50%;transform:translateX(-50%);top:-30px;height:140px;width:4px;background:linear-gradient(180deg,#ef4444,#38bdf8);filter:blur(.6px);opacity:.6;animation:kqPulse 1.2s infinite}
        @keyframes kqPulse{0%,100%{opacity:.45}50%{opacity:.9}}
        .kq-lead{box-shadow:0 0 0 2px rgba(255,255,255,.08),0 0 18px rgba(255,215,0,.25) inset}
        .kq-pop{animation:kqPop .18s ease}
        @keyframes kqPop{0%{transform:scale(.98)}100%{transform:scale(1)}}
      `; document.head.appendChild(style);
    }

    function startTick(){
      try{
        const AC = window.AudioContext||window.webkitAudioContext;
        const ctx = new AC();
        const doBeep=()=>{ 
          tickOsc = ctx.createOscillator();
          const g = ctx.createGain();
          tickOsc.frequency.value = 880;
          g.gain.value = 0.000001;
          tickOsc.connect(g); g.connect(ctx.destination);
          tickOsc.start();
          g.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime+0.01);
          g.gain.exponentialRampToValueAtTime(0.000001, ctx.currentTime+0.15);
          tickOsc.stop(ctx.currentTime+0.18);
        };
        doBeep();
        tickTimer = setInterval(doBeep, 1000);
      }catch{}
    }
    function stopTick(){
      try{ if(tickOsc) tickOsc.disconnect(); }catch{}
      tickOsc=null;
      try{ if(tickTimer) clearInterval(tickTimer); }catch{}
      tickTimer=null;
    }

    function mount(){
      cssOnce();
      overlay=document.createElement("div");
      overlay.className="kq-duel-overlay";
      overlay.innerHTML=`
        <div class="kq-duel-card">
          <div class="kq-row">
            <div class="kq-pill" id="kqd-left">${VOTE_SECONDS}</div>
            <div class="kq-track" style="flex:1;margin:0 8px">
              <div class="kq-duel-fill">
                <i id="kqd-aFill" class="kq-aFill" style="width:50%"></i>
                <div class="kq-divider"></div>
                <i id="kqd-bFill" class="kq-bFill" style="width:50%"></i>
              </div>
            </div>
            <div class="kq-pill">Balsavimas</div>
          </div>
          <div class="kq-row">
            <div class="kq-col"><div class="kq-side red" id="kqd-sideA">
              <img class="kq-pfp" id="kqd-pfpA" src="" referrerpolicy="no-referrer">
              <div class="kq-name" id="kqd-nameA"></div>
              <div class="kq-key">Spausk: A</div>
              <div class="kq-count">Balsai: <span id="kqd-a">0</span></div>
            </div></div>
            <div class="kq-vs">VS<div class="kq-beam"></div></div>
            <div class="kq-col"><div class="kq-side blue" id="kqd-sideB">
              <img class="kq-pfp" id="kqd-pfpB" src="" referrerpolicy="no-referrer">
              <div class="kq-name" id="kqd-nameB"></div>
              <div class="kq-key">Spausk: B</div>
              <div class="kq-count">Balsai: <span id="kqd-b">0</span></div>
            </div></div>
          </div>
          <div style="color:#9fb0c6;font-size:13px;text-align:center">Dvikovininkai balsuoti negali. Laimėtojas +${POINTS_WIN}, pralaimėtojas -${POINTS_LOSE} (min 0).</div>
        </div>`;
      document.body.appendChild(overlay);
      startTick();
    }
    function unmount(){ stopTick(); try{ overlay?.remove(); }catch{} overlay=null; }

    function startHud(){
      const left=$("#kqd-left",overlay), aFill=$("#kqd-aFill",overlay), bFill=$("#kqd-bFill",overlay);
      startAt=performance.now();
      function tick(){
        const end=startAt+VOTE_SECONDS*1000;
        const leftSec=Math.max(0,Math.ceil((end-performance.now())/1000));
        if(left) left.textContent=String(leftSec);
        const a=parseInt($("#kqd-a",overlay).textContent||"0",10);
        const b=parseInt($("#kqd-b",overlay).textContent||"0",10);
        const total=Math.max(1,a+b);
        const aPct=Math.round((a/total)*100); const bPct=100-aPct;
        if(aFill) aFill.style.width = aPct+"%";
        if(bFill) bFill.style.width = bPct+"%";
        $("#kqd-sideA",overlay).classList.toggle("kq-lead", a>b);
        $("#kqd-sideB",overlay).classList.toggle("kq-lead", b>a);
        if(leftSec<=0){ clearInterval(hud); finish(); }
      }
      tick(); hud=setInterval(tick,200);
    }

    function begin(K, qForGate){
      if(active || pending) return;
      pending = true;                            // latch while waiting SOLO
      lastQFired = qForGate;                     // gate this question immediately
      const list=top5(K); if(list.length<2){ pending=false; return; }
      const pair=pickPair(list); if(!pair){ pending=false; return; }
      const {A,B}=pair;
      lastPairKey=[A.id,B.id].sort().join("|");
      seen.set(A.id,(seen.get(A.id)||0)+1);
      seen.set(B.id,(seen.get(B.id)||0)+1);

      const wait=()=>{ if(minisActive()) return setTimeout(wait,250); pending=false; realBegin(K,A,B); };
      wait();
    }

    function realBegin(K,A,B){
      active=true; votes.clear();
      mount(); startHud();
      K.control?.pauseMain?.();
      $("#kqd-nameA",overlay).textContent = A.name||A.id;
      $("#kqd-nameB",overlay).textContent = B.name||B.id;
      $("#kqd-pfpA",overlay).src = A.avatar||"";
      $("#kqd-pfpB",overlay).src = B.avatar||"";

      const duelists=new Set([A.id.toLowerCase(),B.id.toLowerCase()]);
      K.control?.setChatGuard?.((msg)=>{
        if(!active) return false;
        const uid=(msg.user&&(msg.user.userId||msg.user.uniqueId))||norm(msg.displayName||msg.user?.nickname||"");
        if(!uid) return false;
        const players=K?.state?.players||{}; let pid=null;
        if(msg.displayName){ const key=norm(msg.displayName); pid=Object.keys(players).find(id=>norm(players[id]?.name)===key)||null; }
        if(pid && duelists.has(String(pid).toLowerCase())) return true;
        const t=String(msg.text||"").trim().toUpperCase();
        if(t!=="A" && t!=="B") return false;
        if(!votes.has(uid)){
          votes.set(uid,t);
          if(t==="A"){ const el=$("#kqd-a",overlay); if(el){ el.textContent=String((+el.textContent||0)+1); $("#kqd-sideA",overlay).classList.add("kq-pop"); setTimeout(()=>$("#kqd-sideA",overlay).classList.remove("kq-pop"),180); } }
          else       { const el=$("#kqd-b",overlay); if(el){ el.textContent=String((+el.textContent||0)+1); $("#kqd-sideB",overlay).classList.add("kq-pop"); setTimeout(()=>$("#kqd-sideB",overlay).classList.remove("kq-pop"),180); } }
        }
        return true;
      });
    }

    function finish(){
      const K=window.KQuiz;
      clearInterval(hud); hud=null;
      K.control?.clearChatGuard?.();
      const Aname=$("#kqd-nameA",overlay)?.textContent||"A";
      const Bname=$("#kqd-nameB",overlay)?.textContent||"B";
      const a=parseInt($("#kqd-a",overlay)?.textContent||"0",10);
      const b=parseInt($("#kqd-b",overlay)?.textContent||"0",10);

      let msg="";
      if(a===b){
        msg = `Lygiosios. Taškai nesikeičia.`;
      }else{
        const winner=(b>a)?"B":"A";
        const wName=winner==="A"?Aname:Bname;
        const lName=winner==="A"?Bname:Aname;
        awardByName(K,wName,POINTS_WIN);
        awardByName(K,lName,-POINTS_LOSE);
        msg = `Laimėjo ${wName} (+${POINTS_WIN}) | ${lName} (-${POINTS_LOSE})`;
      }
      const toast=document.createElement("div");
      toast.style.cssText="position:fixed;inset:0;z-index:10070;display:flex;align-items:center;justify-content:center;pointer-events:none";
      toast.innerHTML=`<div style="background:#0b1124;border:1px solid #2a365f;border-radius:16px;padding:14px 18px;color:#cfe0ff;font-weight:900">${msg}</div>`;
      document.body.appendChild(toast);
      setTimeout(()=>toast.remove(),1200);
      setTimeout(()=>{ unmount(); active=false; K.control?.resumeFlow?.(); },350);
    }

    // Single-fire gate wrapper
    function tryTrigger(K){
      const q=currentQ(K);
      if(!shouldQ(q)) return;
      if(active || pending) return;
      if(lastQFired===q) return;        // already fired on this question
      begin(K, q);
    }

    // admin/test
    function isAdmin(){
      try{
        if(window.KQ_DEBUG_DUEL) return true;
        if(new URLSearchParams(location.search).get("admin")==="1") return true;
        return localStorage.getItem("kqAdmin")==="1";
      }catch{ return false; }
    }

    function enable(K){
      if(K.__duelVoteWired) return;       // once-only listeners
      K.__duelVoteWired = true;

      // fire on both hooks; gate ensures single run
      K.on && K.on("questionStart", ()=> setTimeout(()=>tryTrigger(K),150));
      K.on && K.on("questionEnd",   ()=> tryTrigger(K));

      // admin test (does NOT set lastQFired so you can test anytime)
      if(isAdmin() && !document.getElementById("kq-duel-test")){
        const box=document.createElement("div"); box.id="kq-duel-test";
        box.style.cssText="position:fixed;right:10px;bottom:10px;z-index:100000";
        const btn=document.createElement("button");
        btn.textContent="DUEL TEST"; btn.style.cssText="padding:8px 12px;border-radius:10px;border:1px solid #244;background:#0e162b;color:#cfe0ff;font-weight:800;cursor:pointer";
        btn.onclick=()=>{ if(!active && !pending) realBegin(K, ...(function(){ 
          const list=top5(K); if(list.length<2) return [];
          const {A,B}=pickPair(list); return [A,B];
        })() ); };
        box.appendChild(btn); document.body.appendChild(box);
        window.addEventListener("keydown",(e)=>{ if(e.altKey && e.key.toLowerCase()==="d"){ e.preventDefault(); btn.click(); } });
      }

      // programmatic
      K.control = K.control || {};
      K.control.enqueueDuelVote = ()=>{ if(!active && !pending){ const list=top5(K); if(list.length>=2){ const {A,B}=pickPair(list); realBegin(K,A,B); } } };
    }

    function disable(){ try{ clearInterval(hud); }catch{} unmount(); active=false; pending=false; }

    return { id:ID, name:"Community Duel Vote", description:"Single-fire per Q2/12/22…, red vs blue, 25s vote, +20/-20.", defaultEnabled:true, enable, disable };
  }
  function register(){ if(!window.KQuiz || !KQuiz.registerAddon) return setTimeout(register,120); KQuiz.registerAddon(factory()); }
  register();
})();
