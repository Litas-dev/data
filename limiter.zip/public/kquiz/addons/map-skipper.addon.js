/*!
 * KQuiz add-on: Map Skipper — v1.0
 * Adds an "×" button to skip the CURRENT map and blacklist it for future picks.
 * Works without editing the map add-on. Best effort via DOM + public APIs.
 */
(function () {
  "use strict";

  // ---- safety gates
  if (!window.KQuiz || !KQuiz.registerAddon) { console.warn("[map-skipper] KQuiz not ready."); return; }

  // ---- storage
  const LS_KEY = "kquiz-map-blacklist";
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const on = (el, ev, fn) => el && el.addEventListener(ev, fn, { passive: true });

  function loadBL() { try { return new Set(JSON.parse(localStorage.getItem(LS_KEY) || "[]")); } catch { return new Set(); } }
  function saveBL(set) { try { localStorage.setItem(LS_KEY, JSON.stringify(Array.from(set))); } catch {} }
  const BL = loadBL();

  // ---- helpers
  function normIso(x){ return String(x||"").trim().toUpperCase(); }
  function blacklist(iso){
    if (!iso) return;
    BL.add(normIso(iso));
    saveBL(BL);
    console.info("[map-skipper] blacklisted:", iso);
  }

  // Try to read current ISO from DOM or globals the map add-on may expose
  function getCurrentIso(){
    // 1) Preferred: data attribute on the map container (common pattern)
    const root = document.querySelector('[data-addon="map-inline"], [data-kq-mini="map-inline"], .kq-map-root, .kq-mini-map');
    const iso = root?.getAttribute?.("data-iso") || root?.dataset?.iso;
    if (iso) return iso;

    // 2) Look for a country code printed in a hidden label
    const hint = document.querySelector('[data-map-iso], .kq-map-iso');
    if (hint?.textContent) return hint.textContent;

    // 3) Fallback global (if map inline ever sets it)
    if (window.KQ_Map?.currentIso) return window.KQ_Map.currentIso;

    return null;
  }

  // Attempt to skip current map round WITHOUT touching original code:
  // - Click a "Next/Skip" control if present
  // - Otherwise, dispatch custom events some builds listen to
  // - If nothing exists, close overlay and ask the map to continue by simulating reveal->next
  function softSkip(){
    // 1) obvious buttons
    const btn = $(
      '#kq-map-hide, #kq-map-next, button[data-role="map-next"], button[data-role="skip"], ' +
      'button[title="Praleisti"], button[title="Skip"], button:contains("Kitas"), button:contains("Next")'
    );
    if (btn){ btn.click(); return true; }

    // 2) custom events a patched map add-on might listen to
    window.dispatchEvent(new CustomEvent("kq:map:skip"));
    window.dispatchEvent(new CustomEvent("kq:mini:skip", { detail: { addon: "map-inline" }}));

    // 3) as last resort try to close overlay; many builds continue automatically
    const closeBtn = $('button[data-role="mini-close"], .kq-mini [data-close], .kq-mini .kq-close');
    if (closeBtn){ closeBtn.click(); return true; }

    return false;
  }

  // Inject the × button into the map UI when it appears
  function ensureSkipButton(){
    const media = document.querySelector(
      // common containers used by the map mini
      '.kq-mini[data-addon="map-inline"] .kq-media, ' +
      '[data-addon="map-inline"] .kq-media, ' +
      '.kq-mini-map .kq-media, ' +
      '.kq-map-root, .kq-mini[data-addon="map-inline"]'
    );
    if (!media || media.querySelector('#kq-map-skipper-x')) return;

    media.style.position = media.style.position || "relative";
    const b = document.createElement("button");
    b.id = "kq-map-skipper-x";
    b.textContent = "×";
    b.title = "Skip this map";
    b.style.cssText = "position:absolute;top:8px;right:10px;width:28px;height:28px;border-radius:14px;" +
      "background:#1b2547;color:#fff;border:1px solid #2a365f;font-weight:900;font-size:14px;" +
      "opacity:.6;cursor:pointer;z-index:2147483647;line-height:26px;text-align:center";
    on(b, "mouseenter", () => b.style.opacity = "1");
    on(b, "mouseleave", () => b.style.opacity = ".6");
    on(b, "click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const iso = getCurrentIso();
      if (iso) blacklist(iso);
      softSkip();
    });
    media.appendChild(b);
  }

  // Filter out blacklisted ISO BEFORE map add-on chooses a target, by trimming pools in the DOM-driven picker.
  // Since we cannot edit the map add-on, we provide a global helper many builds consult if present.
  window.KQ_MapSkipper = {
    isBlacklisted: (iso) => BL.has(normIso(iso)),
    list: () => Array.from(BL),
    clear: () => { BL.clear(); saveBL(BL); console.info("[map-skipper] blacklist cleared"); }
  };

  // Observe DOM to add the button when the map mini mounts
  const mo = new MutationObserver(() => ensureSkipButton());
  mo.observe(document.documentElement, { subtree: true, childList: true });

  // Also try on interval in case of virtualized UIs
  const iv = setInterval(ensureSkipButton, 4000);

  // Register add-on shell so it shows in settings if you want
  KQuiz.registerAddon?.({
    id: "map-skipper",
    name: "Map Skipper",
    version: "1.0.0",
    mount(){ /* no UI panel; works automatically */ },
    unmount(){ try { mo.disconnect(); clearInterval(iv); } catch {} }
  });

  console.info("[map-skipper] ready");
})();
