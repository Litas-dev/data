/* KQuiz Addon: Skull Rain — v1.1
   Trigger: press "A" or "S" (case-insensitive)
   Effect: rain of skulls from top, auto-cleans after duration
   Admin: ?admin=1 shows a SKULL RAIN button
*/
(function(){
  "use strict";
  function factory(){
    const ID="skullRain";
    let K=null, running=false, layer=null, killT=null;

    // Tunables
    const DURATION_MS = 3500;  // time skulls keep spawning
    const CLEAR_MS    = 1200;  // allow last skulls to exit
    const BATCHES     = 3;     // waves
    const PER_BATCH   = 18;    // skulls per wave
    const WAVE_GAP    = 250;   // ms between waves
    const MIN_FALL_MS = 1200;  // fall duration range
    const MAX_FALL_MS = 2400;

    const SKULL_SRC = "https://twemoji.maxcdn.com/v/latest/svg/1f480.svg";

    // CSS once
    function cssOnce(){
      if(document.getElementById("kq-skull-css")) return;
      const s=document.createElement("style"); s.id="kq-skull-css"; s.textContent=`
.kq-skull-wrap{position:fixed;inset:0;z-index:2147483000;pointer-events:none;overflow:hidden}
.kq-skull{position:absolute;top:-10vh;will-change:transform,opacity;opacity:.95;filter:drop-shadow(0 8px 14px rgba(0,0,0,.45))}
.kq-skull img{display:block;width:var(--sz);height:var(--sz)}
@keyframes kq_fall {
  0% { transform:translate(var(--x), -12vh) rotate(0deg); opacity:.0 }
  10% { opacity:.95 }
  100% { transform:translate(calc(var(--x) + var(--drift)), 110vh) rotate(var(--spin)); opacity:.0 }
}
#kq-skull-test{position:fixed;right:10px;bottom:58px;z-index:2147483646}
#kq-skull-test button{padding:8px 12px;border-radius:10px;border:1px solid #244;background:#0e162b;color:#cfe0ff;font-weight:800;cursor:pointer}
      `;
      document.head.appendChild(s);
    }

    // Spawn a single skull
    function addSkull(){
      if(!layer) return;
      const el=document.createElement("div");
      el.className="kq-skull";
      const x = Math.round(Math.random()*100) + "vw";
      const sz = (Math.random()<0.2 ? 56 : 36) + "px";
      const drift = (Math.random()*60 - 30) + "vw";
      const spin  = (Math.random()<0.5?-1:1) * (180+Math.random()*360) + "deg";
      const fall  = Math.round(MIN_FALL_MS + Math.random()*(MAX_FALL_MS - MIN_FALL_MS));

      el.style.setProperty("--x", x);
      el.style.setProperty("--sz", sz);
      el.style.setProperty("--drift", drift);
      el.style.setProperty("--spin", spin);
      el.style.animation = `kq_fall ${fall}ms linear 1 forwards`;

      el.innerHTML = `<img src="${SKULL_SRC}" alt="💀" referrerpolicy="no-referrer">`;
      layer.appendChild(el);
      el.addEventListener("animationend", ()=>{ try{ el.remove(); }catch{} }, { once:true });
    }

    // Orchestrate a rain burst
    function rain(){
      if(running) return;
      running=true; cssOnce();

      layer=document.createElement("div");
      layer.className="kq-skull-wrap";
      document.body.appendChild(layer);

      let wave=0;
      const spawnWave = ()=>{
        for(let i=0;i<PER_BATCH;i++){
          setTimeout(addSkull, Math.random()*WAVE_GAP);
        }
        if(++wave < BATCHES) setTimeout(spawnWave, WAVE_GAP);
      };
      spawnWave();

      clearTimeout(killT);
      killT = setTimeout(()=>{
        try{ layer.remove(); }catch{}
        layer=null; running=false;
      }, DURATION_MS + CLEAR_MS);
    }

    // Admin test button
    function isAdmin(){
      try{
        if(window.KQ_DEBUG_SKULLRAIN) return true;
        if(new URLSearchParams(location.search).get("admin")==="1") return true;
        return localStorage.getItem("kqAdmin")==="1";
      }catch{ return false; }
    }
    function addTest(){
      if(!isAdmin() || document.getElementById("kq-skull-test")) return;
      const box=document.createElement("div"); box.id="kq-skull-test";
      const b=document.createElement("button");
      b.textContent="SKULL RAIN";
      b.onclick=rain; box.appendChild(b); document.body.appendChild(box);
    }

    // Key triggers: A or S, capture to bypass focused inputs
    function onKey(e){
      const k=(e.key||"").toLowerCase();
      if(k==="s" || k==="a") rain();
    }

    function enable(KQuiz){
      K=KQuiz; cssOnce(); addTest();
      window.addEventListener("keydown", onKey, true);
      document.addEventListener("keydown", onKey, true);
      K.control = K.control || {};
      K.control.skullRain = rain;
    }
    function disable(){
      window.removeEventListener("keydown", onKey, true);
      document.removeEventListener("keydown", onKey, true);
      clearTimeout(killT);
      try{ layer?.remove(); }catch{}
      layer=null; running=false; K=null;
    }

    return { id:ID, name:"Skull Rain", version:"1.1.0",
      description:"Press A or S to spawn falling skulls. Visual only.",
      defaultEnabled:true, enable, disable };
  }
  function register(){ if(!window.KQuiz?.registerAddon) return setTimeout(register,120); KQuiz.registerAddon(factory()); }
  register();
})();
