// Client wiring for Kostas KQuiz server.js relay
(() => {
  // --- Game knobs (same as previous) ---
  const START_HP = 1000;
  const ROUND_SEC = 90;
  const COOLDOWNS = { attack: 3, shield: 12, steal: 8 };
  const POWER = { attack: 22, shield: 0.35, steal: 10 };
  const SHIELD_DECAY = 0.04;
  const MOMENTUM_DECAY = 0.015;

  // --- State ---
  let state = resetState();
  function resetState() {
    return {
      timeLeft: ROUND_SEC,
      running: true,
      winner: null,
      momentum: 0.5,
      teams: {
        red: { hp: START_HP, shield: 0, users: new Map(), uniqueAttackers: new Set() },
        blue: { hp: START_HP, shield: 0, users: new Map(), uniqueAttackers: new Set() },
      },
    };
  }

  // --- DOM helpers ---
  const $ = (s) => document.querySelector(s);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const fmt = (n) => Math.round(n);
  const banner = (t) => { const b = $('#banner'); b.textContent = t; b.classList.add('show'); setTimeout(()=>b.classList.remove('show'),1800); };
  const log = (team, html) => { const el = team==='red' ? $('#redLog') : $('#blueLog'); const p = document.createElement('p'); p.innerHTML = html; el.appendChild(p); el.scrollTop = el.scrollHeight; };

  function updateUI(){
    const R = state.teams.red, B = state.teams.blue;
    $('#redHP').style.width = (clamp(R.hp/START_HP,0,1)*100)+'%';
    $('#blueHP').style.width = (clamp(B.hp/START_HP,0,1)*100)+'%';
    $('#redHPNum').textContent = `${fmt(R.hp)} / ${START_HP}`;
    $('#blueHPNum').textContent = `${fmt(B.hp)} / ${START_HP}`;
    $('#redStats').textContent = `${R.users.size} žaidėjų`;
    $('#blueStats').textContent = `${B.users.size} žaidėjų`;
    $('#momentum').style.width = (state.momentum*100)+'%';
    $('#timer').textContent = new Date(state.timeLeft*1000).toISOString().substr(14,5);
    $('#centerMsg').textContent = state.winner
      ? (state.winner==='draw' ? 'Lygiosios. Sudden Death!' : `${state.winner.toUpperCase()} laimėjo`)
      : 'Kovokite chatu: attack • shield • steal';
    renderLB('red'); renderLB('blue');
  }
  function renderLB(team){
    const T = state.teams[team];
    const arr = Array.from(T.users.values()).sort((a,b)=>b.score-a.score).slice(0,8);
    const el = team==='red' ? $('#redLB') : $('#blueLB');
    el.innerHTML = arr.map(u=>`<div class="lbItem"><span>${u.name}</span><strong>${fmt(u.score)}</strong></div>`).join('') || '<div class="lbItem"><span>—</span><strong>0</strong></div>';
  }

  function ensureUser(team, name){
    const T = state.teams[team];
    if(!T.users.has(name)) T.users.set(name, { name, team, score:0, last:{} });
    return T.users.get(name);
  }
  function canUse(u, cmd){
    const cd = (COOLDOWNS[cmd]||0)*1000;
    return Date.now() - (u.last[cmd]||0) >= cd;
  }

  function endRound(w){ state.running=false; state.winner=w||'draw'; banner(state.winner==='draw'?'Lygiosios':`${w.toUpperCase()} pergalė`); }

  // Mechanics
  function doAttack(name, team){
    const atk=team, def=team==='red'?'blue':'red';
    const A=state.teams[atk], D=state.teams[def];
    const u=ensureUser(atk,name);
    if(!canUse(u,'attack')) return;
    const dmg = POWER.attack * (1 + A.uniqueAttackers.size*0.005);
    const eff = dmg * clamp(1 - D.shield, 0, 1);
    D.hp = clamp(D.hp - eff, 0, START_HP);
    u.score += eff; u.last.attack=Date.now(); A.uniqueAttackers.add(name);
    state.momentum = clamp(state.momentum + 0.03*(atk==='red'?1:-1), 0.05, 0.95);
    log(atk, `<b>${name}</b> smogė <span style="color:${atk==='red'?'#ff5964':'#3bd671'}">-${fmt(eff)}</span>`);
    if(D.hp===0) endRound(atk);
  }
  function doShield(name, team){
    const T=state.teams[team]; const u=ensureUser(team,name);
    if(!canUse(u,'shield')) return;
    T.shield = clamp(T.shield + POWER.shield, 0, 0.75);
    u.last.shield=Date.now();
    log(team, `<b>${name}</b> aktyvavo skydą (+${fmt(POWER.shield*100)}%)`);
    banner(`${team.toUpperCase()} skydas ↑`);
  }
  function doSteal(name, team){
    const atk=team, def=team==='red'?'blue':'red';
    const A=state.teams[atk], D=state.teams[def];
    const u=ensureUser(atk,name);
    if(!canUse(u,'steal')) return;
    const val=POWER.steal, eff = val * clamp(1 - D.shield, 0, 1);
    D.hp = clamp(D.hp - eff, 0, START_HP);
    A.hp = clamp(A.hp + eff*0.6, 0, START_HP);
    u.score += eff*1.2; u.last.steal=Date.now(); A.uniqueAttackers.add(name);
    log(atk, `<b>${name}</b> pavogė ${fmt(eff)} HP`);
    if(D.hp===0) endRound(atk);
  }

  // Chat router
  function handleChat(username, text){
    if(!state.running) return;
    const msg = String(text||'').trim().toLowerCase();
    if(!msg) return;

    if(msg.startsWith('join ')){
      const want = msg.split(/\s+/)[1];
      if(want==='red' || want==='blue'){
        // eject from other team
        const other = want==='red'?'blue':'red';
        state.teams[other].users.delete(username);
        ensureUser(want, username);
        banner(`${username} prisijungė prie ${want.toUpperCase()}`);
        updateUI();
        return;
      }
    }

    // autobalance if not on team
    let team = state.teams.red.users.has(username) ? 'red'
             : state.teams.blue.users.has(username) ? 'blue'
             : (state.teams.red.hp <= state.teams.blue.hp ? 'red' : 'blue');
    ensureUser(team, username);

    if(msg==='attack' || msg==='a') return doAttack(username, team);
    if(msg==='shield' || msg==='s') return doShield(username, team);
    if(msg==='steal'  || msg==='x') return doSteal(username, team);
  }

  // Ticks
  setInterval(()=>{
    if(!state.running) return;
    const R=state.teams.red, B=state.teams.blue;
    R.shield = clamp(R.shield - SHIELD_DECAY, 0, 1);
    B.shield = clamp(B.shield - SHIELD_DECAY, 0, 1);
    state.momentum = clamp(state.momentum + (0.5 - state.momentum)*MOMENTUM_DECAY, 0.05, 0.95);
    state.timeLeft = Math.max(0, state.timeLeft - 1);
    if(state.timeLeft===0){
      if(R.hp===B.hp){ banner('Sudden Death! Kitas smūgis laimi'); state.winner='draw'; state.timeLeft=9999; }
      else endRound(R.hp>B.hp?'red':'blue');
    }
    updateUI();
  },1000);

  // WS bootstrap
  const wsURL = `${location.protocol==='https:'?'wss':'ws'}://${location.host}/stream`;
  let ws;
  function connectWS(){
    ws = new WebSocket(wsURL);
    $('#ws').textContent = 'WS: jungiamasi…';
    ws.onopen = () => { $('#ws').textContent = 'WS: prisijungta'; };
    ws.onclose = () => { $('#ws').textContent = 'WS: atsijungta'; setTimeout(connectWS, 1500); };
    ws.onerror = () => { $('#ws').textContent = 'WS: klaida'; };
    ws.onmessage = (ev) => {
      try{
        const m = JSON.parse(ev.data);
        // server.js emits: chat, like, gift, follow, share, join, roomUser, streamEnd, disconnected
        if(m.type==='chat'){
          const name = m.displayName || m.user?.nickname || 'Žaidėjas';
          const text = m.text || '';
          handleChat(name, text);
        } else if(m.type==='roomUser'){
          $('#viewers').textContent = `Žiūrovai: ${Number(m.viewerCount||0)}`;
        }
      }catch{}
    };
  }
  connectWS();

  // Health ping
  fetch('/health').then(r=>r.json()).then(x=>{
    $('#room').textContent = `LIVE: @${x.user || 'n/a'}`;
  }).catch(()=>$('#room').textContent='LIVE: n/a');

  // Local reset
  $('#resetBtn').addEventListener('click', ()=>{
    state = resetState();
    $('#redLog').innerHTML=''; $('#blueLog').innerHTML='';
    banner('Naujas raundas');
    updateUI();
  });

  // Initial draw
  updateUI();
})();
